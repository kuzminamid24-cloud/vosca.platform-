"""Снимки РАБОЧЕЙ версии (настоящий сервер, не демо) для описания платформы.
   python3 tools/shots_real.py [папка_для_снимков]   — поднимает временный сервер, наполняет его данными и снимает экраны (интерфейс на английском)."""
import os, sys, json, time, base64, pathlib, subprocess, tempfile, shutil
from playwright.sync_api import sync_playwright
ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else '/tmp/vosca_shots'); OUT.mkdir(parents=True, exist_ok=True)
PORT = os.environ.get('PORT', '3125'); BASE = f'http://localhost:{PORT}'
tmp = pathlib.Path(tempfile.mkdtemp()); shutil.copytree(ROOT / 'content', tmp / 'content')
env = dict(os.environ, DATA_DIR=str(tmp / 'data'), CONTENT_DIR=str(tmp / 'content'), PORT=PORT, ADMIN_EMAIL='admin@school.example', ADMIN_PASSWORD='adminpass123')
srv = subprocess.Popen(['node', '--no-warnings', 'server.js'], cwd=ROOT, env=env, stdout=open(tmp / 'server.log', 'w'), stderr=subprocess.STDOUT); time.sleep(1.8)
PH = lambda n: 'data:image/png;base64,' + base64.b64encode((ROOT / 'tools' / 'demo_photos' / n).read_bytes()).decode()
H = 3600 * 1000

def api(ctx, method, url, body=None):
    r = ctx.request.fetch(BASE + url, method=method, headers={'Content-Type': 'application/json'}, data=json.dumps(body if body is not None else {}))
    try: d = r.json()
    except Exception: d = None
    assert r.status == 200, (method, url, r.status, d)
    return d

try:
    with sync_playwright() as p:
        br = p.chromium.launch()
        def ctx(tz='Europe/Moscow', w=1240, h=900, mobile=False):
            c = br.new_context(viewport={'width': w, 'height': h}, locale='en-GB', timezone_id=tz, device_scale_factor=2 if mobile else 1, is_mobile=mobile)
            c.add_init_script("try{localStorage.setItem('vosca_lang','en')}catch(e){}"); return c
        # ── наполнение ──
        A = ctx(); api(A, 'POST', '/api/login', {'email': 'admin@school.example', 'password': 'adminpass123'})
        api(A, 'POST', '/api/admin/settings', {'email': 'hello@yourschool.com', 'site': 'https://yourschool.com'})
        kim = api(A, 'POST', '/api/admin/teachers', {'name': 'Kim Somchai', 'email': 'kim@school.example', 'langs': ['thai'], 'password': 'teacherpass1', 'meeting_url': 'https://meet.google.com/kim-room', 'tz': 'Asia/Bangkok', 'bio': ''})['teacher']
        nari = api(A, 'POST', '/api/admin/teachers', {'name': 'Nari Chaidee', 'email': 'nari@school.example', 'langs': ['thai'], 'password': 'teacherpass1', 'meeting_url': 'https://meet.google.com/nari-room', 'tz': 'Asia/Bangkok', 'bio': ''})['teacher']
        K = ctx('Asia/Bangkok'); api(K, 'POST', '/api/login', {'email': 'kim@school.example', 'password': 'teacherpass1'})
        api(K, 'POST', '/api/teach/profile', {'headline': 'Тайский с нуля до разговорного', 'headline_en': 'Thai from zero to conversation', 'teaches': 'Thai, English', 'speaks': 'Thai, English, Russian', 'years': 8, 'country': 'Thailand',
            'bio': 'Тайский язык, 8 лет опыта.', 'bio_en': 'Born and raised in Chiang Mai. I have taught Thai for over eight years: from the alphabet and tones to fluent conversation.\nWe talk a lot in class — no cramming, just real situations: cafés, taxis, meeting people.'})
        api(K, 'POST', '/api/teach/photo', {'data': PH('kim.png')})
        N = ctx('Asia/Bangkok'); api(N, 'POST', '/api/login', {'email': 'nari@school.example', 'password': 'teacherpass1'})
        api(N, 'POST', '/api/teach/profile', {'headline': 'Клуб и произношение', 'headline_en': 'Speaking club & pronunciation', 'teaches': 'Thai, English', 'speaks': 'Thai, English', 'years': 5, 'country': 'Thailand',
            'bio': 'Веду клуб.', 'bio_en': 'I run the speaking club: small groups, lots of practice and gentle corrections.'})
        api(N, 'POST', '/api/teach/photo', {'data': PH('nari.png')})
        studs = {}; codes = api(A, 'POST', '/api/admin/codes', {'course': 'thai', 'days': 90, 'count': 3, 'max': 1})['codes']
        for (name, mail), cd in zip((('Anna Petrova', 'anna@school.example'), ('Boris Ivanov', 'boris@school.example'), ('Maria Sokolova', 'maria@school.example')), codes):
            c = ctx(); r = api(c, 'POST', '/api/register', {'code': cd, 'name': name, 'email': mail, 'password': 'student1234', 'tz': 'Europe/Moscow', 'consents': {'offer': True, 'pd': True, 'age': True}}); studs[mail] = (c, r)
        ids = {u['email']: u['id'] for u in api(A, 'GET', '/api/admin/users')['users']}
        anna = ids['anna@school.example']
        api(A, 'POST', f'/api/admin/users/{anna}/enroll', {'course': 'thai', 'days': 90}); api(A, 'POST', f'/api/admin/users/{anna}/assign', {'course': 'thai', 'teacher': kim['id']})
        now = int(time.time() * 1000)
        api(K, 'POST', '/api/teach/sessions', {'student': anna, 'course': 'thai', 'start': now + 26 * H, 'dur': 50, 'title': 'Thai conversation practice'})
        api(A, 'POST', '/api/admin/club/grant', {'user': 'anna@school.example', 'days': 18, 'note': 'Paid: 3 months'})
        api(A, 'POST', '/api/admin/club/grant', {'user': 'maria@school.example', 'days': 4, 'note': 'Trial week'})
        cs = api(N, 'POST', '/api/teach/club/sessions', {'start': now + 27 * H, 'dur': 60, 'repeat': 4, 'lang': 'English', 'level': 'A2–B1', 'title': 'Small talk: introductions'})['created']
        api(K, 'POST', '/api/teach/club/sessions', {'start': now + 52 * H, 'dur': 60, 'lang': 'English', 'level': 'B1', 'title': 'Trips and travel'})
        api(studs['anna@school.example'][0], 'POST', f'/api/club/{cs[0]["id"]}/book', {})
        api(studs['maria@school.example'][0], 'POST', f'/api/club/{cs[0]["id"]}/book', {})
        api(A, 'POST', '/api/admin/codes', {'course': 'club', 'days': 30, 'count': 1, 'max': 1, 'note': 'Club month — order #1042'})
        # ── снимки ──
        def shot(c, hash_, name, wait='.phero, .sect, .card', full=True, click=None, el=None):
            pg = c.new_page(); pg.goto(BASE + '/' + hash_); pg.wait_for_selector(wait, timeout=8000); pg.wait_for_timeout(900)
            if click: pg.click(click); pg.wait_for_timeout(700)
            (pg.locator(el).first.screenshot(path=str(OUT / name)) if el else pg.screenshot(path=str(OUT / name), full_page=full)); pg.close(); print('  ✓', name)
        S = studs['anna@school.example'][0]; M = studs['maria@school.example'][0]; B = studs['boris@school.example'][0]
        pg = br.new_context(viewport={'width': 1240, 'height': 800}, locale='en-GB'); q = pg.new_page(); q.add_init_script("try{localStorage.setItem('vosca_lang','en')}catch(e){}")
        q.goto(BASE + '/#/'); q.wait_for_selector('form', timeout=8000); q.wait_for_timeout(700); q.screenshot(path=str(OUT / '01_login.png')); print('  ✓ 01_login.png'); q.close()
        shot(S, '#/cabinet', '02_student_cabinet.png', '.phero')
        shot(S, '#/teachers', '03_teachers.png', '.tgrid')
        shot(S, f'#/teachers/{kim["id"]}', '04_teacher_profile.png', '.tprof')
        shot(S, '#/club', '05_club_student.png', '.clubst')
        shot(M, '#/club', '06_club_expiring.png', '.clubst')
        shot(B, '#/club', '07_club_nosub.png', '.clubst')
        shot(K, '#/profile', '08_teacher_profile_editor.png', '#tprofBox form')
        shot(N, '#/teach/club', '09_teacher_club.png', '.sess')
        shot(A, '#/admin/club', '10_admin_club.png', '.clubst, .card')
        shot(A, f'#/admin/user/{anna}', '11_admin_student_club.png', '#clubSect', el='#clubSect')
        shot(A, f'#/admin/user/{kim["id"]}', '12_admin_teacher_profile.png', '[data-form=tprof]', el='[data-form=tprof]')
        shot(A, '#/admin/codes', '13_admin_codes.png', '.phero')
        shot(A, '#/admin', '14_admin_users.png', '.phero')
        mob = ctx('Europe/Moscow', 390, 800, True); api(mob, 'POST', '/api/login', {'email': 'anna@school.example', 'password': 'student1234'})
        shot(mob, '#/cabinet', '15_mobile_cabinet.png', '.phero'); shot(mob, '#/club', '16_mobile_club.png', '.clubst')
        br.close()
finally:
    srv.terminate(); shutil.rmtree(tmp, ignore_errors=True)
