/* Демо-режим: вся платформа работает прямо в браузере. Ядро — то же самое, что на сервере (shared/*.js). */
(() => {
  'use strict';
  window.VOSCA_DEMO = true;
  const KEY = 'vosca_demo_v2', DAY = 864e5, MIN = 6e4;
  const rnd = n => { const a = new Uint8Array(n); crypto.getRandomValues(a); return a; };
  const b64u = a => btoa(String.fromCharCode(...a)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const C = window.DEMO_CONTENT;
  /* состояние держим и в localStorage (между визитами), и в sessionStorage (переживает обновление страницы даже там, где
     localStorage капризничает — например, при открытии файла двойным щелчком); при загрузке берём более свежее */
  const readKey = store => { try { return JSON.parse(store.getItem(KEY)); } catch (e) { return null; } };
  let st = null; { const a = readKey(localStorage), b = readKey(sessionStorage); st = a && b ? ((b.ts || 0) > (a.ts || 0) ? b : a) : (a || b); }
  const SEED_VER = 8;                                        // поднимайте при изменении демо-данных: устаревшее состояние в браузере будет пересоздано (иначе новые демо-коды «не найдены»)
  const fresh = !st || !st.db || st.seedVer !== SEED_VER; st = fresh ? { db: {}, uid: null, skew: 0, seedVer: SEED_VER } : st;
  const save = () => { st.ts = Date.now(); let j; try { j = JSON.stringify(st); } catch (e) { return; } try { localStorage.setItem(KEY, j); } catch (e) { } try { sessionStorage.setItem(KEY, j); } catch (e) { } };
  window.addEventListener('pagehide', save);
  const env = {
    now: () => Date.now() + st.skew, random: Math.random, token: n => b64u(rnd(n)),
    hashPassword: p => 'demo$' + btoa(unescape(encodeURIComponent(p))), verifyPassword: (p, h) => h === 'demo$' + btoa(unescape(encodeURIComponent(p))), dummyHash: () => 'demo$x',
    baseUrl: () => 'https://app.voscaschool.com', dropSessions() { }, mailMode: () => 'log',
    photoSrc: r => 'data:' + r.mime + ';base64,' + r.b64
  };
  let ver = 1;
  const content = { version: () => ver, courses: () => C.courses, meta: (k, lang) => { const l = C.lessons[k]; if (!l) return null; const v = lang === 'en' && EN[k]; return { title: (v && v.title) || l.title, th: l.th, min: l.min, tasks: l.tasks, lead: (v && v.lead) || l.lead }; }, bank: (k, lang) => { const v = lang === 'en' && EN[k]; return v ? v.bank : (C.lessons[k] ? C.lessons[k].bank : []); }, langs: k => (EN[k] && (window.DEMO_LESSONS_EN[k] || HTML[k + '.en']) ? ['ru', 'en'] : ['ru']) };
  const EN = C.lessonsEn = C.lessonsEn || {};               // английские версии: паспорт с банком вопросов (файл урока — DEMO_LESSONS_EN или IndexedDB)

  /* ── свои уроки в демо: хранятся в IndexedDB этого браузера (то же, что делает сервер, но локально) ── */
  const HTML = window.DEMO_CUSTOM_HTML = {}, STAGE = {}, KEY_RE = /^[a-z0-9][a-z0-9-]{1,39}$/;
  const custom = { lessons: {}, en: {} };               // json-паспорта загруженных уроков
  const idb = () => new Promise((res, rej) => { const r = indexedDB.open('vosca_demo', 1); r.onupgradeneeded = () => r.result.createObjectStore('kv'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  const idbGet = async k => { const db = await idb(); return new Promise((res, rej) => { const q = db.transaction('kv').objectStore('kv').get(k); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); }); };
  const idbSet = async (k, v) => { const db = await idb(); return new Promise((res, rej) => { const t = db.transaction('kv', 'readwrite'); t.objectStore('kv').put(v, k); t.oncomplete = () => res(); t.onerror = () => rej(t.error); }); };
  let idbOk = true;
  async function persistContent(htmlKey) {
    try { await idbSet('meta', { courses: C.courses, lessons: custom.lessons, en: custom.en }); if (htmlKey) await idbSet('html:' + htmlKey, HTML[htmlKey]); } catch (e) { idbOk = false; console.warn('IndexedDB недоступна — уроки сохранятся только до закрытия вкладки', e); }
  }
  window.DEMO_READY = (async () => {
    try { const m = await idbGet('meta'); if (m) { C.courses = m.courses; custom.lessons = m.lessons || {}; custom.en = m.en || {}; Object.assign(C.lessons, custom.lessons); Object.assign(EN, custom.en); for (const k of Object.keys(custom.lessons)) HTML[k] = await idbGet('html:' + k); for (const k of Object.keys(custom.en)) HTML[k + '.en'] = await idbGet('html:' + k + '.en'); ver++; } } catch (e) { idbOk = false; }
  })();
  const bad = (status, error) => ({ status, data: { error } });
  async function adminContent(method, path, b, user) {
    if (!user) return bad(401, 'Войдите в аккаунт'); if (user.role !== 'admin') return bad(403, 'Только для администратора');
    if (path === '/api/admin/lessons/stage') {
      const raw = String(b.html || '');
      if (raw.length < 2000 || raw.length > 8e6) return bad(400, 'Файл урока слишком маленький или слишком большой');
      const html = window.VoscaCore.adaptLesson(raw);
      if (!html) return bad(400, 'Не похоже на урок Vosca: в файле не нашлось движка уроков. Загрузите HTML, собранный нашим конструктором.');
      const id = b64u(rnd(8)); STAGE[id] = html; return { status: 200, data: { id, html } };
    }
    if (path === '/api/admin/lessons/commit') {
      const html = STAGE[String(b.stage || '')]; if (!html) return bad(404, 'Файл урока потерян — загрузите заново');
      const key = String(b.key || ''), meta = b.meta, bank = b.bank, c = C.courses.find(x => x.id === String(b.course || ''));
      if (!KEY_RE.test(key)) return bad(400, 'Ключ урока: латиница, цифры и дефис, 2–40 символов');
      if (b.lang === 'en') {                                         // английская версия существующего урока
        const base = C.lessons[key]; if (!base) return bad(400, 'Сначала опубликуйте русскую версию урока с этим ключом — перевод добавляется к ней');
        if (!Array.isArray(bank)) return bad(400, 'Не удалось прочитать вопросы урока');
        const a = new Map(base.bank.map(q => [q.id, q]));
        if (bank.length !== base.bank.length || bank.some(q => !a.has(q.id) || a.get(q.id).opts.length !== (q.opts || []).length || a.get(q.id).a !== q.a)) return bad(400, 'Вопросы для ДЗ в переводе не совпадают с русской версией (номера вопросов, число вариантов или правильные ответы). Соберите перевод из того же урока.');
        const j = { key, title: String((meta && meta.title) || base.title), lead: String((meta && meta.lead) || ''), lang: 'en', bank };
        custom.en[key] = j; EN[key] = j; HTML[key + '.en'] = html; ver++; delete STAGE[b.stage]; await persistContent(key + '.en'); return { status: 200, data: { ok: true } };
      }
      if (!c) return bad(400, 'Курс не найден');
      if (!meta || !meta.title || !(meta.tasks >= 1 && meta.tasks <= 200)) return bad(400, 'Не удалось прочитать паспорт урока');
      if (!Array.isArray(bank)) return bad(400, 'Не удалось прочитать вопросы урока');
      for (const q of bank) if (!q || !q.id || !q.q || !Array.isArray(q.opts) || q.opts.length < 2 || !(q.a >= 0 && q.a < q.opts.length)) return bad(400, 'Некорректный вопрос в банке: ' + (q && q.id));
      const j = { key, title: meta.title, th: meta.th || '', min: meta.min || 40, tasks: meta.tasks, lead: meta.lead || '', bank };
      custom.lessons[key] = j; C.lessons[key] = j; HTML[key] = html;
      if (!C.courses.some(cc => (cc.modules || []).some(m => m.lessons.includes(key)))) {
        const mid = String(b.module || 'main').replace(/[^a-z0-9-]/gi, '').toLowerCase() || 'main';
        let m = (c.modules = c.modules || []).find(x => x.id === mid); if (!m) { m = { id: mid, title: String(b.moduleTitle || 'Уроки').slice(0, 80), lessons: [] }; c.modules.push(m); }
        m.lessons.push(key);
      }
      c.ready = true; ver++; delete STAGE[b.stage]; await persistContent(key); return { status: 200, data: { ok: true } };
    }
    if (path === '/api/admin/lessons/remove') { C.courses.forEach(c => (c.modules || []).forEach(m => { m.lessons = m.lessons.filter(k => k !== String(b.key)); })); ver++; await persistContent(); return { status: 200, data: { ok: true } }; }
    if (path === '/api/admin/lessons/move') {
      C.courses.forEach(c => (c.modules || []).forEach(m => { const i = m.lessons.indexOf(String(b.key)), j = i + (b.dir < 0 ? -1 : 1); if (i >= 0 && j >= 0 && j < m.lessons.length) [m.lessons[i], m.lessons[j]] = [m.lessons[j], m.lessons[i]]; }));
      ver++; await persistContent(); return { status: 200, data: { ok: true } };
    }
    if (path === '/api/admin/courses') {
      const id = String(b.id || '').toLowerCase(); if (!/^[a-z0-9-]{2,20}$/.test(id)) return bad(400, 'Код курса: латиница, 2–20 символов');
      const cur = C.courses.find(x => x.id === id), c = Object.assign({ id, title: '', native: '', flag: '🌍', ready: false, about: '', buyUrl: '', modules: [] }, cur || {});
      ['title', 'native', 'flag', 'about', 'buyUrl'].forEach(k => { if (b[k] !== undefined) c[k] = String(b[k]).trim().slice(0, 300); });
      if (!c.title) return bad(400, 'Введите название курса'); if (c.buyUrl && !/^https:\/\//.test(c.buyUrl)) return bad(400, 'Ссылка «купить» должна начинаться с https://');
      if (cur) Object.assign(cur, c); else C.courses.push(c);
      ver++; await persistContent(); return { status: 200, data: { ok: true } };
    }
    return bad(404, 'Не найдено');
  }
  const app = window.DEMO_APP = window.VoscaCore.createApp({ db: st.db, content, env, adminEmail: 'admin@vosca.demo', cfg: { PASS_SCORE: 80, HW_SIZE: 8, HW_PASS: 70, MIN_LESSON_SECONDS: 90, AUTO_ENROLL: [], LEGAL: false } });
  const call = (user, method, path, body) => app.handle({ method, path, query: {}, body: body || {}, user, ip: 'demo', ua: 'demo' });
  const U = email => Object.values(app.db().users).find(u => u.email === email);

  function seed() {
    const tz = (() => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone; } catch (e) { return 'Europe/Moscow'; } })();
    const admin = app.bootstrapAdmin('admin@vosca.demo', 'demo1234', 'Администратор');
    call(admin, 'POST', '/api/admin/settings', { email: 'voscaofficial0@gmail.com', phone: '+7 931 393-66-85', site: 'https://voscaschool.com' });
    const kim = call(admin, 'POST', '/api/admin/teachers', { name: 'Ким Сомчай', email: 'kim@vosca.demo', langs: ['thai'], password: 'demo1234', meeting_url: 'https://meet.google.com/vosca-demo-room', tz: 'Asia/Bangkok', bio: 'Преподаватель тайского языка, 8 лет опыта. Говорю на тайском, английском и русском.' }).body.teacher;
    /* коды доступа: по одному на каждый язык школы (регистрация без кода невозможна) */
    const codeFor = {}; const mkCode = (code, course, days, note) => { app.db().codes[code] = { code, course, days, max: 1000, used: 0, note, active: true, created: env.now(), by: admin.id, users: [] }; codeFor[course] = codeFor[course] || code; };
    mkCode('VOSCA-DEMO-TEST', 'thai', 30, 'демо-код: тайский'); mkCode('VOSCA-DEMO-FREN', 'fr', 30, 'демо-код: французский'); mkCode('VOSCA-DEMO-ENGL', 'en', 30, 'демо-код: английский');
    mkCode('VOSCA-DEMO-ESPA', 'es', 30, 'демо-код: испанский'); mkCode('VOSCA-DEMO-ZHON', 'zh', 30, 'демо-код: китайский'); mkCode('VOSCA-DEMO-RUSS', 'ru', 30, 'демо-код: русский');
    mkCode('VOSCA-SEED-ANNA', 'thai', 90, 'демо: Анна');
    const reg = (name, email, code) => { const r = call(null, 'POST', '/api/register', { name, email, password: 'demo1234', tz, code: code || 'VOSCA-DEMO-TEST' }); return app.db().users[r.login]; };
    const anna = reg('Анна', 'anna@vosca.demo', 'VOSCA-SEED-ANNA');
    call(admin, 'POST', `/api/admin/users/${anna.id}/assign`, { course: 'thai', teacher: kim.id });
    const kimU = app.db().users[kim.id], t = env.now(), hour = 36e5;
    const at = ms => Math.ceil((t + ms) / (5 * MIN)) * 5 * MIN;
    call(kimU, 'POST', '/api/teach/sessions', { student: anna.id, course: 'thai', start: at(33 * MIN), dur: 50, title: 'Знакомство и разговорная практика' });
    call(kimU, 'POST', '/api/teach/sessions', { student: anna.id, course: 'thai', start: at(26 * hour), dur: 50, repeat: 3, title: 'Разговорная практика' });
    const bob = reg('Борис', 'boris@vosca.demo'); void bob;
    /* публичные профили преподавателей и Разговорный клуб */
    const P = window.DEMO_PHOTOS || {};
    call(kimU, 'POST', '/api/teach/profile', { headline: 'Тайский язык с нуля до разговорного', headline_en: 'Thai from zero to conversation', teaches: 'Тайский, английский', speaks: 'Тайский, английский, русский', years: 8, country: 'Таиланд',
      bio: 'Родился и вырос в Чиангмае. Преподаю тайский больше восьми лет: от алфавита и тонов до свободного разговора. На занятиях много говорим — без зубрёжки, с живыми ситуациями: кафе, такси, знакомства.\nЛюблю, когда ученик уже на первом уроке говорит первые фразы.',
      bio_en: 'Born and raised in Chiang Mai. I have taught Thai for over eight years: from the alphabet and tones to fluent conversation. We talk a lot in class — no cramming, just real situations: cafés, taxis, meeting people.\nI love it when a student says their first phrases already in the first lesson.' });
    if (P.kim) call(kimU, 'POST', '/api/teach/photo', { data: P.kim });
    const nari = call(admin, 'POST', '/api/admin/teachers', { name: 'Нари Чайдээ', email: 'nari@vosca.demo', langs: ['thai', 'en'], password: 'demo1234', meeting_url: 'https://meet.google.com/vosca-demo-nari', tz: 'Asia/Bangkok', bio: '' }).body.teacher;
    const nariU = app.db().users[nari.id];
    call(nariU, 'POST', '/api/teach/profile', { headline: 'Разговорный клуб и произношение', headline_en: 'Speaking club & pronunciation', teaches: 'Тайский, английский', speaks: 'Тайский, английский', years: 5, country: 'Таиланд',
      bio: 'Веду разговорный клуб: небольшие группы, много практики и мягкая поправка ошибок. Помогаю заговорить тем, кто «всё понимает, но стесняется».',
      bio_en: 'I run the speaking club: small groups, lots of practice and gentle corrections. I help people who “understand everything but are shy to speak” find their voice.' });
    if (P.nari) call(nariU, 'POST', '/api/teach/photo', { data: P.nari });
    const maria = reg('Мария', 'maria@vosca.demo');
    /* французский: свой преподаватель и свой ученик — с тайским они не пересекаются */
    const marie = call(admin, 'POST', '/api/admin/teachers', { name: 'Мари Леблан', email: 'marie@vosca.demo', langs: ['fr'], password: 'demo1234', meeting_url: 'https://meet.google.com/vosca-demo-marie', tz: 'Europe/Paris', bio: '' }).body.teacher;
    const marieU = app.db().users[marie.id];
    call(marieU, 'POST', '/api/teach/profile', { headline: 'Французский для жизни и путешествий', headline_en: 'French for life and travel', teaches: 'Французский', speaks: 'Французский, английский, русский', country: 'Франция', years: 6,
      bio: 'Родом из Лиона. Объясняю грамматику простыми словами и много говорю с учениками с первого занятия: кафе, поездки, знакомства.', bio_en: 'From Lyon. I explain grammar in plain words and get students talking from the very first lesson: cafés, trips, meeting people.' });
    const louis = reg('Луи', 'louis@vosca.demo', 'VOSCA-DEMO-FREN');
    call(admin, 'POST', `/api/admin/users/${louis.id}/assign`, { course: 'fr', teacher: marie.id });
    call(marieU, 'POST', '/api/teach/sessions', { student: louis.id, course: 'fr', start: at(50 * hour), dur: 50, title: 'Знакомство и первые фразы' });
    /* материалы: от школы (админ), свои у преподавателя, один уже отправлен ученице */
    call(admin, 'POST', '/api/materials', { title: 'Тайский алфавит: 44 согласных по классам', course: 'thai', kind: 'link', url: 'https://www.thai-language.com/ref/consonants', desc: 'Шпаргалка по классам согласных — пригодится на первых уроках.', audience: 'teachers', teachers: [] });
    call(admin, 'POST', '/api/materials', { title: 'Правила работы с учеником (чек-лист урока)', course: '', kind: 'text', text: '1. Начните с 5 минут разговора.\n2. Одна новая тема за урок.\n3. В конце — мини-итог и домашнее задание.\n4. Отправьте ученику материал по теме урока.', audience: 'teachers', teachers: [] });
    call(admin, 'POST', '/api/materials', { title: 'Французский: артикли — коротко', course: 'fr', kind: 'text', text: 'le / la / les — определённые\nun / une / des — неопределённые\n\nle livre, la table, les enfants', audience: 'all', teachers: [] });
    const m1 = call(kimU, 'POST', '/api/materials', { title: 'Тоны тайского: 5 тонов с примерами', course: 'thai', kind: 'text', text: 'Средний: นา (na) — поле\nНизкий: หน่า (nà)\nПадающий: น่า (nâ)\nВысокий: น้า (ná)\nВосходящий: หน้า (nǎ) — лицо', desc: 'Короткая памятка для первого урока про тоны.' }).body;
    call(kimU, 'POST', '/api/materials', { title: 'Песни для разговорной практики', course: 'thai', kind: 'link', url: 'https://www.thai-language.com/', desc: 'Подборка для лёгкого аудирования.' });
    call(kimU, 'POST', `/api/materials/${m1.material ? m1.material.id : m1.id}/share`, { students: [anna.id], note: 'Посмотрите до пятницы — разберём на уроке' });
    call(admin, 'POST', '/api/admin/club/grant', { user: anna.id, days: 18, note: 'Оплата за 3 месяца' });
    call(admin, 'POST', '/api/admin/club/grant', { user: maria.id, days: 4, note: 'Пробный период' });
    const cl = call(nariU, 'POST', '/api/teach/club/sessions', { start: at(27 * hour), dur: 60, repeat: 4, lang: 'English', level: 'A2–B1', title: 'Small talk: знакомство и рассказ о себе' }).body;
    call(kimU, 'POST', '/api/teach/club/sessions', { start: at(52 * hour), dur: 60, lang: 'English', level: 'B1', title: 'Поездки и путешествия' });
    call(nariU, 'POST', '/api/teach/club/sessions', { start: at(76 * hour), dur: 45, lang: 'ไทย', level: 'A1', title: 'Тайский за кофе: заказ и вежливость' });
    call(nariU, 'POST', '/api/teach/club/link', { url: 'https://meet.google.com/vosca-club-demo' });
    call(anna, 'POST', `/api/club/${cl.created[0].id}/book`);
    call(anna, 'POST', '/api/live/request', { teacher: kim.id, course: 'thai', start: at(5 * 24 * hour + 3 * hour), dur: 50, note: 'Хочу потренировать заказ еды и торг на рынке' });
    app.db().invites['TEACH-DEMO-0001'] = { code: 'TEACH-DEMO-0001', role: 'teacher', max: 1000, used: 0, note: 'демо-приглашение', active: true, created: t, expires: t + 3650 * 864e5, by: admin.id, users: [] };
    app.db().invites['ADMIN-DEMO-0001'] = { code: 'ADMIN-DEMO-0001', role: 'admin', max: 1000, used: 0, note: 'демо-приглашение', active: true, created: t, expires: t + 3650 * 864e5, by: admin.id, users: [] };
    st.uid = null; app.tick(); flushMail(); save();
  }
  function flushMail() { app.pendingMail().forEach(m => app.mailDone(m.id, 'logged', 'Демо: письма не отправляются, но вы видите, какие ушли бы')); }
  if (!Object.keys(app.db().users || {}).length) seed();

  window.VOSCA_API = async (method, url, body) => {
    const [path, qs] = url.split('?'), query = Object.fromEntries(new URLSearchParams(qs || '').entries());
    const user = st.uid ? app.db().users[st.uid] : null;
    if (/^\/api\/admin\/(lessons|courses)/.test(path) && method === 'POST') { try { return await adminContent(method, path, body || {}, user); } catch (e) { console.error(e); return bad(500, 'Ошибка демо: ' + e.message); } }
    let r; try { r = app.handle({ method, path, query, body: body || {}, user: user || null, ip: 'demo', ua: 'demo' }); } catch (e) { console.error(e); return { status: 500, data: { error: 'Ошибка демо: ' + e.message } }; }
    if (r.login) st.uid = r.login; if (r.logout) st.uid = null;
    if (method !== 'GET') { app.tick(); flushMail(); }
    save(); return { status: r.status, data: r.body };
  };
  window.DEMO = {
    login(email) { const u = U(email); st.uid = u ? u.id : null; save(); },
    skew(ms) { st.skew += ms; app.tick(); flushMail(); save(); }, resetSkew() { st.skew = 0; save(); },
    tick() { const n = app.tick(); flushMail(); save(); return n; },
    reset() { try { localStorage.removeItem(KEY); sessionStorage.removeItem(KEY); } catch (e) { } try { indexedDB.deleteDatabase('vosca_demo'); } catch (e) { } location.hash = '#/'; setTimeout(() => location.reload(), 150); },
    skewMs: () => st.skew
  };
  setInterval(() => { if (window.DEMO.tick()) { try { window.V && V.S.user && V.refreshLive(); } catch (e) { } } }, 5000);
})();
