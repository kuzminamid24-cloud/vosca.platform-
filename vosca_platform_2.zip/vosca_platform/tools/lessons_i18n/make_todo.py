"""Замораживает список русских фраз для перевода (tools/lessons_i18n/todo.json) в естественном порядке чтения."""
import sys, re, json, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))
import spans
ORDER = ['prep-1', 'prep-2', 'prep-3', 'prep-4', 'prep-5', 'alphabet', 'grammar-1', 'grammar-2', 'grammar-3', 'grammar-4', 'grammar-5', 'grammar-6']
c = {}; first = {}
def add(x, k, pos):
    c.setdefault(x, set()).add(k)
    if x not in first or (ORDER.index(k), pos) < first[x]: first[x] = (ORDER.index(k), pos)
for k in spans.lesson_keys():
    t = (spans.LES / (k + '.html')).read_text(encoding='utf8')
    for s, e, x in spans.spans_of(t): add(x, k, s)
    j = json.loads((spans.LES / (k + '.json')).read_text(encoding='utf8'))
    def walk(o, pos=[10**9]):
        if isinstance(o, str):
            for s, e, x in spans.spans_of(o): pos[0] += 1; add(x, k, pos[0])
        elif isinstance(o, list): [walk(i) for i in o]
        elif isinstance(o, dict): [walk(v) for v in o.values()]
    walk(j.get('title', '')); walk(j.get('lead', '')); walk(j.get('bank', []))
tab = re.compile(r'[А-Яа-яёЁ̀-ͯ]{1,4}')
skip = lambda k: 'const ' in k or '.test(' in k or '=>' in k
todo = [k for k in c if not skip(k)]
shared = sorted([k for k in todo if len(c[k]) >= 10], key=lambda k: first[k])
rest = sorted([k for k in todo if len(c[k]) < 10], key=lambda k: first[k])
out = shared + rest
old = json.loads((pathlib.Path(__file__).parent / 'todo.json').read_text(encoding='utf8')) if (pathlib.Path(__file__).parent / 'todo.json').exists() else []
out = old + [k for k in out if k not in set(old)]       # уже переведённые номера не сдвигаются: новое — в конец
(pathlib.Path(__file__).parent / 'todo.json').write_text(json.dumps(out, ensure_ascii=False, indent=0), encoding='utf8')
print(len(out), 'фраз;', len(shared), 'общих;', sum(len(x.split()) for x in out), 'слов')
