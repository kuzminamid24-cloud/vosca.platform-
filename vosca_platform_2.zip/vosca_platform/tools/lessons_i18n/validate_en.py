"""Проверка EN-уроков: JS-синтаксис, остатки кириллицы, запуск в браузере, паритет банка вопросов с RU."""
import sys, re, json, subprocess, pathlib, tempfile
sys.path.insert(0, str(pathlib.Path(__file__).parent))
import spans
from playwright.sync_api import sync_playwright
LES = spans.LES; bad = 0
def scripts(h): return re.findall(r'<script(?![^>]*src)[^>]*>(.*?)</script>', h, flags=re.S)
with sync_playwright() as pw:
    br = pw.chromium.launch()
    for k in spans.lesson_keys():
        h = (LES / f'{k}.en.html').read_text(encoding='utf8')
        for i, s in enumerate(scripts(h)):
            f = pathlib.Path(tempfile.mkdtemp()) / 's.js'; f.write_text(s, encoding='utf8')
            r = subprocess.run(['node', '--check', str(f)], capture_output=True, text=True)
            if r.returncode: print(k, 'JS ошибка', r.stderr[:300]); bad += 1
        ru, en = json.loads((LES / f'{k}.json').read_text(encoding='utf8')), json.loads((LES / f'{k}.en.json').read_text(encoding='utf8'))
        if len(ru['bank']) != len(en['bank']): print(k, 'банк: разное число'); bad += 1
        for a, b in zip(ru['bank'], en['bank']):
            if a['id'] != b['id'] or a['a'] != b['a'] or len(a['opts']) != len(b['opts']): print(k, 'банк: расхождение', a['id']); bad += 1
        pg = br.new_page(); errs = []
        pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
        pg.goto('file://' + str(LES / f'{k}.en.html')); pg.wait_for_timeout(1500)
        txt = pg.evaluate("""()=>{const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);const o=[];let n;
          while(n=w.nextNode()){const p=n.parentElement;if(!p||['SCRIPT','STYLE'].includes(p.tagName))continue;
            if(p.closest('.tr-cyr'))continue;const s=n.nodeValue;if(/[А-Яа-яЁё]/.test(s))o.push(s.trim().slice(0,80));}return o}""")
        meta = pg.evaluate("()=>document.documentElement.lang+'|'+document.body.className")
        print(k, meta, 'ошибок JS:', len(errs), 'кириллица в DOM:', len(txt), txt[:6], errs[:3])
        bad += len(errs); pg.close()
    br.close()
print('ПРОБЛЕМ:', bad)
