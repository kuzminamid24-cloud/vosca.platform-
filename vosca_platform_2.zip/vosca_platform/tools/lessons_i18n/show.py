import json,sys,pathlib
T=json.loads((pathlib.Path(__file__).parent/'todo.json').read_text(encoding='utf8'))
a,b=int(sys.argv[1]),int(sys.argv[2])
for i in range(a,min(b,len(T))): print(f'{i}|{T[i]}')
