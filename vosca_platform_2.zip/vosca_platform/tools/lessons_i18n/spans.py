"""Общие функции: выделение русских фраз в уроках (html и банк вопросов)."""
import re, json, pathlib, glob
P = pathlib.Path(__file__).resolve().parent.parent.parent
LES = P / 'content' / 'lessons'
SPAN = re.compile(r"(?:[^'\"`<>{}\n$]|\$(?!\{))*[А-Яа-яЁё](?:[^'\"`<>{}\n$]|\$(?!\{))*")
def strip_assets(s):
    s = re.sub(r'data:[a-z/+\-0-9]+;base64,[A-Za-z0-9+/=]+', lambda m: m.group(0), s)
    return s
def mask_comments(s):
    """заменяет комментарии пробелами (длина сохраняется — удобно для замены по позициям)"""
    def blank(m): return re.sub(r'[^\n]', ' ', m.group(0))
    s = re.sub(r'/\*.*?\*/', blank, s, flags=re.S)
    s = re.sub(r'(?m)^[ \t]*//.*$', blank, s)
    s = re.sub(r'(?<=[\s;,)\]}])//(?![/*])[^\n]*', blank, s)             # хвостовые комментарии кода
    s = re.sub(r'<!--.*?-->', blank, s, flags=re.S)
    return s
CYR = re.compile(r'[А-Яа-яЁё]')
def spans_of(text):
    """[(start, end, stripped_text)] — построчно, строки без кириллицы пропускаются сразу (в файле есть огромные base64-строки)"""
    out = []; text = mask_comments(text); pos = 0
    for line in text.split('\n'):
        if CYR.search(line):
            for m in SPAN.finditer(line):
                raw = m.group(0); t = raw.strip()
                if t: out.append((pos + m.start() + (len(raw) - len(raw.lstrip())), pos + m.start() + len(raw.rstrip()), t))
        pos += len(line) + 1
    return out
def lesson_keys():
    return sorted(p.stem for p in LES.glob('*.html') if not p.stem.endswith('.en'))
def all_spans():
    cnt = {}
    for k in lesson_keys():
        for _, _, t in spans_of((LES / (k + '.html')).read_text(encoding='utf8')): cnt.setdefault(t, set()).add(k)
        j = json.loads((LES / (k + '.json')).read_text(encoding='utf8'))
        # банк и паспорт: строки значений
        def walk(o):
            if isinstance(o, str):
                for _, _, t in spans_of(o): cnt.setdefault(t, set()).add(k + '.json')
            elif isinstance(o, list):
                for x in o: walk(x)
            elif isinstance(o, dict):
                for v in o.values(): walk(v)
        walk(j.get('bank', [])); 
        for f in ('title', 'lead'): walk(j.get(f, ''))
    return cnt
if __name__ == '__main__':
    c = all_spans(); print(len(c))
