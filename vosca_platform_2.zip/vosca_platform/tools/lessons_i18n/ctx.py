import sys,json,re,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).parent)); import spans
T=json.loads((pathlib.Path(__file__).parent/'todo.json').read_text(encoding='utf8'))
for i in map(int,sys.argv[1:]):
    x=T[i]; n=0
    for k in spans.lesson_keys():
        t=(spans.LES/(k+'.html')).read_text(encoding='utf8'); p=t.find(x)
        if p>=0:
            print(f'--[{i}] {k}: ...{t[max(0,p-160):p+len(x)+120]!r}'); break
    else:
        for k in spans.lesson_keys():
            t=(spans.LES/(k+'.json')).read_text(encoding='utf8'); p=t.find(x)
            if p>=0: print(f'--[{i}] {k}.json: ...{t[max(0,p-160):p+len(x)+120]!r}'); break
