"""Собирает en/*.txt (строки «номер|перевод»), проверяет и пишет en.json (ru → en)."""
import json,re,sys,pathlib,glob
D=pathlib.Path(__file__).parent
T=json.loads((D/'todo.json').read_text(encoding='utf8'))
M={}
for f in sorted(glob.glob(str(D/'en'/'*.txt'))):
    for ln,line in enumerate(open(f,encoding='utf8'),1):
        line=line.rstrip('\n')
        if not line.strip(): continue
        i,_,en=line.partition('|')
        try: i=int(i)
        except: print('плохая строка',f,ln,line[:60]); continue
        if i in M: print('дубль',i,f)
        M[i]=en
bad=0
for i,en in M.items():
    ru=T[i]
    if en!='=' and re.search('[А-Яа-яЁё]',en): print('кириллица',i,ru[:40],'→',en[:60]); bad+=1
    if en=='=': continue
    for tok in re.findall(r'\d+|[🔊🐢🔍⚙👁🙈✓🎓🎉⏱⚡]',ru):
        if tok not in en: print('потерян токен',repr(tok),i,ru[:50],'→',en[:60]); bad+=1
    if "'" in en or '"' in en or '\\' in en or '<' in en or '`' in en: print('опасный символ',i,en[:80]); bad+=1
done=len(M); print(f'переведено {done} из {len(T)}; проблем {bad}')
json.dump({T[i]:en for i,en in M.items()},open(D/'en.json','w',encoding='utf8'),ensure_ascii=False,indent=0)
missing=[i for i in range(len(T)) if i not in M]
if missing: print('первый непереведённый',missing[0])
