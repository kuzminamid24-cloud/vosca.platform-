"""Собирает английские версии уроков: content/lessons/<key>.en.html и <key>.en.json из русских + en.json.
Запуск: python3 localize.py [ключ ...]"""
import sys, re, json, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))
import spans
EN = json.loads((pathlib.Path(__file__).parent / 'en.json').read_text(encoding='utf8'))
SHORT = {'и': 'and', 'к': 'k', 'т': 't', 'п': 'p', 'нг': 'ng', 'м': 'm', 'н': 'n', 'й': 'y', 'в': 'w', 'л': 'l', 'р': 'r', 'уу': 'uu', 'ам': 'am', 'аа': 'aa', 'ии': 'ii', 'ч': 'c'}
BAD = re.compile(r"""['"`<>{}\n]|\$\{""")

def apply(text, where, star=False):
    out = text
    for s, e, x in reversed(spans.spans_of(text)):
        if x not in EN:
            if 'const ' in x or '.test(' in x or '=>' in x: continue   # код, а не текст
            raise SystemExit(f'{where}: нет перевода для {x!r}')
        v = EN[x]
        if star and '*' + x in EN and EN['*' + x] != '=': v = EN['*' + x].lstrip('*')   # в HTML верный вариант записан как «*текст»: берём тот же перевод
        if v == '=' and len(x) <= 4 and (text[s - 1:s] in ' >}' or text[e:e + 1] in ' <{') and x in SHORT:
            v = SHORT[x]          # короткая кириллическая «метка» в тексте (м, нг, и…): в EN — латиницей / союз and
        if v == '=': continue
        if BAD.search(v): raise SystemExit(f'{where}: недопустимый символ в переводе {v!r}')
        out = out[:s] + v + out[e:]
    return out

def sub1(html, old, new, where, count=1, must=True):
    n = html.count(old)
    if must and n != count: raise SystemExit(f'{where}: ожидалось {count} вхождений {old!r}, найдено {n}')
    return html.replace(old, new)

def patch(html, key):
    w = key + '.html'
    html = sub1(html, "const t = p => Array.isArray(p) ? p[0] : p;", "const t = p => Array.isArray(p) ? p[1] : p;", w)
    html = sub1(html, "let LANG = 'ru';", "let LANG = 'en';", w)
    html = sub1(html, '<html lang="ru">', '<html lang="en">', w)
    html = sub1(html, '<body class="trm-cyr">', '<body class="trm-lat">', w)
    html = sub1(html, "eff() { return this.mode; },", "eff() { return 'lat'; },", w)
    # в английской версии кириллической транскрипции нет: прячем переключатель режимов
    html = sub1(html, "document.documentElement.lang = 'ru';", "document.documentElement.lang = 'en';", w)
    html = sub1(html, "toLocaleDateString('ru-RU'", "toLocaleDateString('en-GB'", w)
    m = spans.mask_comments(html)                                   # оставшиеся русские кавычки вне комментариев -> английские
    html = ''.join({'«': '“', '»': '”'}.get(c, c) if c in '«»' and m[i] == c else c for i, c in enumerate(html))
    # кириллические «подсказки звуков» в данных урока -> латиница (в EN-версии кириллицы быть не должно)
    ini = "{ k: 'k', kh: 'kh', ng: 'ng', c: 'c', ch: 'ch', s: 's', y: 'y', d: 'd', t: 't', th: 'th', n: 'n', b: 'b', p: 'p', ph: 'ph', f: 'f', m: 'm', r: 'r', l: 'l', w: 'w', h: 'h', '': '—' }"
    html = re.sub(r"const INI_RU = \{[^}]*\};", lambda m: 'const INI_RU = ' + ini + ';', html)
    html = re.sub(r"const FINRU = \{[^}]*\};", "const FINRU = { k: 'k', t: 't', p: 'p', n: 'n', m: 'm', ng: 'ng', i: 'y (i)', o: 'w (u)' };", html)
    html = re.sub(r"const FIN_ROWS = \[\[[^;]*\]\];", "const FIN_ROWS = [['k', 'k'], ['t', 't'], ['p', 'p'], ['n', 'n'], ['m', 'm'], ['y', 'y'], ['w', 'w'], ['ng', 'ng']];", html)
    html = re.sub(r"(lat: '([^']*)', len: '[a-z]', ru: ')[^']*'", lambda m: m.group(1).replace("ru: '", "ru: '") + m.group(2) + "'", html)
    html = html.replace("mark: 'а',", "mark: 'a',")
    html = html.replace("'และ': ['lɛ́', 'и']", "'และ': ['lɛ́', 'and']").replace("['{{และ}}', 'и', 'และ']", "['{{และ}}', 'and', 'และ']")
    html = sub1(html, '</head>', '<style>#trModeBtns{display:none!important}</style>\n</head>', w)
    return html

def walk(o, where):
    if isinstance(o, str): return apply(o, where, True)
    if isinstance(o, list): return [walk(i, where) for i in o]
    if isinstance(o, dict): return {k: walk(v, where) for k, v in o.items()}
    return o

def build(key):
    d = spans.LES
    html = (d / (key + '.html')).read_text(encoding='utf8')
    out = patch(apply(html, key + '.html'), key)
    (d / (key + '.en.html')).write_text(out, encoding='utf8')
    j = json.loads((d / (key + '.json')).read_text(encoding='utf8'))
    for f in ('title', 'lead'): j[f] = walk(j.get(f, ''), key + '.json:' + f)
    j['bank'] = walk(j.get('bank', []), key + '.json:bank')
    (d / (key + '.en.json')).write_text(json.dumps(j, ensure_ascii=False, indent=1), encoding='utf8')
    print(key, 'ok', len(out) // 1024, 'KB')

if __name__ == '__main__':
    for k in (sys.argv[1:] or spans.lesson_keys()): build(k)
