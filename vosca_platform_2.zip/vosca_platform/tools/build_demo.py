"""Собирает одиночный файл демо: клиент + ядро (shared/*.js) + контент.  Запуск: python3 tools/build_demo.py [выходной_файл]"""
import re, json, gzip, base64, pathlib, subprocess, sys
P = pathlib.Path(__file__).resolve().parent.parent; PUB = P / 'public'; T = P / 'tools'
rd = lambda p: pathlib.Path(p).read_text(encoding='utf8')
subprocess.run([sys.executable, str(T / 'build_dict.py')], check=True)
fonts = rd(PUB / 'fonts.css'); css = rd(PUB / 'base.css') + '\n' + rd(PUB / 'app.css')
logo = base64.b64encode((PUB / 'logo.png').read_bytes()).decode()
photos = {f.stem: 'data:image/png;base64,' + base64.b64encode(f.read_bytes()).decode() for f in sorted((T / 'demo_photos').glob('*.png'))}
# ядро — ровно те же файлы, что грузит сервер
shared = '\n'.join(rd(f) for f in sorted((P / 'shared').glob('[0-9]*_*.js')))
core_src = '(function(){' + shared + '\nreturn { createApp, adaptLesson, LEGAL_VERSION, LEGAL_DOCS, OP_FIELDS, HttpError };})()'
courses = json.loads(rd(P / 'content' / 'courses.json'))['courses']
lessons = {}; packed = {}
for j in sorted((P / 'content' / 'lessons').glob('*.json')):
    if j.name.endswith('.en.json'): continue
    d = json.loads(rd(j)); k = d['key']
    if not any(k in m['lessons'] for c in courses for m in c.get('modules', [])): continue
    lessons[k] = d
    html = re.sub(r'@font-face\{.*?\}', '', rd(P / 'content' / 'lessons' / (k + '.html')), flags=re.S)
    packed[k] = base64.b64encode(gzip.compress(html.encode('utf8'), 9)).decode()
# английские версии уроков: <ключ>.en.html + <ключ>.en.json (если есть)
lessons_en = {}; packed_en = {}
for j in sorted((P / 'content' / 'lessons').glob('*.en.json')):
    d = json.loads(rd(j)); k = d['key']
    if k not in lessons or not (P / 'content' / 'lessons' / (k + '.en.html')).exists(): continue
    lessons_en[k] = d
    html = re.sub(r'@font-face\{.*?\}', '', rd(P / 'content' / 'lessons' / (k + '.en.html')), flags=re.S)
    packed_en[k] = base64.b64encode(gzip.compress(html.encode('utf8'), 9)).decode()
scripts = ['app.js', 'app-learn.js', 'app-live.js', 'app-club.js', 'app-materials.js', 'app-admin.js']
i18n = [('i18n', rd(PUB / 'i18n.js')), ('dict', rd(PUB / 'i18n-dict.js'))]
client = {n: rd(PUB / n).replace('src="/logo.png"', 'src="${LOGO_URI}"').replace(' allow="autoplay; speech-synthesis"', '') for n in scripts}
data = 'window.DEMO_CONTENT=%s;\nwindow.DEMO_FONTS=%s;\nwindow.DEMO_LESSONS=%s;\nwindow.DEMO_LESSONS_EN=%s;\nwindow.DEMO_PHOTOS=%s;\nconst LOGO_URI="data:image/png;base64,%s";' % (
    json.dumps({'courses': courses, 'lessons': lessons, 'lessonsEn': lessons_en}, ensure_ascii=False), json.dumps(fonts), json.dumps(packed), json.dumps(packed_en), json.dumps(photos), logo)
parts = [('data', data), ('core', rd(PUB / 'core.js')), ('shared', 'window.VoscaCore=' + core_src + ';')] + i18n + [('pre', rd(T / 'demo-pre.js'))] + [(n, client[n]) for n in scripts] + [('post', rd(T / 'demo-post.js')), ('boot', rd(PUB / 'app-boot.js'))]
for n, s in parts: assert '</script' not in s, n
body = '\n'.join('<script>%s</script>' % s for _, s in parts)
html = f'''<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#F5F9FF">
<title>Vosca · Платформа (демо)</title>
<meta name="description" content="Демо платформы Vosca: курсы, уроки, домашние задания и расписание живых уроков">
<link rel="icon" href="data:image/png;base64,{logo}">
<style>{fonts}</style>
<style>{css}</style>
</head>
<body class="trm-cyr">
<canvas id="cfx"></canvas>
<div class="toast" id="toast"></div>
<header id="hdr"></header>
<div class="wrap" id="app"><div class="loading">Загружаем<span class="dots"></span></div></div>
<footer id="ftr"></footer>
<div id="modalRoot"></div>
{body}
</body>
</html>
'''
out = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else '/home/claude/Vosca_Platform_Demo.html'); out.write_text(html, encoding='utf8')
print(out, round(len(html) / 1e6, 2), 'MB')
