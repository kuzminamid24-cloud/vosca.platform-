"""Склеивает tools/dict/*.js в public/i18n-dict.js (словарь переводов RU → EN).  Запуск: python3 tools/build_dict.py"""
import pathlib
P = pathlib.Path(__file__).resolve().parent.parent
parts = sorted((P / 'tools' / 'dict').glob('[0-9]*.js'))
head = """/* Vosca · словарь переводов интерфейса. ФАЙЛ СОБИРАЕТСЯ из tools/dict/*.js командой `python3 tools/build_dict.py` — правьте исходники, а не его.
   Запись: ['русский текст', 'English']. В русском тексте: {1} — любой текст, {#1} — число, {u:день|дня|дней} — формы слова.
   В переводе: {1}, {2} — подстановки; вместо строки можно дать функцию (n, ...) => '...' (для множественного числа). */
(() => {
  'use strict';
  const dict = window.VOSCA_DICT = [];
  const D = (...entries) => { dict.push(...entries); };
  const pl = (n, one, many) => (+n === 1 ? one : many);       // английское множественное число
"""
body = '\n'.join('/* ── %s ── */\n%s' % (f.stem, f.read_text(encoding='utf8').strip()) for f in parts)
(P / 'public' / 'i18n-dict.js').write_text(head + body + '\n})();\n', encoding='utf8')
print('i18n-dict.js:', len(parts), 'частей')
