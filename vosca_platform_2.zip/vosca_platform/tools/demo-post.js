/* Демо-режим: уроки во фрейме, панель управления демо */
(() => {
  'use strict';
  const V = window.V, D = window.DEMO;
  const cache = {};
  async function unpack(key, en) {
    const ck = en ? key + '.en' : key; if (cache[ck]) return cache[ck];
    const bin = Uint8Array.from(atob((en ? window.DEMO_LESSONS_EN : window.DEMO_LESSONS)[key]), c => c.charCodeAt(0));
    const stream = new Blob([bin]).stream().pipeThrough(new DecompressionStream('gzip'));
    let html = await new Response(stream).text();
    html = html.replace('</head>', '<style>' + window.DEMO_FONTS + '</style></head>');
    return (cache[ck] = html);
  }
  V.mountLesson = async (fr, key) => {
    try {
      const en = VoscaI18n.lang === 'en', C = window.DEMO_CUSTOM_HTML;
      const html = (en && C[key + '.en']) || (en && window.DEMO_LESSONS_EN[key] && await unpack(key, true)) || C[key] || await unpack(key);
      if (document.getElementById('lessonFrame') === fr) fr.srcdoc = html;
    } catch (e) { fr.srcdoc = '<p style="font:16px sans-serif;padding:24px">Не удалось распаковать урок. Откройте файл в современном Chrome, Edge, Safari или Firefox.</p>'; }
  };

  const bar = document.createElement('div'); bar.id = 'demoBar';
  bar.style.cssText = 'position:fixed;left:0;right:0;bottom:0;z-index:70;background:#12213D;color:#fff;font:600 12.5px/1.4 system-ui,sans-serif;padding:8px 12px;display:flex;gap:8px 14px;align-items:center;justify-content:center;flex-wrap:wrap;text-align:center';
  const b = (id, t) => `<button data-d="${id}" style="font:inherit;font-weight:800;border:0;border-radius:999px;padding:4px 12px;cursor:pointer;background:#3B82F6;color:#fff">${t}</button>`;
  const g = (id, t) => `<button data-d="${id}" style="font:inherit;font-weight:800;border:0;border-radius:999px;padding:4px 12px;cursor:pointer;background:#fff;color:#12213D">${t}</button>`;
  function paint() {
    if (localStorage.getItem('vosca_demo_bar') === '0') { bar.innerHTML = '<button data-d="open" style="font:inherit;font-weight:800;border:0;border-radius:999px;padding:3px 12px;cursor:pointer;background:#3B82F6;color:#fff">🎛 Демо-панель</button>'; return; }
    const sk = D.skewMs(), label = sk ? ` · сдвиг времени: ${sk >= 864e5 ? Math.round(sk / 864e5 * 10) / 10 + ' дн.' : Math.round(sk / 6e4) + ' мин'}` : '';
    bar.innerHTML = `<span>ДЕМО · данные только в этом браузере${label}</span>
      <span>Войти как: ${b('anna', 'Ученик (тайский)')} ${b('louis', 'Ученик (французский)')} ${b('kim', 'Преподаватель (тайский)')} ${b('marie', 'Преподаватель (французский)')} ${b('admin', 'Админ')}</span>
      <span>Перемотать время: ${g('t30', '+30 мин')} ${g('t1d', '+1 день')} ${g('t0', 'сбросить')}</span>
      <span>Коды для регистрации: 🇹🇭 <b>VOSCA-DEMO-TEST</b> · 🇫🇷 <b>VOSCA-DEMO-FREN</b> · 🇬🇧 <b>VOSCA-DEMO-ENGL</b></span>${g('reset', 'Сбросить демо')} ${g('close', '▾')}`;
  }
  bar.addEventListener('click', e => {
    const k = e.target.closest('[data-d]'); if (!k) return; const a = k.dataset.d;
    const as = (email, hash) => { D.login(email + '@vosca.demo'); const S = V.S; S.user = null; S.ov = null; S.checked = false; S.needConsent = []; S.unread = 0; if (location.hash === hash) V.render(); else location.hash = hash; };
    if (a === 'anna') as('anna', '#/cabinet'); else if (a === 'kim') as('kim', '#/teach'); else if (a === 'admin') as('admin', '#/admin');
    else if (a === 't30' || a === 't1d') { D.skew(a === 't30' ? 30 * 6e4 : 864e5); V.S.ov = null; V.render(); toast('Время перемотано. Загляните в расписание, колокольчик и письма (админка).'); }
    else if (a === 't0') { D.resetSkew(); V.S.ov = null; V.render(); }
    else if (a === 'reset') { if (confirm('Удалить все демо-данные в этом браузере и начать заново?')) D.reset(); }
    else if (a === 'close') localStorage.setItem('vosca_demo_bar', '0'); else if (a === 'open') localStorage.setItem('vosca_demo_bar', '1');
    paint();
  });
  window.addEventListener('vosca-lang', paint);
  paint(); document.body.appendChild(bar); document.body.style.paddingBottom = '64px';
  window.addEventListener('hashchange', paint);
})();
