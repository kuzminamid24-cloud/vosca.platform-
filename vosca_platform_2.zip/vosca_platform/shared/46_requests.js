/* ═══════════ Запросы на урок: ученик предлагает время — преподаватель принимает или отклоняет ═══════════ */
const REQ_OPEN_MAX = 5;                            // сколько запросов может висеть у ученика одновременно
const REQ_MIN_AHEAD = HOUR;                        // раньше чем через час просить нельзя
const REQ_MAX_AHEAD = 60 * DAY;

function reqView(r, viewer) {
  const t = userById(r.teacher), st = userById(r.student), c = courseById(r.course);
  const v = { id: r.id, starts: r.starts, dur: r.dur, end: r.starts + r.dur * MIN, status: r.status, note: r.note || '', reason: r.reason || '', created: r.created,
    course: r.course, courseTitle: c ? c.title : r.course, teacher: { id: r.teacher, name: t ? t.name : '—', photo: photoSrc(r.teacher) } };
  if (viewer && viewer.id !== r.student) v.student = { id: r.student, name: st ? st.name : '—', email: st ? st.email : '', tz: tzOf(st) };
  return v;
}
function reqMail(title, body, label) {
  return { subject: title + ' — Vosca', html: mailLayout(title, body, { label, url: env.baseUrl() + '/#/' + (label === 'Открыть расписание' ? 'schedule' : 'teach') }), text: title };
}
function teacherBusy(teacherId, start, dur) {
  return overlaps(Object.values(db.live).filter(x => x.teacher === teacherId), start, dur) || overlaps(Object.values(db.club).filter(x => x.teacher === teacherId), start, dur);
}

function requestLesson(student, b) {
  if (student.role !== 'student') throw new HttpError(403, 'Запросить урок может ученик');
  const teacher = userById(+b.teacher);
  if (!teacher || !isTeacher(teacher) || !teacherVisible(teacher, student)) throw new HttpError(400, 'Выберите преподавателя');
  const course = courseById(str(b.course, 40)); if (!course) throw new HttpError(400, 'Выберите курс');
  if (!activeEnroll(student.id, course.id)) throw new HttpError(400, 'Сначала нужен доступ к этому курсу');
  if (!teachesCourse(teacher, course.id)) throw new HttpError(400, 'Этот преподаватель не ведёт выбранный язык — «' + course.title + '»');
  const start = Math.floor(Number(b.start)), dur = clampInt(b.dur, 50, 30, 90);
  if (!Number.isFinite(start) || start < now() + REQ_MIN_AHEAD) throw new HttpError(400, 'Выберите время хотя бы через час');
  if (start > now() + REQ_MAX_AHEAD) throw new HttpError(400, 'Слишком далеко вперёд — выберите дату в ближайшие два месяца');
  const open = Object.values(db.req).filter(r => r.student === student.id && r.status === 'pending');
  if (open.length >= REQ_OPEN_MAX) throw new HttpError(429, 'У вас уже ' + REQ_OPEN_MAX + ' ожидающих запросов — дождитесь ответа или отмените лишние');
  if (open.some(r => r.teacher === teacher.id && Math.abs(r.starts - start) < dur * MIN)) throw new HttpError(409, 'Вы уже отправили запрос на это время');
  if (overlaps(Object.values(db.live).filter(x => x.student === student.id), start, dur) || clubBusy(student.id, start, dur)) throw new HttpError(409, 'У вас в это время уже есть занятие');
  if (teacherBusy(teacher.id, start, dur)) throw new HttpError(409, 'У преподавателя это время занято — выберите другое');
  const r = { id: nextId('req'), student: student.id, teacher: teacher.id, course: course.id, starts: start, dur, note: str(b.note, 300), status: 'pending', created: now() };
  db.req[r.id] = r;
  const tz = tzOf(teacher), when = fmtDT(start, tz);
  notify(teacher.id, 'req_new', '🙋 Запрос на урок', `${student.name} · ${when}`, '#/teach',
    reqMail('Запрос на урок', `<p><b>${esc(student.name)}</b> просит урок: <b>${esc(when)}</b> (${dur} мин), ${esc(course.title)}.</p>${r.note ? `<p>Комментарий: ${esc(r.note)}</p>` : ''}<p>Примите или отклоните запрос в кабинете преподавателя.</p>`, 'Открыть кабинет'));
  return reqView(r, student);
}
function reqGet(id) { const r = db.req[+id]; if (!r) throw new HttpError(404, 'Запрос не найден'); return r; }
function requestCancel(student, id) {
  const r = reqGet(id); if (r.student !== student.id) throw new HttpError(403, 'Нет доступа');
  if (r.status !== 'pending') throw new HttpError(409, 'Запрос уже обработан');
  r.status = 'cancelled'; return reqView(r, student);
}
function requestAccept(actor, id, b) {
  const r = reqGet(id); if (actor.role !== 'admin' && r.teacher !== actor.id) throw new HttpError(403, 'Нет доступа');
  if (r.status !== 'pending') throw new HttpError(409, 'Запрос уже обработан');
  if (r.starts < now() + 5 * MIN) throw new HttpError(409, 'Это время уже прошло или слишком близко — отклоните запрос и предложите другое');
  const made = createSessions(actor, { teacher: r.teacher, student: r.student, course: r.course, start: r.starts, dur: r.dur, title: b && b.title, url: b && b.url }, { fromRequest: true });
  r.status = 'accepted'; r.live = made[0].id; return { request: reqView(r, actor), created: made };
}
function requestDecline(actor, id, reason) {
  const r = reqGet(id); if (actor.role !== 'admin' && r.teacher !== actor.id) throw new HttpError(403, 'Нет доступа');
  if (r.status !== 'pending') throw new HttpError(409, 'Запрос уже обработан');
  r.status = 'declined'; r.reason = str(reason, 200);
  const su = userById(r.student); if (su) {
    const when = fmtDT(r.starts, tzOf(su));
    notify(su.id, 'req_declined', '🙅 Запрос на урок отклонён', `${when}${r.reason ? ' · ' + r.reason : ''}`, '#/schedule',
      reqMail('Запрос на урок отклонён', `<p>Преподаватель <b>${esc(nameOf(r.teacher))}</b> не сможет провести урок <b>${esc(when)}</b>.</p>${r.reason ? `<p>Комментарий: ${esc(r.reason)}</p>` : ''}<p>Предложите другое время в расписании.</p>`, 'Открыть расписание'));
  }
  return reqView(r, actor);
}
/* что показать ученику на странице «Расписание» */
function reqExtras(u) {
  const mine = Object.values(db.req).filter(r => r.student === u.id && r.status !== 'cancelled').sort((a, b) => b.created - a.created).slice(0, 10);
  return { requests: mine.map(r => reqView(r, u)),
    reqTeachers: teachersList(u).map(t => ({ id: t.id, name: t.name, photo: t.photo, headline: t.headline, mine: t.mine, langs: t.langs.map(l => l.id) })),
    reqCourses: catalog().filter(c => activeEnroll(u.id, c.id)).map(c => ({ id: c.id, title: c.title })) };
}
/* что показать преподавателю на странице «Мои ученики» */
function teacherRequests(tid, actor) {
  return Object.values(db.req).filter(r => r.teacher === tid && r.status === 'pending' && r.starts > now()).sort((a, b) => a.starts - b.starts).map(r => reqView(r, actor));
}
function tickRequests() {
  const t = now(); let n = 0;
  Object.values(db.req).forEach(r => { if (r.status === 'pending' && r.starts < t) { r.status = 'expired'; n++; } });
  return n;
}
