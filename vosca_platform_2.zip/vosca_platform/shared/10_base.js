/* ═══════════ Ядро платформы Vosca: общий код сервера и демо-версии (без зависимостей) ═══════════
   Файлы shared/*.js склеиваются в одну область видимости. Хранилище (db), контент и окружение (env)
   подставляет оболочка: сервер Node.js или браузерное демо. */
'use strict';

class HttpError extends Error {
  constructor(status, msg, extra) { super(msg); this.status = status; this.extra = extra; }
}

const MIN = 60e3, HOUR = 3600e3, DAY = 864e5;
const EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/;

let db, content, env;                      // подставляются в createApp
const now = () => env.now();

function clampInt(v, d, lo, hi) { const n = Math.floor(Number(v)); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d; }
function shuffle(a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(env.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function str(v, max) { return String(v == null ? '' : v).trim().replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').slice(0, max || 500); }

/* ── часовые пояса ── */
function validTz(tz) { try { new Intl.DateTimeFormat('en', { timeZone: tz }); return typeof tz === 'string' && tz.length < 60; } catch (e) { return false; } }
function tzOf(u) { return u && validTz(u.tz) ? u.tz : 'Europe/Moscow'; }
function parts(ts, tz) {
  const f = new Intl.DateTimeFormat('en-CA', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const o = {}; f.formatToParts(new Date(ts)).forEach(p => { o[p.type] = p.value; });
  return { y: +o.year, m: +o.month, d: +o.day, h: +o.hour % 24, mi: +o.minute, s: +o.second };
}
function localDay(ts, tz) { const p = parts(ts, tz); return p.y + '-' + String(p.m).padStart(2, '0') + '-' + String(p.d).padStart(2, '0'); }
/* «настенное» время в поясе → момент в UTC */
function zonedToUtc(y, m, d, h, mi, tz) {
  let guess = Date.UTC(y, m - 1, d, h, mi);
  for (let i = 0; i < 3; i++) {
    const p = parts(guess, tz), asUtc = Date.UTC(p.y, p.m - 1, p.d, p.h, p.mi);
    const diff = Date.UTC(y, m - 1, d, h, mi) - asUtc;
    if (!diff) break; guess += diff;
  }
  return guess;
}
/* то же «настенное» время через n недель (учитывает переход на летнее время) */
function addWeeks(ts, tz, n) {
  const p = parts(ts, tz), d = new Date(Date.UTC(p.y, p.m - 1, p.d + 7 * n));
  return zonedToUtc(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate(), p.h, p.mi, tz);
}
function fmtDate(ts, tz) { return new Intl.DateTimeFormat('ru-RU', { timeZone: tz, weekday: 'long', day: 'numeric', month: 'long' }).format(new Date(ts)); }
function fmtTime(ts, tz) { return new Intl.DateTimeFormat('ru-RU', { timeZone: tz, hour: '2-digit', minute: '2-digit' }).format(new Date(ts)); }
function fmtDT(ts, tz) { return fmtDate(ts, tz) + ', ' + fmtTime(ts, tz) + ' (' + tzShort(ts, tz) + ')'; }
function tzShort(ts, tz) {
  try { const s = new Intl.DateTimeFormat('ru-RU', { timeZone: tz, timeZoneName: 'short' }).format(new Date(ts)); const m = s.match(/(GMT|UTC)[+\-−]?\d*(:\d+)?|МСК[+\-−]?\d*/); return m ? m[0] : tz; } catch (e) { return tz; }
}

/* безопасная ссылка на видеовстречу: только https */
function safeUrl(u) {
  u = str(u, 500); if (!u) return '';
  try { const x = new URL(u); if (x.protocol !== 'https:') return null; return x.href; } catch (e) { return null; }
}
function pubUser(u) { return u ? { id: u.id, name: u.name, email: u.email, role: u.role, tz: tzOf(u), photo: db.photos && db.photos[u.id] ? photoSrc(u.id) : '' } : null; }

/* ── хранилище: значения по умолчанию ── */
function initDb(d) {
  d.v = d.v || 1; d.seq = d.seq || {};
  ['users', 'enroll', 'progress', 'hw', 'codes', 'assign', 'live', 'notes', 'activity', 'ach', 'sessions', 'invites', 'photos', 'subs', 'club', 'req', 'materials', 'mfiles'].forEach(k => { d[k] = d[k] || {}; });
  ['consents', 'outbox', 'deletions'].forEach(k => { d[k] = d[k] || []; });
  d.settings = d.settings || {};
  d.settings.operator = d.settings.operator || {};
  return d;
}
function nextId(kind) { db.seq[kind] = (db.seq[kind] || 0) + 1; return db.seq[kind]; }
