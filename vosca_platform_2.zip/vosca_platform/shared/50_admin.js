/* ═══════════ Администрирование ═══════════ */

function adminUserRow(u) {
  const P = db.progress[u.id] || {}, H = db.hw[u.id] || {};
  const act = Object.keys(db.activity[u.id] || {}).sort();
  return { id: u.id, email: u.email, name: u.name, role: u.role, created_at: u.created, last_login: u.last, tz: tzOf(u),
    passed: Object.values(P).filter(x => x.passed_at).length, hw_done: Object.values(H).filter(x => x.status === 'done').length, hw_open: Object.values(H).filter(x => x.status === 'new').length,
    xp: Object.values(P).reduce((a, x) => a + x.xp, 0), courses: [...enrolledSet(u.id)], langs: u.langs || [], lastDay: act[act.length - 1] || null, ads: adsConsent(u.id) };
}
function adminUsers() {
  const users = Object.values(db.users).sort((a, b) => b.id - a.id).map(adminUserRow), week = now() - 7 * DAY;
  const students = users.filter(u => u.role === 'student');
  return { users, totals: { users: students.length, teachers: users.filter(u => u.role === 'teacher').length, active7: students.filter(x => x.last_login > week).length,
    passed: students.reduce((a, x) => a + x.passed, 0), hwDone: students.reduce((a, x) => a + x.hw_done, 0) },
    courses: catalog().map(c => ({ id: c.id, title: c.title, flag: c.flag, ready: c.ready })), teachers: users.filter(u => u.role === 'teacher' || u.role === 'admin').map(u => ({ id: u.id, name: u.name, langs: u.langs || [] })) };
}
function adminUserDetail(id) {
  const t = userById(+id); if (!t) throw new HttpError(404, 'Нет такого пользователя');
  const enroll = Object.keys(db.enroll[t.id] || {}).map(cid => { const r = db.enroll[t.id][cid]; return { course: cid, since: r.since, expires: r.expires, source: r.source, active: !!activeEnroll(t.id, cid) }; });
  const assign = Object.keys(db.assign[t.id] || {}).map(cid => ({ course: cid, teacher: db.assign[t.id][cid], teacherName: nameOf(db.assign[t.id][cid]) }));
  const consents = !CFG.LEGAL ? [] : ['offer', 'consent-pd', 'consent-ads'].map(d => { const c = currentConsent(t.id, d); return { doc: d, title: LEGAL_DOCS[d].title, accepted: !!(c && c.accepted), version: c ? c.version : null, at: c ? c.at : null }; });
  return Object.assign({ user: Object.assign(pubUser(t), { meeting_url: t.meeting_url || '', bio: t.bio || '', langs: t.langs || [] }), created_at: t.created, last_login: t.last, enroll, assign, consents, profile: isTeacher(t) ? profileEdit({ role: 'admin' }, t.id) : null, clubHist: ((db.subs[t.id] || {}).hist || []).slice(-8).reverse().map(h => ({ at: h.at, act: h.act, until: h.until, by: h.by ? nameOf(h.by) : 'код' })) }, overview(t.id));
}
function adminCreateTeacher(b) {
  const name = str(b.name, 60), email = str(b.email, 200).toLowerCase(), pw = String(b.password || '');
  if (!name) throw new HttpError(400, 'Введите имя'); if (!EMAIL_RE.test(email)) throw new HttpError(400, 'Проверьте email');
  if (pw.length < 8) throw new HttpError(400, 'Пароль — не короче 8 символов');
  if (userByEmail(email)) throw new HttpError(409, 'Этот email уже зарегистрирован');
  const url = b.meeting_url ? safeUrl(b.meeting_url) : '';
  if (url === null) throw new HttpError(400, 'Ссылка на встречу должна начинаться с https://');
  const langs = normLangs(b.langs); if (!langs.length) throw new HttpError(400, 'Отметьте хотя бы один язык, который ведёт преподаватель');
  const u = createUser({ name, email, password: pw, tz: b.tz, role: 'teacher' }); u.meeting_url = url || ''; u.bio = str(b.bio, 400); u.langs = langs;
  recordConsent(u.id, 'offer', 1, '', 'admin-created'); recordConsent(u.id, 'consent-pd', 1, '', 'admin-created');
  return pubUser(u);
}
function adminSetRole(uid, role) {
  const u = userById(uid); if (!u) throw new HttpError(404, 'Нет такого пользователя');
  if (!['student', 'teacher'].includes(role)) throw new HttpError(400, 'Недопустимая роль'); if (u.role === 'admin') throw new HttpError(400, 'Роль администратора меняется только через настройки сервера');
  u.role = role;
}
function adminSetLangs(uid, list) {
  const u = userById(uid); if (!u || u.role !== 'teacher') throw new HttpError(400, 'Языки задаются только преподавателю');
  const langs = normLangs(list); if (!langs.length) throw new HttpError(400, 'Отметьте хотя бы один язык');
  u.langs = langs;
}
function adminAssign(uid, cid, teacherId) {
  const s = userById(uid); if (!s) throw new HttpError(404, 'Нет такого ученика');
  db.assign[uid] = db.assign[uid] || {};
  if (!teacherId) { delete db.assign[uid][cid]; return; }
  const t = userById(+teacherId); if (!t || !isTeacher(t)) throw new HttpError(400, 'Выберите преподавателя');
  if (!teachesCourse(t, cid)) throw new HttpError(400, 'Этот преподаватель не ведёт выбранный язык');
  db.assign[uid][cid] = t.id;
  notify(uid, 'teacher', `Ваш преподаватель — ${t.name}`, (courseById(cid) || {}).title || '', '#/schedule');
}
function adminPassUpTo(uid, key) {
  const hit = lessonHit(key); if (!hit) throw new HttpError(404, 'Урок не найден');
  if (!activeEnroll(uid, hit.course.id)) grantCourse(uid, hit.course.id, null, 'admin');
  const P = (db.progress[uid] = db.progress[uid] || {});
  for (const l of hit.course.lessons) {
    if (l.index > hit.lesson.index) break;
    const pv = P[l.key]; if (pv && pv.passed_at) continue;
    P[l.key] = { done: l.tasks, total: l.tasks, accuracy: pv ? pv.accuracy : 100, best_accuracy: pv ? pv.best_accuracy : 100, xp: pv ? pv.xp : 0, seconds: pv ? pv.seconds : 0, attempts: pv ? pv.attempts : 0, passed_at: now(), manual: 1, updated: now() };
    createHomework(uid, l.key);
  }
}
function adminReset(uid, key) {
  const hit = lessonHit(key); if (!hit) throw new HttpError(404, 'Урок не найден');
  hit.course.lessons.forEach(l => { if (l.index >= hit.lesson.index) { if (db.progress[uid]) delete db.progress[uid][l.key]; if (db.hw[uid]) delete db.hw[uid][l.key]; } });
}
function adminCodes() {
  return Object.values(db.codes).sort((a, b) => b.created - a.created).slice(0, 300).map(c => ({ code: c.code, course: c.course, courseTitle: c.course === CLUB_CODE ? 'Разговорный клуб' : (courseById(c.course) || {}).title || c.course, days: c.days, max: c.max, used: c.used, note: c.note, active: c.active, created: c.created, teacherName: c.teacher ? nameOf(c.teacher) : '' }));
}
function adminCreateCodes(actor, b) {
  const isClub = str(b.course, 40) === CLUB_CODE, course = isClub ? { id: CLUB_CODE } : courseById(str(b.course, 40));
  if (!course) throw new HttpError(400, 'Выберите язык');
  if (isClub && !clampInt(b.days, 0, 1, 3650)) throw new HttpError(400, 'Для подписки на клуб укажите срок в днях');
  const days = b.days ? clampInt(b.days, 0, 1, 3650) : null, count = clampInt(b.count, 1, 1, 100), max = clampInt(b.max, 1, 1, 10000), note = str(b.note, 100);
  let teacher = 0; if (b.teacher && !isClub) { const tu = userById(+b.teacher); if (!tu || !isTeacher(tu)) throw new HttpError(400, 'Выберите преподавателя'); if (!teachesCourse(tu, course.id)) throw new HttpError(400, 'Этот преподаватель не ведёт выбранный язык'); teacher = tu.id; }
  const out = [];
  for (let i = 0; i < count; i++) { let code; do { code = makeCode(); } while (db.codes[code]); db.codes[code] = { code, course: course.id, days, max, used: 0, note, active: true, created: now(), by: actor.id, users: [], teacher }; out.push(code); }
  return out;
}
/* ── приглашения для сотрудников: админ выдаёт код → преподаватель (или админ) регистрируется сам ── */
const INVITE_PREFIX = { teacher: 'TEACH', admin: 'ADMIN' };
const WRONG_PORTAL = { student: 'Это аккаунт ученика — войдите через вход для учеников', teacher: 'Это аккаунт преподавателя — войдите через вход для преподавателей', admin: 'Это аккаунт администратора — войдите через вход для администраторов' };
function makeInviteCode(role) {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let s = '';
  for (let i = 0; i < 8; i++) s += A[Math.floor(env.random() * A.length)];
  return INVITE_PREFIX[role] + '-' + s.slice(0, 4) + '-' + s.slice(4);
}
function adminCreateInvites(actor, b) {
  const role = str(b.role, 20); if (!INVITE_PREFIX[role]) throw new HttpError(400, 'Выберите, кого приглашаете');
  const langs = role === 'teacher' ? normLangs(b.langs) : []; if (role === 'teacher' && !langs.length) throw new HttpError(400, 'Отметьте хотя бы один язык, который будет вести преподаватель');
  const count = clampInt(b.count, 1, 1, 50), days = clampInt(b.days, 14, 1, 90), max = role === 'admin' ? 1 : clampInt(b.max, 1, 1, 100), note = str(b.note, 100), out = [];
  for (let i = 0; i < count; i++) { let code; do { code = makeInviteCode(role); } while (db.invites[code]); db.invites[code] = { code, role, max, used: 0, note, active: true, created: now(), expires: now() + days * 864e5, by: actor.id, users: [], langs }; out.push(code); }
  return out;
}
function inviteState(i) { return !i.active ? 'off' : i.used >= i.max ? 'used' : i.expires < now() ? 'expired' : 'active'; }
function adminInvites() {
  return Object.values(db.invites).sort((a, b) => b.created - a.created).slice(0, 200).map(i => ({ code: i.code, role: i.role, max: i.max, used: i.used, note: i.note, state: inviteState(i), langs: (i.langs || []).map(id => (courseById(id) || {}).title || id), created: i.created, expires: i.expires, users: (i.users || []).map(id => (userById(id) || {}).name).filter(Boolean) }));
}
function inviteLookup(raw) {
  const code = normCode(raw), inv = db.invites[code];
  if (!inv || !inv.active) throw new HttpError(404, 'Код приглашения не найден или уже не действует');
  if (inv.used >= inv.max) throw new HttpError(409, 'Это приглашение уже использовано');
  if (inv.expires < now()) throw new HttpError(410, 'Срок действия приглашения закончился — попросите новое');
  return inv;
}
function staffRegister(b, ip, ua) {
  const inv = inviteLookup(b.code), c = b.consents || {};
  const name = str(b.name, 60).replace(/\s+/g, ' '), email = str(b.email, 250).toLowerCase(), pw = String(b.password || '');
  if (name.length < 1) throw new HttpError(400, 'Введите имя');
  if (!EMAIL_RE.test(email)) throw new HttpError(400, 'Проверьте email');
  if (pw.length < 8 || pw.length > 200) throw new HttpError(400, 'Пароль — не короче 8 символов');
  if (CFG.LEGAL && !(c.offer && c.pd && c.age)) throw new HttpError(400, 'Отметьте обязательные согласия');
  if (userByEmail(email)) throw new HttpError(409, 'Этот email уже зарегистрирован — войдите');
  const u = createUser({ name, email, password: pw, tz: b.tz, role: inv.role }); if (inv.role === 'teacher' && inv.langs && inv.langs.length) u.langs = inv.langs.slice();
  recordConsent(u.id, 'offer', 1, ip, ua); recordConsent(u.id, 'consent-pd', 1, ip, ua); recordConsent(u.id, 'age', 1, ip, ua, '1');
  inv.used++; inv.users = (inv.users || []).concat(u.id); touch(u.id);
  notify(u.id, 'welcome', '👋 Добро пожаловать в команду Vosca!', inv.role === 'admin' ? 'Админка — в верхнем меню' : 'Ваши языки: ' + langTitles(u).map(l => l.title).join(', ') + '. Заполните профиль и ссылку на комнату видеовстреч', inv.role === 'admin' ? '#/admin' : '#/profile');
  if (inv.by && userById(inv.by)) notify(inv.by, 'staff', `${u.name} присоединился(лась) как ${inv.role === 'admin' ? 'администратор' : 'преподаватель'}`, inv.note || '', '#/admin/user/' + u.id);
  return u;
}
function adminSessions() {
  const t = now(), all = Object.values(db.live).sort((a, b) => a.starts - b.starts);
  const view = s => Object.assign(sessionView(s, { id: 0 }), { teacherId: s.teacher, studentName: nameOf(s.student), studentId: s.student });
  return { now: t, upcoming: all.filter(s => s.status === 'planned' && sessionEnd(s) > t - 2 * HOUR).map(view), recent: all.filter(s => !(s.status === 'planned' && sessionEnd(s) > t - 2 * HOUR)).slice(-40).reverse().map(view) };
}
function adminOutbox() {
  return db.outbox.slice(-80).reverse().map(m => ({ id: m.id, to: m.to, subject: m.subject, status: m.status, error: m.error || '', created: m.created, sent: m.sent || null }));
}
function adminSettings(b) {
  if (b) {
    const o = db.settings.operator = db.settings.operator || {};
    OP_FIELDS.forEach(f => { if (b[f[0]] !== undefined) o[f[0]] = str(b[f[0]], 300); });
  }
  return { fields: OP_FIELDS.map(f => ({ key: f[0], label: f[1], value: str((db.settings.operator || {})[f[0]], 300) })), missing: operatorMissing(), version: LEGAL_VERSION };
}

/* ── аккаунт пользователя: выгрузка и удаление данных ── */
function exportData(uid) {
  const u = userById(uid);
  return { exportedAt: new Date(now()).toISOString(), profile: { name: u.name, email: u.email, tz: tzOf(u), registered: new Date(u.created).toISOString() },
    courses: db.enroll[uid] || {}, progress: db.progress[uid] || {}, homework: Object.fromEntries(Object.entries(db.hw[uid] || {}).map(([k, h]) => [k, { status: h.status, best: h.best, attempts: h.attempts }])),
    clubSubscription: db.subs[uid] ? { since: new Date(db.subs[uid].since).toISOString(), until: db.subs[uid].until ? new Date(db.subs[uid].until).toISOString() : null } : null,
    clubSessions: Object.values(db.club).filter(s => s.members.includes(uid)).map(s => ({ starts: new Date(s.starts).toISOString(), title: s.title, status: s.status })),
    liveSessions: Object.values(db.live).filter(s => s.student === uid).map(s => ({ starts: new Date(s.starts).toISOString(), title: s.title, status: s.status, note: s.note })),
    consents: db.consents.filter(c => c.uid === uid).map(c => ({ doc: c.doc, version: c.version, accepted: !!c.accepted, at: new Date(c.at).toISOString() })), achievements: db.ach[uid] || {} };
}
