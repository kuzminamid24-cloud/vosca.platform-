/* ═══════════ Каталог, доступ, прогресс, ДЗ, достижения, уведомления, письма ═══════════ */

/* язык текущего запроса (уроки и вопросы ДЗ отдаются на языке интерфейса; нет перевода — по-русски) */
let LANG = 'ru';
const CFG = {
  PASS_SCORE: 80, HW_SIZE: 8, HW_PASS: 70, MIN_LESSON_SECONDS: 90, AUTO_ENROLL: [],
  LEGAL: true          // false — «чистое демо»: без оферты, согласий и журнала согласий (см. README)
};

/* ── каталог курсов ── */
let _cats = {}, _catVer = null, _lidxs = {};          // каталог хранится по языкам интерфейса: названия уроков берутся из их переводов
function catalog() {
  const ver = content.version(), lg = LANG;
  if (_catVer !== ver) { _cats = {}; _lidxs = {}; _catVer = ver; }
  if (_cats[lg]) return _cats[lg];
  const _lidx = _lidxs[lg] = {};
  return _cats[lg] = content.courses().map(c => {
    const course = Object.assign({}, c, { lessons: [] });
    (c.modules || []).forEach(m => (m.lessons || []).forEach(key => {
      const x = content.meta(key, lg); if (!x) return;
      const l = { key, module: m.id, index: course.lessons.length, title: x.title, th: x.th, min: x.min, tasks: x.tasks, lead: x.lead };
      course.lessons.push(l); _lidx[key] = { course, lesson: l };
    }));
    return course;
  });
}
function courseById(id) { return catalog().find(c => c.id === id) || null; }
function lessonHit(key) { catalog(); return _lidxs[LANG][key] || null; }

/* ── пользователи ── */
function userById(id) { return db.users[id] || null; }
function userByEmail(email) { email = String(email || '').toLowerCase(); for (const id in db.users) if (db.users[id].email === email) return db.users[id]; return null; }
function createUser({ name, email, password, tz, role }) {
  const id = nextId('user');
  const u = { id, email: email.toLowerCase(), name, hash: env.hashPassword(password), role: role || 'student', created: now(), last: now(), tz: validTz(tz) ? tz : 'Europe/Moscow',
    notify: 1, meeting_url: '', bio: '', cal: env.token(18) };
  db.users[id] = u; return u;
}
function wipeUser(uid) {
  ['enroll', 'progress', 'hw', 'assign', 'notes', 'activity', 'ach', 'photos', 'subs'].forEach(k => { delete db[k][uid]; });
  Object.keys(db.req).forEach(id => { const r = db.req[id]; if (r.student === uid || r.teacher === uid) delete db.req[id]; });
  Object.keys(db.materials).forEach(id => { const m = db.materials[id]; if (m.owner === uid) { delete db.materials[id]; delete db.mfiles[id]; } else { m.shares = (m.shares || []).filter(x => x.uid !== uid && x.by !== uid); m.teachers = (m.teachers || []).filter(x => x !== uid); } });
  Object.keys(db.club).forEach(id => { const s = db.club[id]; if (s.teacher === uid) delete db.club[id]; else s.members = s.members.filter(x => x !== uid); });
  Object.keys(db.live).forEach(id => { const s = db.live[id]; if (s.student === uid) delete db.live[id]; else if (s.teacher === uid) { s.status = 'cancelled'; s.reason = 'Преподаватель удалил аккаунт'; } });
  db.consents.forEach(c => { if (c.uid === uid) { c.ip = ''; c.ua = ''; c.anon = 1; } });          // обезличиваем, оставляя факт согласия
  db.outbox = db.outbox.filter(m => m.uid !== uid);
  Object.keys(db.sessions).forEach(h => { if (db.sessions[h].uid === uid) delete db.sessions[h]; });
  Object.keys(db.assign).forEach(sid => Object.keys(db.assign[sid]).forEach(c => { if (db.assign[sid][c] === uid) delete db.assign[sid][c]; }));
  delete db.users[uid];
  db.deletions.push({ at: now() });
}

/* ── доступ к курсам ── */
function enrollRec(uid, cid) { return (db.enroll[uid] || {})[cid] || null; }
function activeEnroll(uid, cid) { const r = enrollRec(uid, cid); return r && (!r.expires || r.expires > now()) ? r : null; }
function enrolledSet(uid) { const s = new Set(); Object.keys(db.enroll[uid] || {}).forEach(c => { if (activeEnroll(uid, c)) s.add(c); }); return s; }
function grantCourse(uid, cid, days, source) {
  const c = courseById(cid); if (!c) return false;                  // доступ можно выдать на любой язык школы, даже если уроков в платформе ещё нет — занятия идут с преподавателем
  db.enroll[uid] = db.enroll[uid] || {};
  const cur = activeEnroll(uid, cid);
  let expires = null;
  if (days) { const base = cur && cur.expires ? cur.expires : now(); expires = base + days * DAY; }
  if (cur && !cur.expires && days) expires = null;          // бессрочный доступ не сокращаем
  db.enroll[uid][cid] = { since: cur ? cur.since : now(), expires, source: source || 'admin' };
  return true;
}
function revokeCourse(uid, cid) { if (db.enroll[uid]) delete db.enroll[uid][cid]; }

/* ── уведомления и письма ── */
function mailLayout(title, bodyHtml, cta) {
  const base = env.baseUrl();
  return `<!doctype html><html><body style="margin:0;background:#F5F9FF;font-family:Arial,Helvetica,sans-serif;color:#12213D">
<div style="max-width:560px;margin:0 auto;padding:24px 16px"><div style="font-size:22px;font-weight:900;color:#1D4ED8;margin-bottom:14px">Vosca</div>
<div style="background:#fff;border:2px solid #CBDFFA;border-radius:18px;padding:24px">
<h1 style="font-size:20px;margin:0 0 12px">${esc(title)}</h1>${bodyHtml}
${cta ? `<p style="margin:22px 0 4px"><a href="${esc(cta.url)}" style="display:inline-block;background:#3B82F6;color:#fff;text-decoration:none;font-weight:700;padding:12px 22px;border-radius:999px">${esc(cta.label)}</a></p>` : ''}
</div><p style="font-size:12px;color:#8397B5;margin-top:14px">Это служебное письмо платформы Vosca. Отключить письма об уроках можно в профиле: <a href="${esc(base)}/#/profile" style="color:#8397B5">${esc(base)}</a></p></div></body></html>`;
}
function queueMail(uid, to, subject, text, html) {
  db.outbox.push({ id: nextId('mail'), uid: uid || 0, to, subject, text, html, status: 'queued', tries: 0, created: now() });
  if (db.outbox.length > 3000) db.outbox.splice(0, db.outbox.length - 3000);
}
/* kind: тип; mail: {subject, html, text} — отправляется, если у пользователя включены письма */
function notify(uid, kind, title, body, link, mail) {
  const u = userById(uid); if (!u) return;
  const list = (db.notes[uid] = db.notes[uid] || []);
  list.unshift({ id: nextId('note'), kind, title: str(title, 160), body: str(body, 400), link: link || '', at: now(), read: 0 });
  if (list.length > 100) list.length = 100;
  if (mail && u.notify !== 0) queueMail(uid, u.email, mail.subject, mail.text || title, mail.html);
}
function unreadCount(uid) { return (db.notes[uid] || []).filter(n => !n.read).length; }

/* ── активность, серия дней, достижения ── */
function touch(uid) {
  const u = userById(uid); if (!u) return;
  const a = (db.activity[uid] = db.activity[uid] || {});
  a[localDay(now(), tzOf(u))] = 1;
  const keys = Object.keys(a).sort(); if (keys.length > 400) keys.slice(0, keys.length - 400).forEach(k => delete a[k]);
}
function streakOf(uid) {
  const u = userById(uid), a = db.activity[uid] || {}, tz = tzOf(u);
  let t = now(), n = 0;
  if (!a[localDay(t, tz)]) t -= DAY;                         // сегодня ещё не занимались — серия не обрывается до конца дня
  while (a[localDay(t, tz)]) { n++; t -= DAY; }
  return { days: n, today: !!a[localDay(now(), tz)] };
}
const ACH = [
  { id: 'first', emoji: '🌱', title: 'Первый шаг', desc: 'Пройден первый урок', test: s => s.passed >= 1 },
  { id: 'five', emoji: '🚀', title: 'Разгон', desc: 'Пройдено 5 уроков', test: s => s.passed >= 5 },
  { id: 'hw', emoji: '📝', title: 'Прилежный ученик', desc: 'Сдано первое домашнее задание', test: s => s.hwDone >= 1 },
  { id: 'ace', emoji: '🎯', title: 'В яблочко', desc: 'ДЗ на 100%', test: s => s.hwAce },
  { id: 'alpha', emoji: '🔤', title: 'Покоритель алфавита', desc: 'Пройден урок «Алфавит»', test: s => s.keys.has('alphabet') },
  { id: 'streak3', emoji: '🔥', title: 'Три дня подряд', desc: 'Серия занятий — 3 дня', test: s => s.streak >= 3 },
  { id: 'streak7', emoji: '⚡', title: 'Неделя без пропусков', desc: 'Серия занятий — 7 дней', test: s => s.streak >= 7 },
  { id: 'live', emoji: '🎥', title: 'Живой урок', desc: 'Проведён первый урок с преподавателем', test: s => s.liveDone >= 1 },
  { id: 'course', emoji: '🏆', title: 'Курс пройден', desc: 'Пройдены все уроки курса', test: s => s.courseDone }
];
function statsFor(uid) {
  const P = db.progress[uid] || {}, H = db.hw[uid] || {}, keys = new Set(Object.keys(P).filter(k => P[k].passed_at));
  let courseDone = false;
  catalog().forEach(c => { if (c.ready && c.lessons.length && activeEnroll(uid, c.id) && c.lessons.every(l => keys.has(l.key))) courseDone = true; });
  return { passed: keys.size, keys, hwDone: Object.values(H).filter(h => h.status === 'done').length, hwAce: Object.values(H).some(h => h.best === 100),
    streak: streakOf(uid).days, liveDone: Object.values(db.live).filter(s => s.student === uid && s.status === 'done').length, courseDone };
}
function evalAch(uid) {
  const earned = (db.ach[uid] = db.ach[uid] || {}), s = statsFor(uid), fresh = [];
  ACH.forEach(a => { if (!earned[a.id] && a.test(s)) { earned[a.id] = now(); fresh.push(a); } });
  fresh.forEach(a => notify(uid, 'achievement', `${a.emoji} Достижение: ${a.title}`, a.desc, '#/cabinet'));
  return fresh;
}
function achievementsView(uid) {
  const earned = db.ach[uid] || {};
  return ACH.map(a => ({ id: a.id, emoji: a.emoji, title: a.title, desc: a.desc, at: earned[a.id] || null }));
}

/* ── вид курса для ученика ── */
function ctxOf(uid) { return { enrolled: enrolledSet(uid), progress: db.progress[uid] || {}, hw: db.hw[uid] || {} }; }
function courseView(uid, course, ctx) {
  const en = ctx.enrolled.has(course.id), rec = enrollRec(uid, course.id);
  const base = { id: course.id, title: course.title, native: course.native, flag: course.flag, ready: course.ready, about: course.about, buyUrl: course.buyUrl || '', enrolled: en,
    expired: !!(rec && !en), expires: en && rec ? rec.expires : (rec ? rec.expires : null), total: course.lessons.length };
  if (!course.ready) return base;
  let passed = 0, prev = true;
  const lessons = course.lessons.map((l, i) => {
    const p = ctx.progress[l.key], h = ctx.hw[l.key], isP = !!(p && p.passed_at);
    let status = isP ? 'passed' : (i === 0 || prev) ? 'open' : 'locked';
    if (!en) status = 'locked'; if (isP) passed++; prev = isP;
    return { key: l.key, index: i, module: l.module, title: l.title, th: l.th, min: l.min, tasks: l.tasks, lead: l.lead, status,
      done: p ? p.done : 0, accuracy: p ? p.accuracy : 0, best: p ? p.best_accuracy : 0, attempts: p ? p.attempts : 0, passedAt: p ? p.passed_at : null, manual: !!(p && p.manual),
      hw: h ? { status: h.status, score: h.score, best: h.best, attempts: h.attempts, size: h.qids.length } : null };
  });
  return Object.assign(base, { modules: (course.modules || []).map(m => ({ id: m.id, title: m.title })), lessons, passed, percent: course.lessons.length ? Math.round(passed / course.lessons.length * 100) : 0 });
}

function overview(uid) {
  const u = userById(uid), ctx = ctxOf(uid), courses = catalog().map(c => courseView(uid, c, ctx));
  let cont = null;
  for (const c of courses) { if (!c.enrolled || !c.lessons) continue; const l = c.lessons.find(x => x.status === 'open'); if (l) { cont = { course: c.id, lesson: l.key, title: l.title, index: l.index + 1 }; break; } }
  const pendingHw = [];
  courses.forEach(c => (c.lessons || []).forEach(l => { if (l.hw && l.hw.status === 'new') pendingHw.push({ course: c.id, lesson: l.key, title: l.title, size: l.hw.size, attempts: l.hw.attempts }); }));
  const P = Object.values(ctx.progress);
  const st = { xp: P.reduce((a, p) => a + p.xp, 0), lessonsPassed: P.filter(p => p.passed_at).length, hwDone: Object.values(ctx.hw).filter(h => h.status === 'done').length, minutes: Math.round(P.reduce((a, p) => a + p.seconds, 0) / 60) };
  const streak = streakOf(uid);
  const hasLive = Object.values(db.live).some(s => s.student === uid && s.status !== 'cancelled');
  const checklist = [
    { id: 'reg', title: 'Создать аккаунт', done: true },
    { id: 'lesson', title: 'Пройти первый урок', done: st.lessonsPassed >= 1, link: cont ? '#/lesson/' + cont.lesson : '#/courses' },
    { id: 'hw', title: 'Сделать первое домашнее задание', done: st.hwDone >= 1, link: pendingHw[0] ? '#/hw/' + pendingHw[0].lesson : '' },
    { id: 'live', title: 'Записаться на урок с преподавателем', done: hasLive, link: '#/schedule' }
  ];
  return { courses, continue: cont, pendingHw, stats: st, streak, achievements: achievementsView(uid), checklist: checklist.every(x => x.done) ? null : checklist,
    nextLive: nextLiveFor(uid), club: clubStatus(uid), clubNext: clubNextFor(uid), unread: unreadCount(uid), tz: tzOf(u) };
}

function lessonAccess(uid, key) {
  const hit = lessonHit(key); if (!hit) throw new HttpError(404, 'Урок не найден');
  const ctx = ctxOf(uid);
  if (!ctx.enrolled.has(hit.course.id)) throw new HttpError(403, 'Курс не подключён', { noCourse: hit.course.id });
  const view = courseView(uid, hit.course, ctx), l = view.lessons[hit.lesson.index];
  if (l.status === 'locked') { const pv = view.lessons[hit.lesson.index - 1]; throw new HttpError(403, 'Урок ещё закрыт', { need: pv ? pv.title : null, needScore: CFG.PASS_SCORE }); }
  const nx = view.lessons[hit.lesson.index + 1] || null;
  return { course: hit.course, lesson: hit.lesson, view: l, next: nx && { key: nx.key, title: nx.title } };
}

/* ── ДЗ ── */
function pickQuestions(key) { return shuffle((content.bank(key, 'ru') || []).map(x => x.id)).slice(0, CFG.HW_SIZE); }
function createHomework(uid, key) {
  const ids = pickQuestions(key); if (!ids.length) return false;
  const H = (db.hw[uid] = db.hw[uid] || {});
  if (!H[key]) H[key] = { qids: ids, status: 'new', score: null, best: null, attempts: 0, created: now() };
  return true;
}
const int = (v, lo, hi) => clampInt(v, lo, lo, hi);

function recordProgress(uid, key, b) {
  const a = lessonAccess(uid, key), need = a.lesson.tasks;
  const done = int(b.done, 0, 200), tries = int(b.tries, 0, 5000), hits = Math.min(int(b.hits, 0, 5000), tries), xp = int(b.xp, 0, 20000), seconds = int(b.seconds, 0, 86400);
  const accuracy = tries ? Math.round(hits / tries * 100) : 0, finished = done >= need;
  const plausible = seconds >= CFG.MIN_LESSON_SECONDS && tries >= Math.min(5, need);
  const P = (db.progress[uid] = db.progress[uid] || {}), prev = P[key], was = !!(prev && prev.passed_at);
  const passedNow = !was && finished && plausible && accuracy >= CFG.PASS_SCORE;
  const row = { done: Math.min(done, need), total: need, accuracy, best_accuracy: Math.max(prev ? prev.best_accuracy : 0, finished ? accuracy : 0),
    xp: was ? Math.max(prev.xp, xp) : xp, seconds: was ? Math.max(prev.seconds, seconds) : seconds,
    attempts: (prev ? prev.attempts : 0) + (finished && (!prev || prev.done < need) ? 1 : 0),
    passed_at: was ? prev.passed_at : (passedNow ? now() : null), manual: prev ? prev.manual : 0, updated: now() };
  if (was && prev.done >= need) row.done = prev.done;
  P[key] = row; touch(uid);
  let hwCreated = false;
  if (passedNow) {
    hwCreated = createHomework(uid, key);
    if (hwCreated) notify(uid, 'hw_new', 'Новое домашнее задание', `К уроку «${a.lesson.title}» — ${CFG.HW_SIZE} вопросов`, '#/hw/' + key);
    if (a.next) notify(uid, 'unlock', 'Открыт следующий урок', a.next.title, '#/lesson/' + a.next.key);
    evalAch(uid);
  }
  return { passed: was || passedNow, passedNow, finished, accuracy, need: CFG.PASS_SCORE,
    tooFast: finished && !plausible && accuracy >= CFG.PASS_SCORE && !was, lowScore: finished && plausible && accuracy < CFG.PASS_SCORE && !was,
    hwCreated, next: passedNow || was ? a.next : null };
}

function getHomework(uid, key) {
  const hit = lessonHit(key); if (!hit) throw new HttpError(404, 'Урок не найден');
  const h = (db.hw[uid] || {})[key]; if (!h) throw new HttpError(404, 'ДЗ ещё не открыто — пройдите урок');
  const idx = Object.fromEntries((content.bank(key, LANG) || []).map(x => [x.id, x]));
  return { lesson: key, title: hit.lesson.title, status: h.status, score: h.score, best: h.best, attempts: h.attempts, pass: CFG.HW_PASS,
    questions: h.qids.map(id => idx[id]).filter(Boolean).map(x => ({ id: x.id, q: x.q, say: x.say || '', opts: x.opts })) };
}
function submitHomework(uid, key, answers) {
  const h = (db.hw[uid] || {})[key]; if (!h) throw new HttpError(404, 'ДЗ ещё не открыто');
  if (h.status === 'done') throw new HttpError(409, 'ДЗ уже выполнено');
  if (!answers || typeof answers !== 'object') throw new HttpError(400, 'Нет ответов');
  const idx = Object.fromEntries((content.bank(key, LANG) || []).map(x => [x.id, x]));
  let correct = 0;
  const results = h.qids.map(id => { const x = idx[id]; if (!x) return null; const chosen = Number.isInteger(answers[id]) ? answers[id] : -1, ok = chosen === x.a; if (ok) correct++; return { id, chosen, correct: x.a, ok, why: x.why }; }).filter(Boolean);
  const total = results.length, score = total ? Math.round(correct / total * 100) : 0, passed = score >= CFG.HW_PASS;
  h.best = Math.max(h.best || 0, score); h.score = score; h.attempts++;
  if (passed) { h.status = 'done'; h.doneAt = now(); } else h.qids = pickQuestions(key);
  touch(uid); evalAch(uid);
  return { passed, score, correct, total, pass: CFG.HW_PASS, results };
}

/* ── коды доступа ── */
function makeCode() {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let s = '';
  for (let i = 0; i < 8; i++) s += A[Math.floor(env.random() * A.length)];
  return 'VOSCA-' + s.slice(0, 4) + '-' + s.slice(4);
}
/* Приводим введённый код к виду VOSCA-XXXX-XXXX: любой регистр, пробелы и длинные тире, код, набранный в русской раскладке
   (МЩЫСФ вместо VOSCA), код без дефисов. Так «код не работает» из-за мелочи ввода не бывает. */
const RU_KEYS = { 'Й': 'Q', 'Ц': 'W', 'У': 'E', 'К': 'R', 'Е': 'T', 'Н': 'Y', 'Г': 'U', 'Ш': 'I', 'Щ': 'O', 'З': 'P', 'Ф': 'A', 'Ы': 'S', 'В': 'D', 'А': 'F', 'П': 'G', 'Р': 'H', 'О': 'J', 'Л': 'K', 'Д': 'L', 'Я': 'Z', 'Ч': 'X', 'С': 'C', 'М': 'V', 'И': 'B', 'Т': 'N', 'Ь': 'M', 'Ё': 'E' };
function normCode(raw) {
  let s = str(raw, 60).toUpperCase().replace(/[А-ЯЁ]/g, ch => RU_KEYS[ch] || ch).replace(/[^A-Z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  const m = s.match(/^(VOSCA|TEACH|ADMIN)-?([A-Z0-9]{4})-?([A-Z0-9]{4})$/); if (m) s = m[1] + '-' + m[2] + '-' + m[3];
  return s;
}
/* проверка кода доступа без списания (uid — если известен, ловим повторную активацию) */
function codeCheck(raw, uid) {
  const code = normCode(raw), c = db.codes[code];
  if (!c) throw new HttpError(404, 'Код не найден — проверьте, нет ли опечатки. Если всё верно, напишите в школу (контакты внизу страницы)');
  if (!c.active) throw new HttpError(404, 'Этот код отключён — попросите в школе новый');
  if (c.used >= c.max) throw new HttpError(409, 'Этот код уже использован');
  if (uid && c.users && c.users.includes(uid)) throw new HttpError(409, 'Вы уже активировали этот код');
  return c;
}
/* преподаватель ведёт язык? Пустой список = не задано (старые аккаунты) = все языки */
function teachesCourse(t, cid) { return !t.langs || !t.langs.length || t.langs.includes(cid); }
function normLangs(list) { const ok = new Set(catalog().map(c => c.id)); return [...new Set((Array.isArray(list) ? list : []).map(x => str(x, 40)).filter(x => ok.has(x)))]; }
function langTitles(t) { return (t.langs && t.langs.length ? t.langs : catalog().map(c => c.id)).map(id => courseById(id)).filter(Boolean).map(c => ({ id: c.id, title: c.title, flag: c.flag })); }
function redeemCode(uid, raw) {
  const c = codeCheck(raw, uid);
  if (c.course === CLUB_CODE) {                                       // код на подписку Разговорного клуба
    clubGrant(null, uid, { days: c.days || 30 }, 'code'); c.used++; c.users = (c.users || []).concat(uid);
    return { club: true, until: db.subs[uid].until, title: 'Разговорный клуб' };
  }
  if (!grantCourse(uid, c.course, c.days, 'code')) throw new HttpError(400, 'Курс по этому коду пока недоступен');
  c.used++; c.users = (c.users || []).concat(uid);
  if (c.teacher) autoAssign(uid, c.course, c.teacher);               // код выдан «под преподавателя» — ученик сразу закреплён за ним
  const course = courseById(c.course), u = userById(uid);
  notify(uid, 'course', `Открыт курс «${course.title}»`, c.days ? `Доступ на ${c.days} дн.` : 'Доступ без ограничения по времени', '#/course/' + c.course, {
    subject: `Курс «${course.title}» открыт — Vosca`,
    html: mailLayout('Курс открыт 🎉', `<p>Здравствуйте, ${esc(u.name)}! Вам открыт курс <b>${esc(course.title)}</b>${c.days ? ` на ${c.days} дн.` : ''}. Первый урок уже ждёт.</p>`, { label: 'Начать учёбу', url: env.baseUrl() + '/#/course/' + c.course }),
    text: `Вам открыт курс «${course.title}». ${env.baseUrl()}/#/course/${c.course}`
  });
  touch(uid);
  return { course: c.course, title: course.title };
}
