/* ═══════════ Ученики преподавателя: мои, свободные ученики моих языков, «взять ученика» ═══════════ */
function autoAssign(uid, cid, tid) {                                   // закрепляем преподавателя, если у ученика по этому языку его ещё нет
  const t = userById(tid); if (!t || !isTeacher(t) || !teachesCourse(t, cid)) return false;
  db.assign[uid] = db.assign[uid] || {}; if (db.assign[uid][cid]) return false;
  db.assign[uid][cid] = t.id;
  notify(uid, 'teacher', `Ваш преподаватель — ${t.name}`, (courseById(cid) || {}).title || '', '#/teachers/' + t.id);
  return true;
}
function teacherStudentsPanel(actor, teacherId) {
  const tid = actor.role === 'admin' && teacherId ? +teacherId : actor.id, tu = userById(tid), t = now();
  if (!tu || !isTeacher(tu)) throw new HttpError(404, 'Преподаватель не найден');
  const mine = [];
  Object.keys(db.assign).forEach(sid => Object.keys(db.assign[sid]).forEach(cid => {
    if (db.assign[sid][cid] !== tid) return; const su = userById(+sid); if (!su) return;
    const c = courseById(cid), P = db.progress[su.id] || {}, total = c ? c.lessons.length : 0, passed = c ? c.lessons.filter(l => P[l.key] && P[l.key].passed_at).length : 0;
    const act = db.activity[su.id] || {}, days = Object.keys(act).sort(), en = (db.enroll[su.id] || {})[cid];
    const lives = Object.values(db.live).filter(s => s.student === su.id && s.teacher === tid);
    const next = lives.filter(s => s.status === 'planned' && sessionEnd(s) > t).sort((a, b) => a.starts - b.starts)[0];
    const done = lives.filter(s => s.status === 'done').sort((a, b) => b.starts - a.starts)[0];
    mine.push({ id: su.id, name: su.name, email: su.email, tz: tzOf(su), course: cid, courseTitle: c ? c.title : cid, flag: c ? c.flag : '', ready: !!(c && c.ready), passed, total,
      percent: total ? Math.round(passed / total * 100) : 0, active: !!activeEnroll(su.id, cid), until: en ? en.expires : null, lastDay: days[days.length - 1] || null,
      next: next ? { id: next.id, starts: next.starts, dur: next.dur } : null, lastDone: done ? done.starts : 0, club: clubStatus(su.id).state,
      pending: Object.values(db.req).filter(r => r.student === su.id && r.teacher === tid && r.status === 'pending').length, materials: Object.values(db.materials).filter(m => (m.shares || []).some(x => x.uid === su.id && x.by === tid)).length });
  }));
  mine.sort((a, b) => (a.next ? a.next.starts : Infinity) - (b.next ? b.next.starts : Infinity) || a.name.localeCompare(b.name));
  const free = [];
  Object.keys(db.enroll).forEach(sid => {
    const su = userById(+sid); if (!su || su.role !== 'student') return;
    Object.keys(db.enroll[sid]).forEach(cid => {
      if (!teachesCourse(tu, cid) || !activeEnroll(su.id, cid) || (db.assign[sid] || {})[cid]) return;
      const c = courseById(cid); if (!c) return;
      free.push({ id: su.id, name: su.name, email: su.email, course: cid, courseTitle: c.title, flag: c.flag, since: db.enroll[sid][cid].since });
    });
  });
  free.sort((a, b) => b.since - a.since);
  return { now: t, tz: tzOf(actor), teacher: { id: tid, name: tu.name }, students: mine, free, langs: langTitles(tu), teachers: actor.role === 'admin' ? Object.values(db.users).filter(isTeacher).map(u => ({ id: u.id, name: u.name })) : undefined };
}
function teacherTake(actor, b) {
  const tid = actor.role === 'admin' ? +b.teacher : actor.id, tu = userById(tid);
  if (!tu || !isTeacher(tu)) throw new HttpError(400, 'Выберите преподавателя');
  const su = userById(+b.student), cid = str(b.course, 40);
  if (!su || su.role !== 'student') throw new HttpError(404, 'Ученик не найден');
  if (!courseById(cid) || !activeEnroll(su.id, cid)) throw new HttpError(400, 'У ученика нет доступа к этому языку');
  if (!teachesCourse(tu, cid)) throw new HttpError(403, 'Вы не ведёте этот язык');
  const cur = (db.assign[su.id] || {})[cid];
  if (cur === tid) throw new HttpError(409, 'Этот ученик уже ваш');
  if (cur) throw new HttpError(409, 'У ученика уже есть преподаватель — смену делает администратор');
  autoAssign(su.id, cid, tid);
  return { ok: true };
}
