/* ═══════════ Материалы для преподавания ═══════════
   Добавляет админ (материалы школы — всем преподавателям языка или выбранным) или сам преподаватель (свои).
   Три вида: ссылка, текст/заметка, файл (PDF, картинка, документ Office, аудио). Преподаватель может «отправить» материал ученику —
   тогда он появляется у ученика в разделе «Материалы». Админ может сделать материал видимым и ученикам языка. */
const MAT_FILE_MAX = 3 * 1024 * 1024;
const MAT_EXT = { pdf: 'application/pdf', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif', txt: 'text/plain', mp3: 'audio/mpeg', m4a: 'audio/mp4',
  doc: 'application/msword', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', ppt: 'application/vnd.ms-powerpoint', pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  xls: 'application/vnd.ms-excel', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' };
const MAT_MAGIC = { pdf: '%PDF', png: '\x89PNG', jpg: '\xFF\xD8\xFF', jpeg: '\xFF\xD8\xFF', gif: 'GIF8', docx: 'PK', pptx: 'PK', xlsx: 'PK', doc: '\xD0\xCF\x11\xE0', ppt: '\xD0\xCF\x11\xE0', xls: '\xD0\xCF\x11\xE0' };
const MAT_LIMIT_PER_TEACHER = 60;

function matFileCheck(f) {
  const name = str(f && f.name, 120).replace(/[\\/:*?"<>|\x00-\x1f]/g, '_').trim(), ext = (name.split('.').pop() || '').toLowerCase();
  if (!name || !MAT_EXT[ext]) throw new HttpError(400, 'Такой тип файла не поддерживается. Подходят: PDF, картинки, документы Word/Excel/PowerPoint, TXT, MP3');
  const b64 = String(f.data || '').replace(/^data:[^;]*;base64,/, '');
  if (!/^[A-Za-z0-9+\/]+={0,2}$/.test(b64)) throw new HttpError(400, 'Не удалось прочитать файл');
  const bytes = Math.floor(b64.length * 3 / 4) - (b64.endsWith('==') ? 2 : b64.endsWith('=') ? 1 : 0);
  if (bytes > MAT_FILE_MAX) throw new HttpError(413, 'Файл слишком большой: можно до 3 МБ. Для больших файлов добавьте ссылку (Google Drive, Яндекс Диск)');
  if (MAT_MAGIC[ext] && !b64Magic(b64).startsWith(MAT_MAGIC[ext])) throw new HttpError(400, 'Файл не похож на «' + ext + '» — проверьте, что он не повреждён');
  return { name, mime: MAT_EXT[ext], b64, bytes };
}
function createMaterial(actor, b) {
  if (!isTeacher(actor)) throw new HttpError(403, 'Только для преподавателя');
  const isAdmin = actor.role === 'admin', title = str(b.title, 120).trim(), desc = str(b.desc, 600).trim(), kind = str(b.kind, 10), course = str(b.course, 40);
  if (!title) throw new HttpError(400, 'Введите название материала');
  if (course) { if (!courseById(course)) throw new HttpError(400, 'Выберите язык'); if (!isAdmin && !teachesCourse(actor, course)) throw new HttpError(403, 'Вы не ведёте этот язык'); }
  else if (!isAdmin) throw new HttpError(400, 'Выберите язык материала');
  if (!isAdmin && Object.values(db.materials).filter(m => m.owner === actor.id).length >= MAT_LIMIT_PER_TEACHER) throw new HttpError(429, 'Слишком много материалов — удалите ненужные');
  const m = { id: nextId('mat'), owner: actor.id, ownerRole: actor.role, course, title, desc, kind, created: now(), shares: [], audience: 'teachers', teachers: [] };
  if (kind === 'link') { const u = safeUrl(str(b.url, 500)); if (!u) throw new HttpError(400, 'Ссылка должна начинаться с https://'); m.url = u; }
  else if (kind === 'text') { const t = str(b.text, 8000).trim(); if (!t) throw new HttpError(400, 'Введите текст материала'); m.text = t; }
  else if (kind === 'file') { const f = matFileCheck(b.file); m.file = { name: f.name, mime: f.mime, size: f.bytes }; db.mfiles[m.id] = { name: f.name, mime: f.mime, b64: f.b64 }; }
  else throw new HttpError(400, 'Выберите, что добавляете: ссылку, текст или файл');
  if (isAdmin) {
    m.audience = b.audience === 'all' ? 'all' : 'teachers';
    m.teachers = (Array.isArray(b.teachers) ? b.teachers : []).map(Number).filter(id => { const t = userById(id); return t && isTeacher(t); });
    if (m.audience === 'all' && !course) throw new HttpError(400, 'Чтобы показать материал ученикам, выберите язык');
  }
  db.materials[m.id] = m;
  if (isAdmin) (m.teachers.length ? m.teachers.map(userById) : Object.values(db.users).filter(u => isTeacher(u) && u.role === 'teacher' && (!course || teachesCourse(u, course))))
    .forEach(t => t && t.id !== actor.id && notify(t.id, 'material', '📚 Новый материал для преподавания', `${title}${course ? ' · ' + (courseById(course) || {}).title : ''}`, '#/teach/materials'));
  return matView(m, actor);
}
function matMaySee(m, u) {                                              // может ли пользователь открыть материал
  if (!u) return false;
  if (u.role === 'admin' || m.owner === u.id) return true;
  if (u.role === 'teacher') return m.ownerRole === 'admin' && (!m.course || teachesCourse(u, m.course)) && (!m.teachers.length || m.teachers.includes(u.id));
  if (u.role === 'student') return (m.shares || []).some(x => x.uid === u.id) || (m.ownerRole === 'admin' && m.audience === 'all' && !!activeEnroll(u.id, m.course));
  return false;
}
function matView(m, viewer) {
  const c = m.course ? courseById(m.course) : null, own = viewer && (viewer.role === 'admin' || viewer.id === m.owner);
  const v = { id: m.id, title: m.title, desc: m.desc, kind: m.kind, course: m.course, courseTitle: c ? c.title : 'Все языки', flag: c ? c.flag : '🌍', created: m.created,
    from: { id: m.owner, name: m.ownerRole === 'admin' ? 'Vosca' : nameOf(m.owner), school: m.ownerRole === 'admin' }, mine: !!own, school: m.ownerRole === 'admin' };
  if (m.kind === 'link') v.url = m.url; if (m.kind === 'text') v.text = m.text; if (m.kind === 'file') v.file = m.file;
  if (own) {
    v.audience = m.audience; v.teachers = (m.teachers || []).map(id => ({ id, name: nameOf(id) }));
    v.shares = (m.shares || []).map(x => ({ id: x.uid, name: nameOf(x.uid), at: x.at }));
  }
  if (viewer && viewer.role === 'student') { const sh = (m.shares || []).find(x => x.uid === viewer.id); v.sharedAt = sh ? sh.at : m.created; v.note = sh ? sh.note || '' : ''; }
  return v;
}
function teacherMaterials(actor) {
  const list = Object.values(db.materials).filter(m => matMaySee(m, actor)).sort((a, b) => b.created - a.created);
  const mine = [], school = [];
  list.forEach(m => (m.owner === actor.id ? mine : school).push(matView(m, actor)));
  const langs = actor.role === 'admin' ? catalog().map(c => ({ id: c.id, title: c.title, flag: c.flag })) : langTitles(actor);
  const ts = teacherStudentsPanel(actor).students;
  return { mine, school, langs, students: ts.map(s => ({ id: s.id, name: s.name, course: s.course, courseTitle: s.courseTitle, flag: s.flag })) };
}
function studentMaterials(u) {
  const items = Object.values(db.materials).filter(m => matMaySee(m, u)).sort((a, b) => b.created - a.created).map(m => matView(m, u));
  items.sort((a, b) => b.sharedAt - a.sharedAt);
  return { items };
}
function adminMaterials() {
  const items = Object.values(db.materials).sort((a, b) => b.created - a.created).map(m => Object.assign(matView(m, { role: 'admin', id: 0 }), { ownerName: nameOf(m.owner) }));
  return { items, langs: catalog().map(c => ({ id: c.id, title: c.title, flag: c.flag })), teachers: Object.values(db.users).filter(u => u.role === 'teacher').map(u => ({ id: u.id, name: u.name, langs: u.langs || [] })) };
}
function materialGet(id) { const m = db.materials[+id]; if (!m) throw new HttpError(404, 'Материал не найден'); return m; }
function materialFile(viewer, id) {
  const m = materialGet(id); if (!matMaySee(m, viewer) || m.kind !== 'file') throw new HttpError(404, 'Материал не найден');
  const f = db.mfiles[m.id]; if (!f) throw new HttpError(404, 'Файл не найден');
  return { name: f.name, mime: f.mime, b64: f.b64 };
}
function materialShare(actor, id, b) {
  const m = materialGet(id); if (!isTeacher(actor) || !matMaySee(m, actor)) throw new HttpError(403, 'Нет доступа');
  const ids = [...new Set((Array.isArray(b.students) ? b.students : []).map(Number))]; if (!ids.length) throw new HttpError(400, 'Выберите хотя бы одного ученика');
  const note = str(b.note, 300).trim(); let n = 0;
  ids.forEach(sid => {
    const su = userById(sid); if (!su || su.role !== 'student') return;
    const mine = actor.role === 'admin' || Object.values(db.assign[sid] || {}).includes(actor.id);
    if (!mine) throw new HttpError(403, 'Можно отправлять только своим ученикам: ' + su.name);
    if (m.course && !activeEnroll(sid, m.course) && actor.role !== 'admin') throw new HttpError(400, `У ученика ${su.name} нет доступа к этому языку`);
    if ((m.shares || []).some(x => x.uid === sid)) return;
    (m.shares = m.shares || []).push({ uid: sid, by: actor.id, at: now(), note }); n++;
    notify(sid, 'material', '📚 Преподаватель отправил вам материал', `${m.title} · ${actor.name}`, '#/materials', { subject: `Новый материал: ${m.title} — Vosca`, text: `${actor.name} отправил(а) вам материал «${m.title}»`,
      html: mailLayout('Новый материал', `<p><b>${esc(actor.name)}</b> отправил(а) вам материал: <b>${esc(m.title)}</b>.</p>${note ? `<p>${esc(note)}</p>` : ''}`, { label: 'Открыть материалы', url: env.baseUrl() + '/#/materials' }) });
  });
  return { shared: n, material: matView(m, actor) };
}
function materialUnshare(actor, id, sid) {
  const m = materialGet(id); if (!isTeacher(actor) || !matMaySee(m, actor)) throw new HttpError(403, 'Нет доступа');
  m.shares = (m.shares || []).filter(x => x.uid !== +sid); return matView(m, actor);
}
function materialDelete(actor, id) {
  const m = materialGet(id); if (!(actor.role === 'admin' || m.owner === actor.id)) throw new HttpError(403, 'Удалить можно только свой материал');
  delete db.materials[m.id]; delete db.mfiles[m.id];
}
