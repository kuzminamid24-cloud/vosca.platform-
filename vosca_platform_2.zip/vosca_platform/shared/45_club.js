/* ═══════════ Профили преподавателей и Разговорный клуб (подписка, занятия, запись) ═══════════ */

/* ───────────── профиль преподавателя: фото, имя, «о себе» ───────────── */
const PHOTO_MAX = 200 * 1024;                       // байт после уменьшения в браузере
const PROFILE_TEXT = { headline: 90, headline_en: 90, bio: 1200, bio_en: 1200, speaks: 120, teaches: 120, country: 60 };

function profileOf(u) {
  const p = u.profile || {};
  return { headline: p.headline || '', headline_en: p.headline_en || '', bio: p.bio !== undefined ? p.bio : (u.bio || ''), bio_en: p.bio_en || '',
    speaks: p.speaks || '', teaches: p.teaches || '', years: p.years || 0, country: p.country || '', video: p.video || '', hidden: !!p.hidden };
}
function photoSrc(uid) {
  const r = db.photos[uid]; if (!r) return '';
  return env.photoSrc ? env.photoSrc(r, uid) : '/photo/' + uid + '?v=' + r.v;
}
/* текст на языке интерфейса: английский, если он есть; русский как основной */
function pickLang(ru, en) { return LANG === 'en' ? (en || ru) : (ru || en); }

function teacherVisible(u, viewer) {
  if (!isTeacher(u)) return false;
  const p = profileOf(u);
  if (p.hidden && !(viewer && (viewer.role === 'admin' || viewer.id === u.id))) return false;
  if (u.role === 'admin') return !!(p.headline || p.headline_en || p.bio || p.bio_en || db.photos[u.id]);        // админ в списке — только если сам заполнил профиль
  return true;
}
function teacherCard(u, full, viewer) {
  const p = profileOf(u);
  const c = { id: u.id, name: u.name, role: u.role, photo: photoSrc(u.id), headline: pickLang(p.headline, p.headline_en), speaks: p.speaks, teaches: p.teaches, years: p.years, country: p.country, hidden: p.hidden, langs: langTitles(u) };
  if (full) {
    c.bio = pickLang(p.bio, p.bio_en); c.video = p.video;
    c.mine = !!(viewer && Object.values(db.assign[viewer.id] || {}).includes(u.id));
    c.club = Object.values(db.club).filter(s => s.teacher === u.id && s.status === 'planned' && sessionEnd(s) > now()).sort((a, b) => a.starts - b.starts).slice(0, 4).map(s => ({ id: s.id, title: s.title, lang: s.lang, starts: s.starts }));
  }
  return c;
}
function teachersList(viewer) {
  let us = Object.values(db.users).filter(u => teacherVisible(u, viewer));
  if (viewer && viewer.role === 'student') {                         // ученик видит только тех, кто ведёт его языки
    const mine = [...enrolledSet(viewer.id)];
    if (mine.length) us = us.filter(u => mine.some(cid => teachesCourse(u, cid)));
  }
  const list = us.map(u => teacherCard(u, false, viewer));
  list.forEach(c => { c.mine = !!(viewer && Object.values(db.assign[viewer.id] || {}).includes(c.id)); });
  return list.sort((a, b) => (b.mine - a.mine) || a.name.localeCompare(b.name));
}
function teacherDetail(id, viewer) {
  const u = userById(+id); if (!u || !teacherVisible(u, viewer)) throw new HttpError(404, 'Преподаватель не найден');
  return teacherCard(u, true, viewer);
}
function profileTarget(actor, tid) {
  const t = actor.role === 'admin' && tid ? userById(+tid) : actor;
  if (!t || !isTeacher(t)) throw new HttpError(404, 'Преподаватель не найден');
  return t;
}
function profileEdit(actor, tid) {
  const t = profileTarget(actor, tid);
  return Object.assign({ id: t.id, name: t.name, photo: photoSrc(t.id), meeting_url: t.meeting_url || '' }, profileOf(t));
}
function saveProfile(actor, b) {
  const t = profileTarget(actor, b.teacher), p = Object.assign({}, t.profile || {});
  if (p.bio === undefined) p.bio = t.bio || '';
  Object.keys(PROFILE_TEXT).forEach(k => { if (b[k] !== undefined) p[k] = str(b[k], PROFILE_TEXT[k]); });
  if (b.years !== undefined) p.years = clampInt(b.years, 0, 0, 60);
  if (b.video !== undefined) { const v = b.video ? safeUrl(b.video) : ''; if (v === null) throw new HttpError(400, 'Ссылка на видео должна начинаться с https://'); p.video = v; }
  if (b.hidden !== undefined) { if (actor.role !== 'admin') throw new HttpError(403, 'Скрыть профиль может только администратор'); p.hidden = !!b.hidden; }
  if (b.name !== undefined) { const n = str(b.name, 60).replace(/\s+/g, ' '); if (!n) throw new HttpError(400, 'Введите имя'); t.name = n; }
  t.profile = p; t.bio = p.bio;
  return profileEdit(actor, t.id);
}
function b64Magic(b64) { try { return atob(b64.slice(0, 16)); } catch (e) { return ''; } }
function savePhoto(actor, b) {
  const t = profileTarget(actor, b.teacher);
  if (b.remove) { delete db.photos[t.id]; return { photo: '' }; }
  const m = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+\/]+={0,2})$/.exec(String(b.data || ''));
  if (!m) throw new HttpError(400, 'Загрузите изображение JPG, PNG или WebP');
  const mime = m[1], b64 = m[2], bytes = Math.floor(b64.length * 3 / 4) - (b64.endsWith('==') ? 2 : b64.endsWith('=') ? 1 : 0);
  if (bytes > PHOTO_MAX) throw new HttpError(413, 'Фото слишком большое: нужно не больше 200 КБ (браузер уменьшает его сам)');
  const head = b64Magic(b64), ok = mime === 'image/jpeg' ? head.startsWith('\xFF\xD8\xFF') : mime === 'image/png' ? head.startsWith('\x89PNG') : (head.startsWith('RIFF') && head.slice(8, 12) === 'WEBP');
  if (!ok) throw new HttpError(400, 'Файл не похож на изображение');
  db.photos[t.id] = { mime, b64, v: now() };
  return { photo: photoSrc(t.id) };
}

/* ───────────── Разговорный клуб: подписка ───────────── */
const CLUB_LANGS = ['English', 'Русский', 'ไทย', 'Français', 'Español', '中文'];
const CLUB_CODE = 'club';                              // «курс» в кодах доступа, который открывает подписку на клуб
const CLUB_CAP = 6;                                   // мест в группе по умолчанию

function endOfDay(ts, tz) { const p = parts(ts, tz); return zonedToUtc(p.y, p.m, p.d, 23, 59, tz) + 59 * 1000 + 999; }
/* полных суток до окончания (подписка кончается в конце последнего дня, поэтому «0» = последний день) */
function daysLeft(until) { return Math.floor((until - now()) / DAY); }
function clubActive(uid, at) { const s = db.subs[uid]; return !!s && (!s.until || s.until > (at === undefined ? now() : at)); }
function clubStatus(uid) {
  const s = db.subs[uid]; if (!s) return { state: 'none', active: false };
  const t = now(), active = !s.until || s.until > t;
  return { state: !active ? 'expired' : s.until && daysLeft(s.until) <= 7 ? 'expiring' : 'active', active, until: s.until || null, lifetime: !s.until, since: s.since,
    left: s.until ? Math.max(0, daysLeft(s.until)) : null, source: s.source || '', note: s.note || '' };
}
function clubMail(kind, u, s) {
  const tz = tzOf(u), until = s.until ? fmtLongDate(s.until, tz) : '';
  const T = {
    granted: ['Доступ к Разговорному клубу открыт', s.until ? `Подписка действует до ${until}` : 'Подписка без ограничения по времени'],
    extended: ['Подписка на Разговорный клуб продлена', s.until ? `Новая дата окончания: ${until}` : 'Теперь подписка без ограничения по времени'],
    revoked: ['Доступ к Разговорному клубу закрыт', 'Обратитесь в школу, если это ошибка'],
    w7: ['Подписка на клуб скоро закончится', `Подписка действует до ${until} — осталась неделя или меньше`],
    d1: ['Подписка на клуб скоро закончится', `Последний день — ${until}`],
    exp: ['Подписка на клуб закончилась', 'Чтобы продолжить ходить в клуб, продлите подписку']
  }[kind];
  return { subject: T[0] + ' — Vosca', html: mailLayout(T[0], `<p>Здравствуйте, ${esc(u.name)}!</p><p style="font-size:16px"><b>${esc(T[1])}</b></p>`, { label: 'Открыть клуб', url: env.baseUrl() + '/#/club' }), text: `${T[0]}. ${T[1]}. ${env.baseUrl()}/#/club` };
}
function fmtLongDate(ts, tz) { return new Intl.DateTimeFormat('ru-RU', { timeZone: tz, day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(ts)); }
function clubNotify(kind, uid) {
  const u = userById(uid), s = db.subs[uid]; if (!u || !s) return;
  const icon = { granted: '🎤', extended: '🎤', revoked: '⛔', w7: '⏳', d1: '⏳', exp: '⌛' }[kind];
  const m = clubMail(kind, u, s), until = s.until ? fmtLongDate(s.until, tzOf(u)) : '';
  const title = { granted: 'Доступ к Разговорному клубу открыт', extended: 'Подписка на клуб продлена', revoked: 'Доступ к клубу закрыт', w7: 'Подписка на клуб заканчивается на этой неделе', d1: 'Подписка на клуб заканчивается завтра или сегодня', exp: 'Подписка на клуб закончилась' }[kind];
  notify(uid, 'club_' + kind, icon + ' ' + title, until ? 'До ' + until : '', '#/club', m);
}
/* админ (или код): открыть / продлить / назначить дату. b: {days} | {until:'YYYY-MM-DD'} | {lifetime:true} */
function clubGrant(actor, uid, b, source) {
  const u = userById(uid); if (!u || u.role !== 'student') throw new HttpError(404, 'Ученик не найден');
  const tz = tzOf(u), t = now(), prev = db.subs[uid], cur = prev && (!prev.until || prev.until > t) ? prev : null;
  let until;
  if (b.lifetime) until = null;
  else if (b.until) {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(b.until)); if (!m) throw new HttpError(400, 'Неверная дата окончания');
    until = endOfDay(zonedToUtc(+m[1], +m[2], +m[3], 12, 0, tz), tz);
    if (until <= t) throw new HttpError(400, 'Дата окончания должна быть в будущем');
  } else {
    const days = clampInt(b.days, 0, 1, 3650); if (!days) throw new HttpError(400, 'Укажите срок: число дней, дату окончания или «без ограничения»');
    if (cur && !cur.until) until = null;                                      // бессрочную подписку днями не сокращаем
    else until = endOfDay((cur && cur.until ? cur.until : t) + days * DAY, tz);
  }
  const was = !!cur;
  db.subs[uid] = { since: prev ? prev.since : t, until, source: source || (prev && prev.source) || 'admin', note: b.note !== undefined ? str(b.note, 100) : (prev ? prev.note || '' : ''),
    by: actor ? actor.id : 0, w7: until && daysLeft(until) <= 7 ? 1 : 0, d1: until && daysLeft(until) <= 1 ? 1 : 0, exp: 0,
    hist: ((prev && prev.hist) || []).slice(-19).concat([{ at: t, by: actor ? actor.id : 0, act: was ? 'extend' : 'grant', until }]) };
  clubTrim(uid);
  clubNotify(was ? 'extended' : 'granted', uid);
  return clubStatus(uid);
}
function clubRevoke(actor, uid) {
  const u = userById(uid), s = db.subs[uid]; if (!u || !s) throw new HttpError(404, 'У ученика нет подписки');
  const t = now(); s.until = t - 1; s.exp = 1; s.w7 = 1; s.d1 = 1;
  s.hist = (s.hist || []).slice(-19).concat([{ at: t, by: actor ? actor.id : 0, act: 'revoke', until: s.until }]);
  clubTrim(uid); clubNotify('revoked', uid);
  return clubStatus(uid);
}
/* записи, которые выходят за срок подписки, снимаются (ученик получает уведомление) */
function clubTrim(uid) {
  const out = [];
  Object.values(db.club).forEach(s => {
    if (s.status !== 'planned' || s.starts <= now() || !s.members.includes(uid) || clubActive(uid, s.starts)) return;
    s.members = s.members.filter(x => x !== uid); out.push(s);
  });
  if (out.length) { const tz = tzOf(userById(uid)); notify(uid, 'club_trim', `Записей в клуб снято: ${out.length}`, 'Они выходят за срок подписки: ' + out.map(s => fmtDT(s.starts, tz)).join('; ').slice(0, 300), '#/club'); }
  return out.length;
}

/* ───────────── Разговорный клуб: единая ссылка на встречи ───────────── */
/* У клуба ОДНА постоянная ссылка. Её вставляет преподаватель, который ведёт клуб (или админ), и при желании рассылает участникам. */
function clubLink() { db.settings.club = db.settings.club || {}; return db.settings.club; }
function clubUrlOf(s) { return (s && s.url) || clubLink().url || ''; }
function clubLinkView() { const l = clubLink(); return { url: l.url || '', by: l.by ? nameOf(l.by) : '', at: l.at || 0 }; }
function clubMembersOf(actor) {                                       // кому рассылать: записанным на будущие занятия (преподавателю — на его занятия)
  const ids = new Set(); Object.values(db.club).filter(s => s.status === 'planned' && sessionEnd(s) > now() && (actor.role === 'admin' || s.teacher === actor.id)).forEach(s => s.members.forEach(id => ids.add(id)));
  return [...ids].map(userById).filter(Boolean);
}
function clubLinkSend(actor) {
  if (!isTeacher(actor)) throw new HttpError(403, 'Только для преподавателя');
  const url = clubLink().url; if (!url) throw new HttpError(400, 'Сначала вставьте ссылку на встречу клуба');
  const people = clubMembersOf(actor);
  people.forEach(u => notify(u.id, 'club_link', '🔗 Ссылка на Разговорный клуб', `От ${actor.name}`, '#/club', { subject: 'Ссылка на Разговорный клуб — Vosca',
    html: mailLayout('Ссылка на Разговорный клуб', `<p>Здравствуйте, ${esc(u.name)}! Преподаватель <b>${esc(actor.name)}</b> прислал ссылку на встречи клуба:</p><p><a href="${esc(url)}">${esc(url)}</a></p><p>Одна и та же ссылка подходит для всех занятий клуба. Расписание — в личном кабинете.</p>`, { label: 'Открыть клуб', url: env.baseUrl() + '/#/club' }),
    text: 'Ссылка на Разговорный клуб: ' + url }));
  return { sent: people.length };
}
function clubLinkSet(actor, b) {
  if (!isTeacher(actor)) throw new HttpError(403, 'Только для преподавателя');
  const raw = str(b.url, 300).trim(), url = raw ? safeUrl(raw) : '';
  if (url === null) throw new HttpError(400, 'Ссылка на встречу должна начинаться с https://');
  const l = clubLink(), changed = url !== (l.url || '');
  l.url = url || ''; l.by = actor.id; l.at = now();
  const out = { link: clubLinkView(), sent: 0 };
  if (b.notify && url && changed) out.sent = clubLinkSend(actor).sent;
  return out;
}

/* ───────────── Разговорный клуб: занятия ───────────── */
const isClubManager = (a, s) => !!a && (a.role === 'admin' || (a.role === 'teacher' && a.id === s.teacher));
function clubSession(id) { const s = db.club[+id]; if (!s) throw new HttpError(404, 'Занятие клуба не найдено'); return s; }
function clubBusy(uid, start, dur, except) {                  // у ученика уже есть что-то в это время (except — само занятие, его не считаем)
  const mine = Object.values(db.club).filter(s => s !== except && s.members.includes(uid));
  return overlaps(Object.values(db.live).filter(x => x.student === uid), start, dur) || overlaps(mine, start, dur);
}
function clubSessionView(s, viewer) {
  const t = userById(s.teacher), member = !!viewer && s.members.includes(viewer.id), manager = isClubManager(viewer, s);
  const v = { id: s.id, title: s.title, lang: s.lang, level: s.level, starts: s.starts, dur: s.dur, end: sessionEnd(s), status: s.status, cap: s.cap, taken: s.members.length, free: Math.max(0, s.cap - s.members.length),
    teacher: { id: s.teacher, name: t ? t.name : '—', photo: photoSrc(s.teacher), headline: t ? pickLang(profileOf(t).headline, profileOf(t).headline_en) : '' },
    joined: member, series: s.series || 0, reason: s.reason || '' };
  if (member || manager) v.url = clubUrlOf(s);
  if (manager) v.members = s.members.map(id => { const u = userById(id); return { id, name: u ? u.name : '—', email: u ? u.email : '' }; });
  if (viewer && viewer.role === 'student' && !member && s.status === 'planned') {
    if (!clubActive(viewer.id, s.starts)) { const st = db.subs[viewer.id]; v.block = !st ? 'nosub' : (clubActive(viewer.id) ? 'late' : 'expired'); }
    else if (s.members.length >= s.cap) v.block = 'full';
    else if (clubBusy(viewer.id, s.starts, s.dur)) v.block = 'busy';
  }
  return v;
}
function createClubSessions(actor, b) {
  if (!isTeacher(actor)) throw new HttpError(403, 'Только для преподавателя');
  const teacher = actor.role === 'admin' ? userById(+b.teacher) : actor;
  if (!teacher || !isTeacher(teacher)) throw new HttpError(400, 'Выберите преподавателя');
  const start = Math.floor(Number(b.start)), dur = clampInt(b.dur, 60, 15, 180), cap = clampInt(b.cap, CLUB_CAP, 2, 50), repeat = clampInt(b.repeat, 1, 1, 26);
  if (!Number.isFinite(start) || start < now() - 5 * MIN) throw new HttpError(400, 'Время начала должно быть в будущем');
  const url = b.url ? safeUrl(b.url) : '';                         // у клуба одна общая ссылка (см. clubLink) — личная нужна лишь как исключение
  if (url === null) throw new HttpError(400, 'Ссылка на встречу должна начинаться с https://');
  const lang = CLUB_LANGS.includes(str(b.lang, 20)) ? str(b.lang, 20) : CLUB_LANGS[0], title = str(b.title, 100) || 'Разговорный клуб · ' + lang, level = str(b.level, 20);
  const series = repeat > 1 ? nextId('series') : 0, tTz = tzOf(teacher), busy = Object.values(db.live).concat(Object.values(db.club)).filter(x => x.teacher === teacher.id);
  const times = [];
  for (let i = 0; i < repeat; i++) { const at = i ? addWeeks(start, tTz, i) : start; if (overlaps(busy, at, dur)) throw new HttpError(409, `У преподавателя занято: ${fmtDT(at, tTz)}`); times.push(at); }
  return times.map(at => {
    const s = { id: nextId('club'), teacher: teacher.id, title, lang, level, starts: at, dur, cap, url: url || '', status: 'planned', members: [], series, by: actor.id, created: now(), r24: at - now() < 26 * HOUR ? 1 : 0, r15: 0 };
    db.club[s.id] = s; return clubSessionView(s, actor);
  });
}
function clubBook(student, id) {
  const s = clubSession(id);
  if (s.status !== 'planned' || s.starts < now() - 5 * MIN) throw new HttpError(409, 'На это занятие уже нельзя записаться');
  if (s.members.includes(student.id)) throw new HttpError(409, 'Вы уже записаны');
  if (!clubActive(student.id, s.starts)) {
    const st = db.subs[student.id];
    if (!st) throw new HttpError(403, 'Для записи нужна подписка на Разговорный клуб — обратитесь в школу или введите код доступа', { club: 'nosub' });
    throw new HttpError(403, clubActive(student.id) ? `Ваша подписка заканчивается ${fmtLongDate(st.until, tzOf(student))} — раньше этого занятия. Продлите подписку, чтобы записаться` : 'Подписка на клуб закончилась — продлите её, чтобы записаться', { club: clubActive(student.id) ? 'late' : 'expired' });
  }
  if (s.members.length >= s.cap) throw new HttpError(409, 'Все места заняты');
  if (clubBusy(student.id, s.starts, s.dur)) throw new HttpError(409, 'В это время у вас уже есть другое занятие');
  s.members.push(student.id); touch(student.id);
  const tz = tzOf(student);
  notify(student.id, 'club_booked', '🎤 Вы записаны в клуб', `${s.title} · ${fmtDT(s.starts, tz)}`, '#/club', {
    subject: `Вы записаны в клуб — ${fmtDate(s.starts, tz)}, ${fmtTime(s.starts, tz)}`,
    html: mailLayout('Вы записаны в Разговорный клуб', `<p><b>${esc(fmtDT(s.starts, tz))}</b></p><p>${esc(s.title)} · ${s.dur} мин<br>Преподаватель: <b>${esc(nameOf(s.teacher))}</b></p>${clubUrlOf(s) ? `<p>Ссылка на встречу: <a href="${esc(clubUrlOf(s))}">${esc(clubUrlOf(s))}</a></p>` : ''}`, { label: 'Открыть клуб', url: env.baseUrl() + '/#/club' }),
    text: `Вы записаны: ${s.title}, ${fmtDT(s.starts, tz)}. ${clubUrlOf(s)}` });
  notify(s.teacher, 'club_join', `${student.name} записался(лась) в клуб`, `${s.title} · ${fmtDT(s.starts, tzOf(userById(s.teacher)))} · ${s.members.length}/${s.cap}`, '#/teach/club');
  return clubSessionView(s, student);
}
function clubUnbook(student, id) {
  const s = clubSession(id); if (!s.members.includes(student.id)) throw new HttpError(409, 'Вы не записаны на это занятие');
  if (s.status !== 'planned') throw new HttpError(409, 'Занятие уже нельзя изменить');
  s.members = s.members.filter(x => x !== student.id);
  return clubSessionView(s, student);
}
function clubNotifyMembers(kind, s) {
  s.members.forEach(uid => {
    const u = userById(uid); if (!u) return; const tz = tzOf(u), when = fmtDT(s.starts, tz);
    const T = { cancelled: ['❌ Занятие клуба отменено', 'Занятие клуба отменено'], moved: ['🕒 Занятие клуба перенесено', 'Занятие клуба перенесено'], r24: ['⏰ Завтра занятие клуба', 'Напоминание: клуб завтра'], r15: ['🎤 Клуб начинается', 'Клуб начинается'] }[kind];
    const link = kind === 'cancelled' ? '' : clubUrlOf(s) ? `<p>Ссылка на встречу: <a href="${esc(clubUrlOf(s))}">${esc(clubUrlOf(s))}</a></p>` : '<p>Ссылка появится в личном кабинете.</p>';
    notify(uid, 'club_' + kind, T[0], `${s.title} · ${when}`, '#/club', { subject: `${T[1]} — ${fmtDate(s.starts, tz)}, ${fmtTime(s.starts, tz)}`,
      html: mailLayout(T[1], `<p><b>${esc(when)}</b></p><p>${esc(s.title)} · ${s.dur} мин<br>Преподаватель: <b>${esc(nameOf(s.teacher))}</b></p>${kind === 'cancelled' ? (s.reason ? `<p>Причина: ${esc(s.reason)}</p>` : '') : link}`, { label: kind === 'r15' && clubUrlOf(s) ? 'Подключиться' : 'Открыть клуб', url: kind === 'r15' && clubUrlOf(s) ? s.url : env.baseUrl() + '/#/club' }),
      text: `${T[1]}: ${s.title}, ${when}. ${clubUrlOf(s)}` });
  });
  if (kind === 'r24' || kind === 'r15') notify(s.teacher, 'club_' + kind, kind === 'r15' ? '🎤 Клуб начинается' : '⏰ Завтра занятие клуба', `${s.title} · ${fmtDT(s.starts, tzOf(userById(s.teacher)))} · записано ${s.members.length}`, '#/teach/club');
}
function clubCancel(actor, id, reason, wholeSeries) {
  const s = clubSession(id); if (!isClubManager(actor, s)) throw new HttpError(403, 'Нет доступа');
  const targets = wholeSeries && s.series ? Object.values(db.club).filter(x => x.series === s.series && x.status === 'planned' && x.starts >= s.starts) : [s];
  targets.forEach(x => { x.status = 'cancelled'; x.reason = str(reason, 200); clubNotifyMembers('cancelled', x); });
  return { cancelled: targets.length };
}
function clubMove(actor, id, start) {
  const s = clubSession(id); if (!isClubManager(actor, s)) throw new HttpError(403, 'Нет доступа');
  start = Math.floor(Number(start)); if (!Number.isFinite(start) || start < now() - 5 * MIN) throw new HttpError(400, 'Время должно быть в будущем');
  const busy = Object.values(db.live).concat(Object.values(db.club)).filter(x => x !== s && x.teacher === s.teacher);
  if (overlaps(busy, start, s.dur)) throw new HttpError(409, 'У преподавателя занято в это время');
  s.starts = start; s.r24 = start - now() < 26 * HOUR ? 1 : 0; s.r15 = 0; s.status = 'planned';
  s.members = s.members.filter(uid => { if (clubActive(uid, start) && !clubBusy(uid, start, s.dur, s)) return true; notify(uid, 'club_trim', 'Запись в клуб снята', `${s.title} перенесено на время, когда подписка уже закончится или у вас занято`, '#/club'); return false; });
  clubNotifyMembers('moved', s); return clubSessionView(s, actor);
}
function clubDone(actor, id) {
  const s = clubSession(id); if (!isClubManager(actor, s)) throw new HttpError(403, 'Нет доступа');
  if (s.status === 'cancelled') throw new HttpError(409, 'Занятие отменено');
  s.status = 'done'; s.members.forEach(uid => { touch(uid); evalAch(uid); }); return clubSessionView(s, actor);
}
function clubKick(actor, id, uid) {
  const s = clubSession(id); if (!isClubManager(actor, s)) throw new HttpError(403, 'Нет доступа');
  if (!s.members.includes(+uid)) throw new HttpError(404, 'Ученик не записан');
  s.members = s.members.filter(x => x !== +uid);
  notify(+uid, 'club_trim', 'Запись в клуб снята', `${s.title} · ${fmtDT(s.starts, tzOf(userById(+uid)))}`, '#/club');
  return clubSessionView(s, actor);
}
function clubTeacherPanel(actor, teacherId) {
  const tid = actor.role === 'admin' && teacherId ? +teacherId : actor.id, t = now();
  const all = Object.values(db.club).filter(s => s.teacher === tid).sort((a, b) => a.starts - b.starts);
  const up = all.filter(s => s.status === 'planned' && sessionEnd(s) > t - 2 * HOUR);
  return { now: t, tz: tzOf(actor), link: clubLinkView(), teacher: { id: tid, name: nameOf(tid), meeting_url: (userById(tid) || {}).meeting_url || '' }, langs: CLUB_LANGS, cap: CLUB_CAP,
    upcoming: up.map(s => clubSessionView(s, actor)), recent: all.filter(s => !up.includes(s)).slice(-15).reverse().map(s => clubSessionView(s, actor)),
    teachers: actor.role === 'admin' ? Object.values(db.users).filter(isTeacher).map(u => ({ id: u.id, name: u.name })) : undefined };
}
/* страница клуба для ученика */
function clubFor(u) {
  const t = now(), all = Object.values(db.club).sort((a, b) => a.starts - b.starts);
  const upcoming = all.filter(s => s.status === 'planned' && sessionEnd(s) > t);
  const past = all.filter(s => s.members.includes(u.id) && !(s.status === 'planned' && sessionEnd(s) > t)).slice(-8).reverse();
  return { now: t, tz: tzOf(u), linkSet: !!clubLink().url, sub: clubStatus(u.id), upcoming: upcoming.map(s => clubSessionView(s, u)), past: past.map(s => clubSessionView(s, u)), langs: CLUB_LANGS,
    contacts: CONTACTS(), hist: ((db.subs[u.id] || {}).hist || []).slice(-5).reverse().map(h => ({ at: h.at, act: h.act, until: h.until })) };
}
function clubNextFor(uid) {
  const l = Object.values(db.club).filter(s => s.status === 'planned' && s.members.includes(uid) && sessionEnd(s) > now()).sort((a, b) => a.starts - b.starts)[0];
  return l ? clubSessionView(l, userById(uid)) : null;
}

/* ───────────── админ: подписчики и занятия клуба ───────────── */
function adminClub() {
  const t = now(), rows = [];
  Object.keys(db.subs).forEach(id => {
    const u = userById(+id); if (!u) return; const st = clubStatus(+id);
    const booked = Object.values(db.club).filter(s => s.status === 'planned' && s.starts > t && s.members.includes(+id)).length;
    rows.push(Object.assign({ id: u.id, name: u.name, email: u.email, tz: tzOf(u), booked, by: (db.subs[id].by && nameOf(db.subs[id].by)) || '' }, st));
  });
  const order = { expiring: 0, active: 1, expired: 2 };
  rows.sort((a, b) => (order[a.state] - order[b.state]) || ((a.until || Infinity) - (b.until || Infinity)));
  const stats = { active: rows.filter(r => r.active).length, expiring: rows.filter(r => r.state === 'expiring').length, expired: rows.filter(r => r.state === 'expired').length, lifetime: rows.filter(r => r.active && r.lifetime).length };
  const all = Object.values(db.club).sort((a, b) => a.starts - b.starts), up = all.filter(s => s.status === 'planned' && sessionEnd(s) > t - 2 * HOUR), admin = { id: 0, role: 'admin' };
  return { now: t, stats, subs: rows, students: Object.values(db.users).filter(u => u.role === 'student').map(u => ({ id: u.id, name: u.name, email: u.email })).sort((a, b) => a.name.localeCompare(b.name)),
    upcoming: up.map(s => clubSessionView(s, admin)), recent: all.filter(s => !up.includes(s)).slice(-20).reverse().map(s => clubSessionView(s, admin)), langs: CLUB_LANGS, cap: CLUB_CAP,
    link: clubLinkView(),
    teachers: Object.values(db.users).filter(isTeacher).map(u => ({ id: u.id, name: u.name })) };
}
function adminClubUser(b) {
  const raw = b.user, u = /^\d+$/.test(String(raw)) ? userById(+raw) : userByEmail(raw);
  if (!u || u.role !== 'student') throw new HttpError(404, 'Ученик с таким email не найден');
  return u;
}

/* ───────────── фоновые задачи: напоминания и окончание подписок ───────────── */
function tickClub() {
  const t = now(); let n = 0;
  Object.values(db.club).forEach(s => {
    if (s.status !== 'planned') return;
    const left = s.starts - t;
    if (!s.r24 && left <= 24 * HOUR && left > 2 * HOUR) { s.r24 = 1; clubNotifyMembers('r24', s); n++; }
    if (!s.r15 && left <= 15 * MIN && left > -10 * MIN) { s.r15 = 1; s.r24 = 1; clubNotifyMembers('r15', s); n++; }
    if (t > sessionEnd(s) + 3 * HOUR) { s.status = 'done'; s.auto = 1; s.members.forEach(uid => { touch(uid); evalAch(uid); }); n++; }
  });
  Object.keys(db.subs).forEach(id => {
    const s = db.subs[id]; if (!s.until || !userById(+id)) return; const left = s.until - t;
    if (left <= 0) { if (!s.exp) { s.exp = s.w7 = s.d1 = 1; clubNotify('exp', +id); n++; } }
    else if (daysLeft(s.until) <= 1) { if (!s.d1) { s.d1 = s.w7 = 1; clubNotify('d1', +id); n++; } }
    else if (daysLeft(s.until) <= 7) { if (!s.w7) { s.w7 = 1; clubNotify('w7', +id); n++; } }
  });
  return n;
}
