/* ═══════════ Адаптер уроков ═══════════
   Уроки, собранные нашим конструктором раньше, не умеют разговаривать с платформой (сообщать прогресс, отдавать «паспорт»).
   При загрузке в платформу к такому файлу автоматически дописывается маленький скрипт — сам урок не меняется,
   а открытый отдельно (двойным кликом) работает как прежде. */
function voscaAdapterRuntime() {
  if (window.__voscaAdapter) return; window.__voscaAdapter = 1;
  var EMBED; try { EMBED = window.parent !== window; } catch (e) { EMBED = true; }
  if (!EMBED) return;
  var st = document.createElement('style'); st.textContent = '.nextcard em{display:none!important}'; document.head.appendChild(st);
  function taskList() { return (typeof TASKS !== 'undefined' ? TASKS : typeof TASK_IDS !== 'undefined' ? TASK_IDS : []).filter(function (x) { return x !== 'rate'; }); }
  function snap() {
    var req = taskList(), done = req.filter(function (x) { return State.done.has(x); }).length;
    return { source: 'vosca-lesson', type: 'progress', done: done, total: req.length, tries: State.tries || 0, hits: State.hits || 0, xp: State.xp || 0, seconds: State.t0 ? Math.round((Date.now() - State.t0) / 1000) : 0 };
  }
  var last = '', lastAt = 0;
  function report() {
    try { var m = snap(), sig = [m.done, m.tries, m.hits, m.xp].join(); if (sig !== last || Date.now() - lastAt > 15000) { last = sig; lastAt = Date.now(); parent.postMessage(m, '*'); } } catch (e) { }
  }
  setInterval(report, 800);
  window.addEventListener('message', function (e) {
    var d = e.data; if (!d || d.source !== 'vosca-host' || d.type !== 'getMeta') return;
    var reply = function (o) { o.source = 'vosca-lesson'; o.type = 'meta'; (e.source || parent).postMessage(o, '*'); };
    try {
      var plain = function (x) { if (Array.isArray(x)) x = x[0]; return String(x || '').replace(/<[^>]+>/g, '').replace(/\{\{([^{}|]+)[^{}]*\}\}/g, '$1'); };
      var F = typeof fx === 'function' ? fx : function (x) { return x; };
      var bank = [];
      if (typeof QZ !== 'undefined') Object.keys(QZ).forEach(function (id) { (QZ[id] || []).forEach(function (q, i) { bank.push({ id: id + ':' + i, q: F(q.q), say: q.say || '', opts: q.opts.map(function (o) { return F(o[0]); }), a: q.opts.findIndex(function (o) { return o[1]; }), why: F(q.why || '') }); }); });
      var L = typeof LESSON !== 'undefined' ? LESSON : {};
      var title = plain(L.title) || plain(document.title).replace(/^Vosca\s*[·\-]\s*/, '');
      reply({ meta: { title: title, th: L.titleTh || '', min: typeof TOTAL_MIN !== 'undefined' ? TOTAL_MIN : 30, tasks: taskList().length, lead: plain(L.lead).slice(0, 160) }, bank: bank });
    } catch (err) { reply({ error: String(err) }); }
  });
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a[href]'); if (!a) return;
    var h = a.getAttribute('href') || '';
    if (/\.html($|#)/.test(h) && !/^https?:/.test(h)) { e.preventDefault(); try { parent.postMessage({ source: 'vosca-lesson', type: 'next', href: h }, '*'); } catch (_) { } }
  }, true);
  try { parent.postMessage({ source: 'vosca-lesson', type: 'ready' }, '*'); } catch (e) { }
}
/* вернёт доработанный HTML; null — если файл не похож на урок Vosca */
function adaptLesson(html) {
  html = String(html || '');
  if (html.indexOf('vosca-lesson') >= 0) return html;
  const engine = /const State\b/.test(html) && /const LESSON\b/.test(html) && (/const TASKS\b/.test(html) || /const TASK_IDS\b/.test(html));
  if (!engine) return null;
  const tag = '<script>(' + voscaAdapterRuntime.toString() + ')();<' + '/script>', i = html.lastIndexOf('</body>');
  return i >= 0 ? html.slice(0, i) + tag + html.slice(i) : html + tag;
}
