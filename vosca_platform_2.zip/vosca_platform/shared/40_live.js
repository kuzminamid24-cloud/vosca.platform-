/* ═══════════ Живые уроки: расписание, преподаватели, видеоссылки, календарь, напоминания ═══════════ */

const isTeacher = u => !!u && (u.role === 'teacher' || u.role === 'admin');
const JOIN_BEFORE = 10 * MIN;            // кнопка «Подключиться» активна за 10 минут до начала
const LIVE_STATUSES = ['planned', 'done', 'cancelled'];

function sessionEnd(s) { return s.starts + s.dur * MIN; }
function canManage(actor, s) { return !!actor && (actor.role === 'admin' || (actor.role === 'teacher' && s.teacher === actor.id)); }
function nameOf(uid) { const u = userById(uid); return u ? u.name : 'Пользователь удалён'; }

function sessionView(s, forUser) {
  const t = userById(s.teacher), st = userById(s.student), c = courseById(s.course);
  const v = { id: s.id, starts: s.starts, dur: s.dur, end: sessionEnd(s), title: s.title || (c ? c.title : 'Урок'), course: s.course, courseTitle: c ? c.title : s.course,
    status: s.status, url: s.url || '', note: s.note || '', noteAt: s.noteAt || null, reason: s.reason || '', series: s.series || 0,
    teacher: { id: s.teacher, name: t ? t.name : '—', photo: photoSrc(s.teacher) }, declined: !!s.declined, declineReason: s.declineReason || '' };
  if (forUser && forUser.id !== s.student) v.student = { id: s.student, name: st ? st.name : '—', tz: tzOf(st) };
  return v;
}

function nextLiveFor(uid) {
  const list = Object.values(db.live).filter(s => s.student === uid && s.status === 'planned' && sessionEnd(s) > now()).sort((a, b) => a.starts - b.starts);
  return list[0] ? sessionView(list[0], userById(uid)) : null;
}

function scheduleFor(u) {
  const t = now();
  const mine = Object.values(db.live).filter(s => s.student === u.id).sort((a, b) => a.starts - b.starts);
  const upcoming = mine.filter(s => s.status === 'planned' && sessionEnd(s) > t - HOUR);
  const past = mine.filter(s => !(s.status === 'planned' && sessionEnd(s) > t - HOUR)).slice(-15).reverse();
  const teachers = [];
  Object.keys(db.assign[u.id] || {}).forEach(cid => { const tt = userById(db.assign[u.id][cid]); if (tt) teachers.push({ id: tt.id, name: tt.name, bio: pickLang(profileOf(tt).bio, profileOf(tt).bio_en), headline: pickLang(profileOf(tt).headline, profileOf(tt).headline_en), photo: photoSrc(tt.id), course: cid, courseTitle: (courseById(cid) || {}).title || cid, email: tt.email }); });
  return { now: t, tz: tzOf(u), upcoming: upcoming.map(s => sessionView(s, u)), past: past.map(s => sessionView(s, u)), teachers, calUrl: env.baseUrl() + '/cal/' + u.cal + '.ics', joinBefore: JOIN_BEFORE };
}

/* ── письма и уведомления о занятиях ── */
function liveMail(kind, s, to) {
  const tz = tzOf(to), when = fmtDT(s.starts, tz), c = courseById(s.course), teacher = nameOf(s.teacher), student = nameOf(s.student);
  const who = to.id === s.teacher ? `Ученик: <b>${esc(student)}</b>` : `Преподаватель: <b>${esc(teacher)}</b>`;
  const link = s.url ? `<p>Ссылка на видеовстречу: <a href="${esc(s.url)}">${esc(s.url)}</a></p>` : '<p>Ссылка на встречу появится в личном кабинете.</p>';
  const plainLink = s.url ? `Ссылка: ${s.url}` : '';
  const T = {
    new: ['Назначен урок', `Назначен урок «${s.title}»`, 'Расписание'],
    moved: ['Урок перенесён', `Урок «${s.title}» перенесён`, 'Расписание'],
    cancelled: ['Урок отменён', `Урок «${s.title}» отменён`, 'Расписание'],
    r24: ['Напоминание: урок завтра', `Завтра урок «${s.title}»`, 'Открыть расписание'],
    r15: ['Урок начинается', `Через 15 минут начнётся урок «${s.title}»`, 'Подключиться']
  }[kind];
  const html = mailLayout(T[1], `<p style="font-size:16px"><b>${esc(when)}</b></p><p>${esc(c ? c.title : '')} · ${s.dur} мин<br>${who}</p>${kind === 'cancelled' ? `<p>${s.reason ? 'Причина: ' + esc(s.reason) : ''}</p>` : link}`,
    { label: T[2], url: kind === 'r15' && s.url ? s.url : env.baseUrl() + '/#/schedule' });
  return { subject: `${T[0]} — ${fmtDate(s.starts, tz)}, ${fmtTime(s.starts, tz)}`, html, text: `${T[1]}. ${when}. ${plainLink}` };
}
function notifyLive(kind, s, who) {
  const u = userById(who); if (!u) return;
  const title = { new: '🎥 Назначен урок', moved: '🕒 Урок перенесён', cancelled: '❌ Урок отменён', r24: '⏰ Завтра урок', r15: '🎥 Урок начинается' }[kind];
  notify(who, 'live_' + kind, title, `${fmtDT(s.starts, tzOf(u))} · ${nameOf(who === s.teacher ? s.student : s.teacher)}`, '#/schedule', liveMail(kind, s, u));
}

/* ── создание и изменение занятий ── */
function overlaps(list, start, dur, exceptId) {
  return list.some(x => x.status === 'planned' && x.id !== exceptId && start < sessionEnd(x) && x.starts < start + dur * MIN);
}
function createSessions(actor, b, opts) {
  if (!isTeacher(actor)) throw new HttpError(403, 'Только для преподавателя');
  const teacher = actor.role === 'admin' ? userById(+b.teacher) : actor;
  if (!teacher || !isTeacher(teacher)) throw new HttpError(400, 'Выберите преподавателя');
  const student = userById(+b.student); if (!student || student.role !== 'student') throw new HttpError(400, 'Выберите ученика');
  const course = courseById(str(b.course, 40)); if (!course) throw new HttpError(400, 'Выберите курс');
  if (!activeEnroll(student.id, course.id)) throw new HttpError(400, 'У ученика нет доступа к этому курсу');
  if (!teachesCourse(teacher, course.id)) throw new HttpError(400, 'Этот преподаватель не ведёт выбранный язык — «' + course.title + '»');
  const assigned = (db.assign[student.id] || {})[course.id];
  if (actor.role === 'teacher' && assigned !== actor.id && !(opts && opts.fromRequest)) throw new HttpError(403, 'Этот ученик закреплён за другим преподавателем');
  if (!assigned) { db.assign[student.id] = db.assign[student.id] || {}; db.assign[student.id][course.id] = teacher.id; }
  const start = Math.floor(Number(b.start)), dur = clampInt(b.dur, 50, 15, 240), repeat = clampInt(b.repeat, 1, 1, 26);
  if (!Number.isFinite(start) || start < now() - 5 * MIN) throw new HttpError(400, 'Время начала должно быть в будущем');
  const url = b.url ? safeUrl(b.url) : safeUrl(teacher.meeting_url);
  if (url === null) throw new HttpError(400, 'Ссылка на встречу должна начинаться с https://');
  const title = str(b.title, 100) || course.title;
  const series = repeat > 1 ? nextId('series') : 0, made = [];
  const tTz = tzOf(teacher), tList = Object.values(db.live).filter(x => x.teacher === teacher.id), sList = Object.values(db.live).filter(x => x.student === student.id);
  for (let i = 0; i < repeat; i++) {
    const at = i ? addWeeks(start, tTz, i) : start;
    if (overlaps(tList, at, dur)) throw new HttpError(409, `У преподавателя занято: ${fmtDT(at, tTz)}`);
    if (overlaps(sList, at, dur)) throw new HttpError(409, `У ученика занято: ${fmtDT(at, tzOf(student))}`);
    made.push(at);
  }
  const out = made.map(at => {
    const s = { id: nextId('live'), teacher: teacher.id, student: student.id, course: course.id, starts: at, dur, title, url: url || '', status: 'planned', note: '', series, by: actor.id, created: now(), r24: at - now() < 26 * HOUR ? 1 : 0, r15: 0 };
    db.live[s.id] = s; return s;
  });
  notifyLive('new', out[0], student.id);
  if (out.length > 1) notify(student.id, 'live_series', `Назначено ещё ${out.length - 1} ${out.length === 2 ? 'занятие' : 'занятий'} по тому же дню`, 'Они в вашем расписании', '#/schedule');
  return out.map(s => sessionView(s, actor));
}

function getSession(id) { const s = db.live[+id]; if (!s) throw new HttpError(404, 'Занятие не найдено'); return s; }
function moveSession(actor, id, start) {
  const s = getSession(id); if (!canManage(actor, s)) throw new HttpError(403, 'Нет доступа');
  start = Math.floor(Number(start)); if (!Number.isFinite(start) || start < now() - 5 * MIN) throw new HttpError(400, 'Время должно быть в будущем');
  if (overlaps(Object.values(db.live).filter(x => x.teacher === s.teacher), start, s.dur, s.id)) throw new HttpError(409, 'У преподавателя занято в это время');
  if (overlaps(Object.values(db.live).filter(x => x.student === s.student), start, s.dur, s.id)) throw new HttpError(409, 'У ученика занято в это время');
  s.starts = start; s.r24 = start - now() < 26 * HOUR ? 1 : 0; s.r15 = 0; s.status = 'planned'; s.declined = 0;
  notifyLive('moved', s, s.student); return sessionView(s, actor);
}
function cancelSession(actor, id, reason, wholeSeries) {
  const s = getSession(id); if (!canManage(actor, s)) throw new HttpError(403, 'Нет доступа');
  const targets = wholeSeries && s.series ? Object.values(db.live).filter(x => x.series === s.series && x.status === 'planned' && x.starts >= s.starts) : [s];
  targets.forEach(x => { x.status = 'cancelled'; x.reason = str(reason, 200); });
  notifyLive('cancelled', s, s.student);
  return { cancelled: targets.length };
}
function finishSession(actor, id, note) {
  const s = getSession(id); if (!canManage(actor, s)) throw new HttpError(403, 'Нет доступа');
  if (s.status === 'cancelled') throw new HttpError(409, 'Занятие отменено');
  s.status = 'done'; if (note !== undefined && str(note, 1000)) { s.note = str(note, 1000); s.noteAt = now(); notify(s.student, 'teacher_note', '💬 Заметка преподавателя', s.note.slice(0, 120), '#/schedule'); }
  touch(s.student); evalAch(s.student); return sessionView(s, actor);
}
function noteSession(actor, id, note) {
  const s = getSession(id); if (!canManage(actor, s)) throw new HttpError(403, 'Нет доступа');
  s.note = str(note, 1000); s.noteAt = now(); if (s.note) notify(s.student, 'teacher_note', '💬 Заметка преподавателя', s.note.slice(0, 120), '#/schedule');
  return sessionView(s, actor);
}
function declineSession(student, id, reason) {
  const s = getSession(id); if (s.student !== student.id) throw new HttpError(403, 'Нет доступа');
  if (s.status !== 'planned') throw new HttpError(409, 'Занятие уже нельзя изменить');
  s.declined = 1; s.declineReason = str(reason, 200) || 'Не смогу присутствовать';
  notify(s.teacher, 'live_decline', `${student.name} не сможет прийти`, `${fmtDT(s.starts, tzOf(userById(s.teacher)))} · ${s.declineReason}`, '#/teach', {
    subject: `${student.name} просит перенести урок`,
    html: mailLayout('Ученик просит перенести урок', `<p><b>${esc(student.name)}</b> не сможет прийти на урок ${esc(fmtDT(s.starts, tzOf(userById(s.teacher))))}.</p><p>Причина: ${esc(s.declineReason)}</p>`, { label: 'Открыть расписание', url: env.baseUrl() + '/#/teach' }),
    text: `${student.name} не сможет прийти. ${s.declineReason}`
  });
  return sessionView(s, student);
}

/* ── кабинет преподавателя ── */
function teacherPanel(actor, teacherId) {
  const tid = actor.role === 'admin' && teacherId ? +teacherId : actor.id;
  const t = now();
  const sessions = Object.values(db.live).filter(s => s.teacher === tid).sort((a, b) => a.starts - b.starts);
  const upcoming = sessions.filter(s => s.status === 'planned' && sessionEnd(s) > t - 2 * HOUR);
  const recent = sessions.filter(s => !(s.status === 'planned' && sessionEnd(s) > t - 2 * HOUR)).slice(-20).reverse();
  const students = [];
  Object.keys(db.assign).forEach(sid => Object.keys(db.assign[sid]).forEach(cid => {
    if (db.assign[sid][cid] !== tid) return; const su = userById(+sid); if (!su) return;
    const c = courseById(cid), P = db.progress[su.id] || {}, passed = c ? c.lessons.filter(l => P[l.key] && P[l.key].passed_at).length : 0;
    const act = db.activity[su.id] || {}, days = Object.keys(act).sort();
    students.push({ id: su.id, name: su.name, email: su.email, tz: tzOf(su), course: cid, courseTitle: c ? c.title : cid, passed, total: c ? c.lessons.length : 0, active: !!activeEnroll(su.id, cid), lastDay: days[days.length - 1] || null });
  }));
  const tu = userById(tid);
  return { now: t, tz: tzOf(actor), teacher: { id: tid, name: tu ? tu.name : '', meeting_url: tu ? tu.meeting_url : '' }, upcoming: upcoming.map(s => sessionView(s, actor)), recent: recent.map(s => sessionView(s, actor)), students,
    calUrl: env.baseUrl() + '/cal/' + (tu ? tu.cal : '') + '.ics', requests: teacherRequests(tid, actor) };
}

/* ── календарь (.ics) ── */
function icsEscape(s) { return String(s || '').replace(/\\/g, '\\\\').replace(/\n/g, '\\n').replace(/,/g, '\\,').replace(/;/g, '\\;'); }
function icsDate(ts) { return new Date(ts).toISOString().replace(/[-:]/g, '').replace(/\.\d+Z$/, 'Z'); }
function icsFold(line) { const out = []; let s = line; while (s.length > 74) { out.push(s.slice(0, 74)); s = ' ' + s.slice(74); } out.push(s); return out.join('\r\n'); }
function icsFor(u) {
  const since = now() - 14 * DAY;
  const list = Object.values(db.live).filter(s => (s.student === u.id || s.teacher === u.id) && s.starts > since && s.status !== 'cancelled')
    .concat(Object.values(db.club).filter(s => (s.teacher === u.id || s.members.includes(u.id)) && s.starts > since && s.status !== 'cancelled').map(s => Object.assign({}, s, { id: 'c' + s.id, student: 0, title: s.title })));
  const L = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Vosca//Schedule//RU', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH', 'X-WR-CALNAME:Vosca — уроки', 'REFRESH-INTERVAL;VALUE=DURATION:PT1H'];
  list.forEach(s => {
    const other = s.student === 0 ? 'Разговорный клуб · ' + nameOf(s.teacher) : u.id === s.teacher ? 'Ученик: ' + nameOf(s.student) : 'Преподаватель: ' + nameOf(s.teacher);
    L.push('BEGIN:VEVENT', `UID:vosca-live-${s.id}@vosca`, `DTSTAMP:${icsDate(s.created || now())}`, `DTSTART:${icsDate(s.starts)}`, `DTEND:${icsDate(sessionEnd(s))}`,
      icsFold('SUMMARY:' + icsEscape('Vosca: ' + s.title)), icsFold('DESCRIPTION:' + icsEscape(other + (s.url ? '\nВстреча: ' + s.url : ''))));
    if (s.url) L.push(icsFold('LOCATION:' + icsEscape(s.url)), icsFold('URL:' + s.url));
    L.push('BEGIN:VALARM', 'ACTION:DISPLAY', 'DESCRIPTION:Урок скоро начнётся', 'TRIGGER:-PT15M', 'END:VALARM', 'END:VEVENT');
  });
  L.push('END:VCALENDAR'); return L.join('\r\n');
}
function icsByToken(token) {
  for (const id in db.users) if (db.users[id].cal === token) return icsFor(db.users[id]);
  return null;
}

/* ── планировщик: напоминания и автозавершение (вызывать раз в минуту) ── */
function tick() {
  const t = now(); let n = 0;
  Object.values(db.live).forEach(s => {
    if (s.status !== 'planned') return;
    const left = s.starts - t;
    if (!s.r24 && left <= 24 * HOUR && left > 2 * HOUR) { s.r24 = 1; notifyLive('r24', s, s.student); notifyLive('r24', s, s.teacher); n++; }
    if (!s.r15 && left <= 15 * MIN && left > -10 * MIN) { s.r15 = 1; s.r24 = 1; notifyLive('r15', s, s.student); notifyLive('r15', s, s.teacher); n++; }
    if (t > sessionEnd(s) + 3 * HOUR) { s.status = 'done'; s.auto = 1; touch(s.student); evalAch(s.student); }
  });
  return n + tickClub() + tickRequests();
}
