/* ═══════════ API: единая точка входа для сервера и демо ═══════════ */

function needUser(u) { if (!u) throw new HttpError(401, 'Войдите в аккаунт'); return u; }
function needAdmin(u) { needUser(u); if (u.role !== 'admin') throw new HttpError(403, 'Только для администратора'); return u; }
function needTeacher(u) { needUser(u); if (!isTeacher(u)) throw new HttpError(403, 'Только для преподавателя'); return u; }
const CONTACT_DEFAULT = { email: 'voscaofficial0@gmail.com', phone: '+7 931 393-66-85' };      // если администратор не вписал свои
const CONTACTS = () => { const o = operatorInfo(); return { email: str(o.email, 200) || CONTACT_DEFAULT.email, phone: str(o.phone, 60) || CONTACT_DEFAULT.phone }; };

function meBody(u) {
  return { user: pubUser(u), config: { passScore: CFG.PASS_SCORE, hwPass: CFG.HW_PASS, version: LEGAL_VERSION, legal: !!CFG.LEGAL, requireCode: CFG.REQUIRE_CODE !== false, contacts: CONTACTS() },
    needConsent: u ? needConsent(u.id).map(d => ({ id: d, title: LEGAL_DOCS[d].title })) : [], unread: u ? unreadCount(u.id) : 0, ads: u ? adsConsent(u.id) : false, notify: u ? u.notify !== 0 : true };
}

function register(b, ip, ua) {
  const name = str(b.name, 60).replace(/\s+/g, ' '), email = str(b.email, 250).toLowerCase(), pw = String(b.password || ''), c = b.consents || {};
  if (name.length < 1) throw new HttpError(400, 'Введите имя');
  if (!EMAIL_RE.test(email)) throw new HttpError(400, 'Проверьте email');
  if (pw.length < 8 || pw.length > 200) throw new HttpError(400, 'Пароль — не короче 8 символов');
  if (CFG.LEGAL) {
    if (!c.offer) throw new HttpError(400, 'Нужно принять условия оферты');
    if (!c.pd) throw new HttpError(400, 'Без согласия на обработку персональных данных регистрация невозможна');
    if (!c.age) throw new HttpError(400, 'Подтвердите возраст или согласие родителя');
  }
  if (userByEmail(email)) throw new HttpError(409, 'Этот email уже зарегистрирован — войдите');
  const isBoss = !!(ADMIN_EMAIL && email === ADMIN_EMAIL), needCode = CFG.REQUIRE_CODE !== false && !isBoss;
  if (needCode) { if (!str(b.code, 40)) throw new HttpError(400, 'Введите код доступа Vosca — его выдаёт школа. Нет кода? Напишите в школу — контакты внизу страницы.'); codeCheck(b.code); }   // проверяем ДО создания аккаунта
  const u = createUser({ name, email, password: pw, tz: b.tz, role: isBoss ? 'admin' : 'student' });
  recordConsent(u.id, 'offer', 1, ip, ua); recordConsent(u.id, 'consent-pd', 1, ip, ua); recordConsent(u.id, 'age', 1, ip, ua, '1');
  if (c.ads) recordConsent(u.id, 'consent-ads', 1, ip, ua);
  CFG.AUTO_ENROLL.forEach(cid => grantCourse(u.id, cid, null, 'auto'));
  if (needCode) { try { redeemCode(u.id, b.code); } catch (e) { wipeUser(u.id); throw e; } }
  touch(u.id);
  notify(u.id, 'welcome', '👋 Добро пожаловать в Vosca!', 'Загляните в кабинет — там первый шаг', '#/cabinet', {
    subject: 'Добро пожаловать в Vosca', text: 'Вы зарегистрировались в Vosca. ' + env.baseUrl(),
    html: mailLayout(`Добро пожаловать, ${u.name}!`, '<p>Аккаунт создан. В личном кабинете — ваши курсы, расписание занятий и домашние задания.</p>', { label: 'Открыть кабинет', url: env.baseUrl() + '/#/cabinet' })
  });
  return u;
}

/* req: {method, path, query, body, user, ip, ua}. Возвращает {status, body, login?, logout?} */
function handle(req) {
  try { return route(req); }
  catch (e) {
    if (e instanceof HttpError) return { status: e.status, body: Object.assign({ error: e.message }, e.extra || {}) };
    throw e;
  } finally { LANG = 'ru'; }       // фоновые задачи (письма, напоминания) всегда на русском
}
const ok = body => ({ status: 200, body });

function route(req) {
  const m = req.method, p = req.path, b = req.body || {}, u = req.user; let x;
  LANG = req.query && req.query.lang === 'en' ? 'en' : 'ru';

  if (p === '/api/me' && m === 'GET') return ok(meBody(u));
  if ((x = p.match(/^\/api\/legal\/([a-z-]+)$/)) && m === 'GET') { if (!CFG.LEGAL) throw new HttpError(404, 'Не найдено'); const d = legalDoc(x[1]); return ok({ id: d.id, title: d.title, version: d.version, html: d.html, missing: d.missing, required: d.required }); }

  if (p === '/api/register' && m === 'POST') { const nu = register(b, req.ip, req.ua); return { status: 200, body: meBody(nu), login: nu.id }; }
  if (p === '/api/login' && m === 'POST') {
    const lu = userByEmail(str(b.email, 250)), good = env.verifyPassword(String(b.password || ''), lu ? lu.hash : env.dummyHash());
    if (!lu || !good) throw new HttpError(401, 'Неверный email или пароль');
    const portal = str(b.portal, 10);
    if (portal && portal !== lu.role) throw new HttpError(403, WRONG_PORTAL[lu.role] || 'Войдите через свой вход', { wrongPortal: lu.role });
    lu.last = now(); if (validTz(b.tz) && !lu.tzSet) lu.tz = b.tz;
    return { status: 200, body: meBody(lu), login: lu.id };
  }
  if (p === '/api/staff/check' && m === 'POST') { const inv = inviteLookup(b.code); return ok({ role: inv.role }); }
  if (p === '/api/staff/register' && m === 'POST') { const nu = staffRegister(b, req.ip, req.ua); return { status: 200, body: meBody(nu), login: nu.id }; }
  if (p === '/api/logout' && m === 'POST') return { status: 200, body: { ok: true }, logout: true };

  needUser(u);
  if (p === '/api/overview' && m === 'GET') { const ov = overview(u.id); if (u.role === 'student') { const own = ov.courses.filter(c => c.enrolled || c.expired); if (own.length) ov.courses = own; else if (db.subs[u.id]) ov.courses = []; }      // у кого уже есть курс — другие языки не показываем
    return ok(Object.assign(meBody(u), ov, { now: now() })); }
  if (p === '/api/consent/accept' && m === 'POST') {
    (Array.isArray(b.docs) ? b.docs : []).forEach(d => { if (LEGAL_DOCS[d]) recordConsent(u.id, d, 1, req.ip, req.ua); });
    return ok(meBody(u));
  }
  if (needConsent(u.id).length && !/^\/api\/(account\/(export|delete)|notifications)/.test(p)) throw new HttpError(403, 'Нужно принять обновлённые документы', { needConsent: needConsent(u.id) });

  /* аккаунт */
  if (p === '/api/account' && m === 'POST') {
    if (b.name !== undefined) { const n = str(b.name, 60).replace(/\s+/g, ' '); if (!n) throw new HttpError(400, 'Введите имя'); u.name = n; }
    if (b.tz !== undefined) { if (!validTz(b.tz)) throw new HttpError(400, 'Неизвестный часовой пояс'); u.tz = b.tz; u.tzSet = 1; }
    if (b.notify !== undefined) u.notify = b.notify ? 1 : 0;
    if (b.ads !== undefined) { const was = adsConsent(u.id); if (!!b.ads !== was) recordConsent(u.id, 'consent-ads', !!b.ads, req.ip, req.ua); }
    if (u.role !== 'student') { if (b.meeting_url !== undefined) { const url = b.meeting_url ? safeUrl(b.meeting_url) : ''; if (url === null) throw new HttpError(400, 'Ссылка должна начинаться с https://'); u.meeting_url = url; } if (b.bio !== undefined) u.bio = str(b.bio, 400); }
    return ok(meBody(u));
  }
  if (p === '/api/account/password' && m === 'POST') {
    if (!env.verifyPassword(String(b.old || ''), u.hash)) throw new HttpError(403, 'Текущий пароль неверный');
    const np = String(b.password || ''); if (np.length < 8 || np.length > 200) throw new HttpError(400, 'Новый пароль — не короче 8 символов');
    u.hash = env.hashPassword(np); return ok({ ok: true });
  }
  if (p === '/api/account/export' && m === 'GET') return ok(exportData(u.id));
  if (p === '/api/account/delete' && m === 'POST') {
    if (u.role === 'admin') throw new HttpError(400, 'Аккаунт администратора удаляется через настройки сервера');
    if (!env.verifyPassword(String(b.password || ''), u.hash)) throw new HttpError(403, 'Пароль неверный');
    wipeUser(u.id); return { status: 200, body: { ok: true }, logout: true };
  }
  if (p === '/api/redeem' && m === 'POST') { const r = redeemCode(u.id, b.code); return ok(r); }

  /* уведомления */
  if (p === '/api/notifications' && m === 'GET') return ok({ items: (db.notes[u.id] || []).slice(0, 40), unread: unreadCount(u.id) });
  if (p === '/api/notifications/read' && m === 'POST') { (db.notes[u.id] || []).forEach(n => { n.read = 1; }); return ok({ ok: true }); }

  /* обучение */
  if ((x = p.match(/^\/api\/lesson\/([a-z0-9-]+)$/)) && m === 'GET') { const a = lessonAccess(u.id, x[1]); return ok({ course: { id: a.course.id, title: a.course.title }, lesson: a.view, next: a.next, passScore: CFG.PASS_SCORE }); }
  if ((x = p.match(/^\/api\/progress\/([a-z0-9-]+)$/)) && m === 'POST') return ok(recordProgress(u.id, x[1], b));
  if ((x = p.match(/^\/api\/homework\/([a-z0-9-]+)\/submit$/)) && m === 'POST') return ok(submitHomework(u.id, x[1], b.answers));
  if ((x = p.match(/^\/api\/homework\/([a-z0-9-]+)$/)) && m === 'GET') return ok(getHomework(u.id, x[1]));

  /* преподаватели: список и профили видят все вошедшие */
  if (p === '/api/teachers' && m === 'GET') return ok({ teachers: teachersList(u) });
  if ((x = p.match(/^\/api\/teachers\/(\d+)$/)) && m === 'GET') return ok({ teacher: teacherDetail(x[1], u) });

  /* Разговорный клуб: ученик */
  if (p === '/api/club' && m === 'GET') return ok(clubFor(u));
  if ((x = p.match(/^\/api\/club\/(\d+)\/(book|unbook)$/)) && m === 'POST') {
    if (u.role !== 'student') throw new HttpError(403, 'Записываются ученики');
    return ok(x[2] === 'book' ? clubBook(u, x[1]) : clubUnbook(u, x[1]));
  }

  /* расписание ученика */
  if (p === '/api/schedule' && m === 'GET') return ok(Object.assign(scheduleFor(u), reqExtras(u)));
  if (p === '/api/live/request' && m === 'POST') return ok({ request: requestLesson(u, b) });
  if ((x = p.match(/^\/api\/live\/request\/(\d+)\/cancel$/)) && m === 'POST') return ok({ request: requestCancel(u, x[1]) });
  if ((x = p.match(/^\/api\/teach\/requests\/(\d+)\/(accept|decline)$/)) && m === 'POST') { needTeacher(u); return ok(x[2] === 'accept' ? requestAccept(u, x[1], b) : { request: requestDecline(u, x[1], b.reason) }); }
  if ((x = p.match(/^\/api\/schedule\/(\d+)\/decline$/)) && m === 'POST') return ok(declineSession(u, x[1], b.reason));

  /* преподаватель */
  if (p === '/api/teach' && m === 'GET') { needTeacher(u); return ok(teacherPanel(u, req.query && req.query.teacher)); }
  if (p === '/api/teach/sessions' && m === 'POST') { needTeacher(u); return ok({ created: createSessions(u, b) }); }
  if ((x = p.match(/^\/api\/teach\/sessions\/(\d+)\/(move|cancel|done|note)$/)) && m === 'POST') {
    needTeacher(u);
    if (x[2] === 'move') return ok(moveSession(u, x[1], b.start));
    if (x[2] === 'cancel') return ok(cancelSession(u, x[1], b.reason, !!b.series));
    if (x[2] === 'done') return ok(finishSession(u, x[1], b.note));
    return ok(noteSession(u, x[1], b.note));
  }

  /* профиль преподавателя и занятия клуба */
  if (p === '/api/teach/profile' && m === 'GET') { needTeacher(u); return ok(profileEdit(u, req.query && req.query.teacher)); }
  if (p === '/api/teach/profile' && m === 'POST') { needTeacher(u); return ok(saveProfile(u, b)); }
  if (p === '/api/teach/photo' && m === 'POST') { needTeacher(u); return ok(savePhoto(u, b)); }
  if (p === '/api/teach/club' && m === 'GET') { needTeacher(u); return ok(clubTeacherPanel(u, req.query && req.query.teacher)); }
  if (p === '/api/teach/students' && m === 'GET') { needTeacher(u); return ok(teacherStudentsPanel(u, req.query && req.query.teacher)); }
  if (p === '/api/teach/students/take' && m === 'POST') { needTeacher(u); return ok(teacherTake(u, b)); }
  if (p === '/api/teach/materials' && m === 'GET') { needTeacher(u); return ok(teacherMaterials(u)); }
  if (p === '/api/materials' && m === 'GET') { if (u.role !== 'student') throw new HttpError(403, 'Раздел для учеников'); return ok(studentMaterials(u)); }
  if (p === '/api/materials' && m === 'POST') { needTeacher(u); return ok({ material: createMaterial(u, b) }); }
  if ((x = p.match(/^\/api\/materials\/(\d+)\/file$/)) && m === 'GET') return ok(materialFile(u, x[1]));
  if ((x = p.match(/^\/api\/materials\/(\d+)\/(share|unshare|delete)$/)) && m === 'POST') {
    if (x[2] === 'delete') { materialDelete(u, x[1]); return ok({ ok: true }); }
    return ok(x[2] === 'share' ? materialShare(u, x[1], b) : materialUnshare(u, x[1], b.student));
  }
  if (p === '/api/teach/club/link' && m === 'POST') { needTeacher(u); return ok(clubLinkSet(u, b)); }
  if (p === '/api/teach/club/link/send' && m === 'POST') { needTeacher(u); return ok(clubLinkSend(u)); }
  if (p === '/api/teach/club/sessions' && m === 'POST') { needTeacher(u); return ok({ created: createClubSessions(u, b) }); }
  if ((x = p.match(/^\/api\/teach\/club\/sessions\/(\d+)\/(move|cancel|done|kick)$/)) && m === 'POST') {
    needTeacher(u);
    if (x[2] === 'move') return ok(clubMove(u, x[1], b.start));
    if (x[2] === 'cancel') return ok(clubCancel(u, x[1], b.reason, !!b.series));
    if (x[2] === 'done') return ok(clubDone(u, x[1]));
    return ok(clubKick(u, x[1], b.user));
  }

  /* админ */
  if (p.startsWith('/api/admin/')) {
    needAdmin(u);
    if (p === '/api/admin/users' && m === 'GET') return ok(adminUsers());
    if ((x = p.match(/^\/api\/admin\/users\/(\d+)$/)) && m === 'GET') return ok(adminUserDetail(x[1]));
    if (p === '/api/admin/teachers' && m === 'POST') return ok({ teacher: adminCreateTeacher(b) });
    if ((x = p.match(/^\/api\/admin\/users\/(\d+)\/(enroll|pass|reset|password|role|assign|delete|profile|langs)$/)) && m === 'POST') {
      const t = userById(+x[1]); if (!t) throw new HttpError(404, 'Нет такого пользователя');
      switch (x[2]) {
        case 'enroll':
          if (b.on === false) revokeCourse(t.id, str(b.course, 40));
          else { if (!grantCourse(t.id, str(b.course, 40), b.days ? clampInt(b.days, 0, 1, 3650) : null, 'admin')) throw new HttpError(400, 'Курс недоступен');
            const c = courseById(str(b.course, 40)); notify(t.id, 'course', `Открыт курс «${c.title}»`, '', '#/course/' + c.id, { subject: `Курс «${c.title}» открыт — Vosca`, html: mailLayout('Курс открыт 🎉', `<p>Вам открыт курс <b>${esc(c.title)}</b>.</p>`, { label: 'Начать учёбу', url: env.baseUrl() + '/#/course/' + c.id }), text: `Вам открыт курс «${c.title}»` }); }
          break;
        case 'pass': adminPassUpTo(t.id, str(b.lesson, 60)); break;
        case 'reset': adminReset(t.id, str(b.lesson, 60)); break;
        case 'password': { const np = String(b.password || ''); if (np.length < 8) throw new HttpError(400, 'Пароль — не короче 8 символов'); t.hash = env.hashPassword(np); env.dropSessions(t.id); break; }
        case 'langs': adminSetLangs(t.id, b.langs); break;
        case 'role': adminSetRole(t.id, str(b.role, 20)); break;
        case 'assign': adminAssign(t.id, str(b.course, 40), b.teacher); break;
        case 'delete': if (t.role === 'admin') throw new HttpError(400, 'Администратора удалить нельзя'); wipeUser(t.id); break;
        case 'profile': { const url = b.meeting_url ? safeUrl(b.meeting_url) : ''; if (url === null) throw new HttpError(400, 'Ссылка должна начинаться с https://'); if (b.meeting_url !== undefined) t.meeting_url = url; if (b.bio !== undefined) t.bio = str(b.bio, 400); break; }
      }
      return ok({ ok: true });
    }
    if (p === '/api/admin/materials' && m === 'GET') return ok(adminMaterials());
    if (p === '/api/admin/codes' && m === 'GET') return ok({ codes: adminCodes(), courses: catalog().map(c => ({ id: c.id, title: c.title, flag: c.flag, ready: c.ready })), teachers: Object.values(db.users).filter(isTeacher).map(u => ({ id: u.id, name: u.name, langs: u.langs || [] })) });
    if (p === '/api/admin/codes' && m === 'POST') return ok({ codes: adminCreateCodes(u, b) });
    if ((x = p.match(/^\/api\/admin\/codes\/([A-Z0-9-]+)\/off$/)) && m === 'POST') { if (db.codes[x[1]]) db.codes[x[1]].active = false; return ok({ ok: true }); }
    if (p === '/api/admin/invites' && m === 'GET') return ok({ invites: adminInvites(), courses: catalog().map(c => ({ id: c.id, title: c.title, flag: c.flag, ready: c.ready })) });
    if (p === '/api/admin/invites' && m === 'POST') return ok({ codes: adminCreateInvites(u, b) });
    if ((x = p.match(/^\/api\/admin\/invites\/([A-Z0-9-]+)\/off$/)) && m === 'POST') { if (db.invites[x[1]]) db.invites[x[1]].active = false; return ok({ ok: true }); }
    if (p === '/api/admin/club' && m === 'GET') return ok(adminClub());
    if (p === '/api/admin/club/grant' && m === 'POST') { const su = adminClubUser(b); return ok({ sub: clubGrant(u, su.id, b), name: su.name }); }
    if (p === '/api/admin/club/revoke' && m === 'POST') { const su = adminClubUser(b); return ok({ sub: clubRevoke(u, su.id), name: su.name }); }
    if (p === '/api/admin/sessions' && m === 'GET') return ok(adminSessions());
    if (p === '/api/admin/outbox' && m === 'GET') return ok({ items: adminOutbox(), smtp: env.mailMode() });
    if (p === '/api/admin/settings' && m === 'GET') return ok(adminSettings());
    if (p === '/api/admin/settings' && m === 'POST') return ok(adminSettings(b));
    if (p === '/api/admin/catalog' && m === 'GET') return ok({ courses: content.courses(), lessons: Object.fromEntries(catalog().flatMap(c => c.lessons.map(l => [l.key, { title: l.title, min: l.min, tasks: l.tasks, questions: (content.bank(l.key) || []).length, langs: content.langs ? content.langs(l.key) : ['ru'] }]))) });
  }
  throw new HttpError(404, 'Не найдено');
}

/* ── создание приложения ── */
let ADMIN_EMAIL = '';
function bootstrapAdmin(email, password, name) {
  email = String(email || '').toLowerCase(); if (!email) return null;
  let u = userByEmail(email);
  if (u) { if (u.role !== 'admin') u.role = 'admin'; return u; }
  if (!password) return null;
  u = createUser({ name: name || 'Администратор', email, password, role: 'admin' });
  recordConsent(u.id, 'offer', 1, '', 'bootstrap'); recordConsent(u.id, 'consent-pd', 1, '', 'bootstrap'); return u;
}
function createApp(opts) {
  db = initDb(opts.db); content = opts.content; env = opts.env; ADMIN_EMAIL = String(opts.adminEmail || '').toLowerCase();
  if (opts.cfg) Object.assign(CFG, opts.cfg);
  return { handle, tick, icsByToken, bootstrapAdmin, photoOf: id => { const r = db.photos[id]; return r ? { mime: r.mime, v: r.v, buf: Buffer.from(r.b64, 'base64') } : null; }, mailDone: (id, status, err) => { const m = db.outbox.find(x => x.id === id); if (m) { m.status = status; m.error = err || ''; m.tries = (m.tries || 0) + (status === 'queued' ? 1 : 0); if (status === 'sent') m.sent = now(); } }, pendingMail: () => db.outbox.filter(x => x.status === 'queued'), db: () => db, CFG };
}
