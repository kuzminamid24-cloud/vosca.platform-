/* Vosca · переводы интерфейса: русский (исходный язык) и English.
   Как это устроено: экраны пишутся по-русски, а этот модуль переводит готовый DOM по словарю (i18n-dict.js).
   Фразы с подстановками описаны шаблонами: {1} — любой текст, {#1} — число, {u:день|дня|дней} — формы слова.
   Что не найдено в словаре — остаётся по-русски (и попадает в VoscaI18n.miss, это проверяют тесты). */
(() => {
  'use strict';
  const CYR = /[Ѐ-ӿ]/;
  const LANGS = [['ru', 'RU', 'Русский'], ['en', 'EN', 'English']];
  const LOCALE = { ru: 'ru-RU', en: 'en-GB' };
  const KEY = 'vosca_lang';
  const I = window.VoscaI18n = { lang: 'ru', langs: LANGS, miss: new Set() };

  const norm = s => s.replace(/[\s ]+/g, ' ').trim();
  const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  /* ── названия дней и месяцев (в уведомлениях ядро пишет дату по-русски) ── */
  const W = {
    en: ['понедельник|Monday', 'вторник|Tuesday', 'среда|Wednesday', 'четверг|Thursday', 'пятница|Friday', 'суббота|Saturday', 'воскресенье|Sunday',
      'января|January', 'февраля|February', 'марта|March', 'апреля|April', 'мая|May', 'июня|June', 'июля|July', 'августа|August', 'сентября|September', 'октября|October', 'ноября|November', 'декабря|December', 'МСК|MSK'],
  };
  const wordMaps = {};
  const wordPass = (s, lang) => {
    if (!W[lang]) return s;
    if (!wordMaps[lang]) { const m = new Map(W[lang].map(x => x.split('|'))); wordMaps[lang] = { m, re: new RegExp('(?<![\\u0400-\\u04FF])(' + [...m.keys()].join('|') + ')(?![\\u0400-\\u04FF])', 'gi') }; }
    const { m, re } = wordMaps[lang];
    return s.replace(re, w => m.get(w) || m.get(w.toLowerCase()) || w);
  };

  /* ── словарь → быстрые таблицы ── */
  let C = null;
  function compile() {
    C = { en: { exact: new Map(), pats: [] } };
    (window.VOSCA_DICT || []).forEach(e => {
      const ru = norm(e[0]);
      ['en'].forEach((lang, i) => {
        const v = e[i + 1]; if (v === undefined || v === null) return;
        if (!/\{[^}]+\}/.test(ru)) { C[lang].exact.set(ru, v); return; }
        let lit = 0;
        const src = ru.split(/(\{[^}]+\})/).map(part => {
          let m;
          if ((m = part.match(/^\{#(\d)\}$/))) return '(\\d+(?:[.,]\\d+)?)';
          if ((m = part.match(/^\{(\d)\}$/))) return '(.+?)';
          if ((m = part.match(/^\{u:([^}]+)\}$/))) return '(?:' + m[1].split('|').map(esc).join('|') + ')';
          lit += part.length; return esc(part);
        }).join('');
        C[lang].pats.push({ re: new RegExp('^' + src + '$'), v, lit, key: ru });
      });
    });
    ['en'].forEach(l => C[l].pats.sort((a, b) => b.lit - a.lit));
  }

  function core(s, lang, depth) {
    const D = C[lang]; let v = D.exact.get(s);
    if (v !== undefined) return typeof v === 'function' ? v() : v;
    for (const p of D.pats) {
      const m = p.re.exec(s); if (!m) continue;
      const caps = m.slice(1).map(c => (CYR.test(c) ? sub(c, lang, depth) : c));
      return typeof p.v === 'function' ? p.v(...caps) : p.v.replace(/\{#?(\d)\}/g, (_, i) => caps[i - 1]);
    }
    if (s.indexOf('·') >= 0 && depth < 4) {                           // «Подготовка · 40 мин · 5 заданий»: переводим по частям
      let changed = false;
      const out = s.split(/(\s*·\s*)/).map((x, i) => { if (i % 2 || !x) return x; const t = sub(x, lang, depth + 1); if (t !== x) changed = true; return t; });
      if (changed) return out.join('');
    }
    const pm = depth < 4 && /^((?:\d+\.\s|[^\p{L}\p{N}«»"“”‘’'()\[\]]+)+)(.+)$/su.exec(s);          // «🇹🇭 Тайский язык», «3. Урок»: значок или номер впереди
    if (pm) { const t = sub(pm[2], lang, depth + 1); if (t !== pm[2]) return pm[1] + t; }
    if (s.indexOf(' — ') > 0 && depth < 4) {                           // «Анна — Тайский язык»
      let changed = false;
      const out = s.split(' — ').map(x => { const t = sub(x, lang, depth + 1); if (t !== x) changed = true; return t; });
      if (changed) return out.join(' — ');
    }
    const w = wordPass(s, lang);
    return w !== s ? w : null;
  }
  const sub = (s, lang, depth) => { const t = core(norm(s), lang, (depth || 0) + 1); return t === null || t === undefined ? s : t; };

  function tr(raw, lang) {
    lang = lang || I.lang;
    if (lang === 'ru' || !raw || !CYR.test(raw)) return raw;
    if (!C) compile();
    const lead = raw.match(/^[\s ]*/)[0], trail = raw.match(/[\s ]*$/)[0], c = norm(raw);
    const t = core(c, lang, 0);
    const out = t === null ? raw : lead + t + trail;
    if (CYR.test(out)) I.miss.add(c);
    return out;
  }
  I.t = tr;
  I.locale = () => LOCALE[I.lang] || 'ru-RU';

  /* ── перевод готового DOM ── */
  const SKIP = { SCRIPT: 1, STYLE: 1, IFRAME: 1, TEXTAREA: 1 };
  const ATTRS = ['placeholder', 'title', 'aria-label', 'alt'];
  function node(n) {
    if (n.nodeType === 3) {
      const p = n.parentNode; if (p && (SKIP[p.nodeName] || (p.closest && p.closest('[data-notr]')))) return;
      const v = n.nodeValue; if (CYR.test(v)) { const t = tr(v); if (t !== v) n.nodeValue = t; } return; }
    if (n.nodeType !== 1 || n.hasAttribute('data-notr')) return;
    for (const a of ATTRS) { if (n.hasAttribute(a)) { const v = n.getAttribute(a); if (CYR.test(v)) { const t = tr(v); if (t !== v) n.setAttribute(a, t); } } }
    if (SKIP[n.tagName]) return;
    for (let c = n.firstChild; c; c = c.nextSibling) node(c);
  }
  I.apply = (root) => { if (I.lang !== 'ru') node(root || document.body); document.title = I.lang === 'ru' ? (I.ruTitle || document.title) : tr(I.ruTitle || document.title); };

  const mo = new MutationObserver(list => {
    if (I.lang === 'ru') return;
    for (const m of list) {
      if (m.type === 'childList') m.addedNodes.forEach(node);
      else if (m.type === 'characterData') node(m.target);
      else if (m.type === 'attributes') { const el = m.target; if (!el.closest || !el.closest('[data-notr]')) { const v = el.getAttribute(m.attributeName); if (v && CYR.test(v)) { const t = tr(v); if (t !== v) el.setAttribute(m.attributeName, t); } } }
    }
    mo.takeRecords();
  });

  /* ── выбор языка ── */
  const pick = () => {
    try { const q = new URLSearchParams(location.search).get('lang'); if (q && LOCALE[q]) { try { localStorage.setItem(KEY, q); } catch (e) { } return q; } } catch (e) { }
    try { const s = localStorage.getItem(KEY); if (s && LOCALE[s]) return s; } catch (e) { }
    const nav = (navigator.languages && navigator.languages[0]) || navigator.language || 'ru';
    const two = String(nav).slice(0, 2).toLowerCase();
    return two === 'ru' || two === 'uk' || two === 'be' || two === 'kk' ? 'ru' : 'en';
  };
  I.set = lang => {
    if (!LOCALE[lang]) return;
    I.lang = lang; document.documentElement.lang = lang;
    try { localStorage.setItem(KEY, lang); } catch (e) { }
    window.dispatchEvent(new CustomEvent('vosca-lang', { detail: lang }));
    if (window.V && V.render) V.render(); else I.apply();
    I.apply();
  };
  I.init = () => {
    I.ruTitle = document.title;
    I.lang = pick(); document.documentElement.lang = I.lang;
    if (I.lang !== 'ru') I.apply();
    mo.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  };

  /* родные диалоги браузера тоже переводим */
  ['confirm', 'alert', 'prompt'].forEach(k => { const f = window[k].bind(window); window[k] = (m, d) => f(tr(String(m)), d); });

  /* переключатель языка (в шапке) */
  I.switcher = () => `<div class="lsw" role="group" aria-label="Language / Язык" data-notr>${LANGS.map(l => `<button type="button" class="${l[0] === I.lang ? 'on' : ''}" data-act="lang" data-l="${l[0]}" lang="${l[0]}" title="${l[2]}" aria-pressed="${l[0] === I.lang}">${l[1]}</button>`).join('')}</div>`;
})();
