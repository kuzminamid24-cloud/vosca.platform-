/* Vosca · клиент: расписание ученика и кабинет преподавателя */
(() => {
  'use strict';
  const V = window.V, S = V.S, app = V.app, h = V.h, api = V.api, plural = V.plural;

  const STATUS = { planned: ['', ''], done: ['ok', 'проведён'], cancelled: ['bad', 'отменён'] };
  const dayGroups = list => { const g = []; list.forEach(s => { const k = V.dayKey(s.starts), last = g[g.length - 1]; if (last && last.k === k) last.items.push(s); else g.push({ k, ts: s.starts, items: [s] }); }); return g; };

  /* ── ученик ── */
  function sessRow(s) {
    return `<div class="sess ${s.declined ? 'dec' : ''}"><div class="tm"><b>${V.fTime(s.starts)}</b><small>${s.dur} мин</small></div>
      <div class="si"><b>${h(s.title)}</b><span>${h(s.courseTitle)} · преподаватель <a href="#/teachers/${s.teacher.id}">${h(s.teacher.name)}</a></span>
        <span class="cdp" data-cd="${s.starts}" data-end="${s.end}">${V.cd(s.starts - V.now())}</span>
        ${s.declined ? `<span class="bdg hw">Вы сообщили, что не сможете прийти</span>` : ''}</div>
      <div class="sa">${V.joinHtml(s)}${s.declined ? '' : `<button class="btn sm gho" data-act="decline" data-id="${s.id}">Не смогу прийти</button>`}</div></div>`;
  }
  V.route(/^\/schedule$/, async () => {
    V.loading(); await V.loadOverview(); V.header('schedule');
    const sc = await api('GET', '/api/schedule'), up = sc.upcoming.filter(s => s.status === 'planned');
    const cal = sc.calUrl, web = cal.replace(/^https?:/, 'webcal:');
    app.innerHTML = `<section class="phero"><span class="pill"><span class="dot"></span> Живые уроки</span><h1>Расписание</h1>
      <p>Все ваши занятия с преподавателем. Время показано в вашем часовом поясе — <b>${h(sc.tz.replace(/_/g, ' '))}</b> (${V.tzLabel(sc.tz)}). <a href="#/profile">Изменить</a></p></section>
      ${V.reqStudent(sc)}
      ${up[0] ? V.liveCard(up[0], { big: 1, noSchedule: 1 }) : ''}
      <div class="sect"><h2>Ближайшие занятия <small>${up.length}</small></h2>
        ${up.length ? dayGroups(up).map(g => `<div class="dayh">${h(V.fDay(g.ts))}</div>${g.items.map(sessRow).join('')}`).join('')
          : `<div class="empty"><div style="font-size:42px">📅</div><b>Пока нет назначенных занятий.</b><br>Нажмите «Запросить урок» и предложите удобное время — преподаватель подтвердит его, а вы получите письмо и уведомление.</div>`}</div>
      ${sc.teachers.length ? `<div class="sect"><h2>Ваш преподаватель</h2><div class="cols2">${sc.teachers.map(t => `<a class="card tcard" href="#/teachers/${t.id}">${V.avatar(t, 'lg')}<div><b>${h(t.name)}</b><div class="mut2" style="font-size:14px">${h(t.headline || t.courseTitle)}</div>${t.bio ? `<p style="font-size:14px;margin-top:6px">${h(t.bio.length > 160 ? t.bio.slice(0, 160) + '…' : t.bio)}</p>` : ''}<small class="mut">Профиль →</small></div></a>`).join('')}</div></div>` : ''}
      <div class="sect"><h2>Календарь в телефоне</h2><div class="card">${V.demo ? '<p class="mut2">В рабочей версии здесь будет персональная ссылка-подписка: уроки сами появятся в вашем Google/Apple/Outlook-календаре с напоминанием за 15 минут и ссылкой на встречу.</p>'
        : `<p class="mut2" style="font-size:14px">Подпишитесь один раз — все уроки (и новые, и перенесённые) будут появляться в вашем календаре сами, с напоминанием за 15 минут и ссылкой на встречу.</p>
        <div class="row mt16"><a class="btn pri sm" href="https://calendar.google.com/calendar/r?cid=${encodeURIComponent(web)}" target="_blank" rel="noopener">Google Календарь</a><a class="btn sm" href="${h(web)}">Apple / Outlook</a><button class="btn sm gho" data-act="copyurl" data-url="${h(cal)}">Скопировать ссылку</button></div>
        <p class="mut" style="font-size:12.5px;margin-top:10px">Ссылка личная — не показывайте её другим.</p>`}</div></div>
      ${sc.past.length ? `<div class="sect"><h2>Прошедшие</h2>${sc.past.map(s => `<div class="sess past"><div class="tm"><b>${h(V.fDayShort(s.starts))}</b><small>${V.fTime(s.starts)}</small></div><div class="si"><b>${h(s.title)}</b><span>${h(s.teacher.name)} · <span class="bdg ${STATUS[s.status][0]}">${STATUS[s.status][1] || 'в плане'}</span>${s.reason ? ' · ' + h(s.reason) : ''}</span>${s.note ? `<div class="tnote">💬 ${h(s.note)}</div>` : ''}</div></div>`).join('')}</div>` : ''}`;
    V.refreshLive();
  });
  V.act('copyurl', el => V.copy(el.dataset.url));
  V.act('decline', el => V.modal(`<div class="mbig">🙋</div><h2>Не сможете прийти?</h2><p>Преподаватель получит уведомление и предложит другое время.</p>
    <form data-form="decline" data-id="${el.dataset.id}" data-err="derr"><label class="fld" style="text-align:left"><span>Причина (необязательно)</span><input name="reason" maxlength="200" placeholder="Например: заболел(а)"></label>
    <div class="ferr hide" id="derr"></div><div class="acts"><button class="btn pri" type="submit">Сообщить преподавателю</button><button type="button" class="btn gho" data-act="closemodal">Отмена</button></div></form>`));
  V.form('decline', async (fd, f) => { await api('POST', `/api/schedule/${f.dataset.id}/decline`, { reason: fd.reason }); V.closeModal(); toast('Преподаватель получил уведомление'); V.render(); });

  /* ── преподаватель ── */
  let T = null;
  function trow(s) {
    const sTz = s.student && s.student.tz;
    return `<div class="sess ${s.declined ? 'dec' : ''}"><div class="tm"><b>${V.fTime(s.starts)}</b><small>${s.dur} мин</small></div>
      <div class="si"><b>${h(s.student ? s.student.name : '')} <span class="mut">· ${h(s.courseTitle)}</span></b><span>${h(s.title)}${sTz && sTz !== V.tz() ? ` · у ученика ${V.fTime(s.starts, sTz)} (${h(sTz.split('/').pop().replace(/_/g, ' '))})` : ''}</span>
        <span class="cdp" data-cd="${s.starts}" data-end="${s.end}">${V.cd(s.starts - V.now())}</span>${s.series ? ' <span class="bdg">серия</span>' : ''}
        ${s.declined ? `<div class="tnote warn">🙋 Ученик просит перенести: ${h(s.declineReason)}</div>` : ''}</div>
      <div class="sa">${V.joinHtml(s)}<button class="btn sm" data-act="tmove" data-id="${s.id}">Перенести</button><button class="btn sm gho" data-act="tdone" data-id="${s.id}">Проведён</button><button class="btn sm gho" data-act="tcancel" data-id="${s.id}">Отменить</button></div></div>`;
  }
  V.route(/^\/teach$/, async () => {
    if (S.user && S.user.role === 'student') { V.header('cabinet'); return V.notFound('Нет доступа'); }
    V.loading(); await V.loadOverview(); V.header('teach');
    const d = T = await api('GET', '/api/teach');
    const byId = {}; d.upcoming.concat(d.recent).forEach(s => { byId[s.id] = s; }); d.byId = byId;
    app.innerHTML = `<section class="phero"><span class="pill">Преподаватель</span><h1>Мои ученики и занятия</h1>
      <p>Время показано в вашем часовом поясе — <b>${h(d.tz.replace(/_/g, ' '))}</b> (${V.tzLabel(d.tz)}). Ученики видят занятия в своём времени, письма приходят обеим сторонам.</p></section>
      ${!d.teacher.meeting_url ? `<div class="notice mt16">🔗 Добавьте свою постоянную ссылку на видеовстречу — она автоматически подставится во все занятия. <a class="btn sm pri" href="#/profile">Добавить в профиле</a></div>` : `<div class="notice ok mt16">🔗 Ссылка на встречу: <a href="${h(d.teacher.meeting_url)}" target="_blank" rel="noopener noreferrer">${h(d.teacher.meeting_url)}</a> — подставляется в новые занятия.</div>`}
      <div class="row mt24"><button class="btn pri" data-act="newsess" ${d.students.length ? '' : 'disabled'}>＋ Назначить занятие</button><a class="btn" href="#/teach/students">👩‍🎓 Мои ученики</a><a class="btn" href="#/teach/materials">📚 Материалы</a>${V.demo ? '' : `<button class="btn gho" data-act="copyurl" data-url="${h(d.calUrl)}">Скопировать ссылку на мой календарь</button>`}</div>
      ${V.reqTeach(d)}
      <div class="sect"><h2>Ближайшие занятия <small>${d.upcoming.length}</small></h2>${d.upcoming.length ? dayGroups(d.upcoming).map(g => `<div class="dayh">${h(V.fDay(g.ts))}</div>${g.items.map(trow).join('')}`).join('') : '<div class="empty">Нет запланированных занятий. Нажмите «Назначить занятие».</div>'}</div>
      <div class="sect"><h2>Мои ученики <small>${d.students.length}</small> <a class="btn sm" href="#/teach/students" style="margin-left:auto">Все ученики и свободные →</a></h2>${d.students.length ? `<div class="atw"><table class="at"><thead><tr><th>Ученик</th><th>Курс</th><th>Прогресс</th><th>Был(а)</th><th></th></tr></thead><tbody>${d.students.map(s => `<tr><td class="unm"><b>${h(s.name)}</b><span>${h(s.email)} · ${h(s.tz.split('/').pop().replace(/_/g, ' '))}</span></td><td>${h(s.courseTitle)}${s.active ? '' : ' <span class="bdg bad">доступ закончился</span>'}</td><td>${s.passed}/${s.total}</td><td>${s.lastDay || '—'}</td><td><button class="btn sm" data-act="newsess" data-student="${s.id}" data-course="${s.course}" ${s.active ? '' : 'disabled'}>Назначить</button></td></tr>`).join('')}</tbody></table></div>`
        : '<div class="empty">Пока никто не закреплён за вами. Откройте <a href="#/teach/students">«Мои ученики»</a> — там список свободных учеников вашего языка, которых можно взять себе. Ещё ученик может запросить у вас урок со страницы «Преподаватели», а администратор может закрепить учеников.</div>'}</div>
      ${d.recent.length ? `<div class="sect"><h2>Недавние</h2>${d.recent.map(s => `<div class="sess past"><div class="tm"><b>${h(V.fDayShort(s.starts))}</b><small>${V.fTime(s.starts)}</small></div><div class="si"><b>${h(s.student ? s.student.name : '')}</b><span>${h(s.title)} · <span class="bdg ${STATUS[s.status][0]}">${STATUS[s.status][1] || 'ожидает итога'}</span>${s.reason ? ' · ' + h(s.reason) : ''}</span>${s.note ? `<div class="tnote">💬 ${h(s.note)}</div>` : ''}</div>
        <div class="sa">${s.status === 'planned' ? `<button class="btn sm" data-act="tdone" data-id="${s.id}">Проведён</button>` : ''}${s.status !== 'cancelled' ? `<button class="btn sm gho" data-act="tnote" data-id="${s.id}">${s.note ? 'Изменить заметку' : 'Заметка ученику'}</button>` : ''}</div></div>`).join('')}</div>` : ''}`;
    V.refreshLive();
  });

  /* создание занятий: общий модал (используется и в админке) */
  V.sessionModal = (o) => {
    const tomorrow = V.inputDate(V.now() + 864e5, o.tz);
    const pick = o.pick || '';
    V.modal(`<div class="mbig">🎥</div><h2>Назначить занятие</h2>
      <form data-form="mksess" data-err="merr" data-tz="${h(o.tz)}" style="text-align:left">
        ${o.teachers ? `<label class="fld"><span>Преподаватель</span><select name="teacher" class="sel">${o.teachers.map(t => `<option value="${t.id}" ${t.id === o.teacher ? 'selected' : ''}>${h(t.name)}</option>`).join('')}</select></label>` : ''}
        <label class="fld"><span>Ученик и курс</span><select name="stu" class="sel">${o.students.map(s => `<option value="${s.id}|${s.course}" ${pick === s.id + '|' + s.course ? 'selected' : ''}>${h(s.name)} — ${h(s.courseTitle)}</option>`).join('')}</select></label>
        <div class="dbl"><label class="fld"><span>Дата (${h(o.tz.split('/').pop().replace(/_/g, ' '))})</span><input type="date" name="date" value="${tomorrow}" required></label>
        <label class="fld"><span>Время</span><input type="time" name="time" value="18:00" required></label></div>
        <div class="dbl"><label class="fld"><span>Длительность, мин</span><input type="number" name="dur" value="50" min="15" max="240" required></label>
        <label class="fld"><span>Повторять каждую неделю</span><select name="repeat" class="sel"><option value="1">Только один раз</option>${[2, 3, 4, 6, 8, 12, 26].map(n => `<option value="${n}">${n} ${plural(n, ['неделя', 'недели', 'недель'])} подряд</option>`).join('')}</select></label></div>
        <label class="fld"><span>Тема (необязательно)</span><input name="title" maxlength="100" placeholder="Например: Разговорная практика"></label>
        <label class="fld"><span>Ссылка на встречу (по умолчанию — из профиля преподавателя)</span><input name="url" maxlength="300" placeholder="https://…"></label>
        <div class="ferr hide" id="merr"></div><div class="acts"><button class="btn pri" type="submit">Назначить и отправить письмо</button><button type="button" class="btn gho" data-act="closemodal">Отмена</button></div></form>`, { cls: 'wide' });
  };
  V.act('newsess', el => {
    if (!T) return;
    V.sessionModal({ students: T.students.filter(s => s.active), tz: T.tz, pick: el.dataset.student ? el.dataset.student + '|' + el.dataset.course : '' });
  });
  V.form('mksess', async (fd, f) => {
    V.hideEl('merr');
    const [stu, course] = fd.stu.split('|'), start = V.zoned(fd.date, fd.time, f.dataset.tz);
    if (!Number.isFinite(start)) throw new Error('Укажите дату и время');
    const body = { student: +stu, course, start, dur: +fd.dur, repeat: +fd.repeat, title: fd.title, url: fd.url.trim() }; if (fd.teacher) body.teacher = +fd.teacher;
    const r = await api('POST', '/api/teach/sessions', body);
    V.closeModal(); toast(r.created.length > 1 ? `Назначено занятий: ${r.created.length}. Ученик получил письмо.` : 'Занятие назначено. Ученик получил письмо.'); V.render();
  });

  const modalForm = (kind, id, title, inner, btn) => V.modal(`<h2>${title}</h2><form data-form="${kind}" data-id="${id}" data-err="merr" style="text-align:left">${inner}<div class="ferr hide" id="merr"></div><div class="acts"><button class="btn pri" type="submit">${btn}</button><button type="button" class="btn gho" data-act="closemodal">Закрыть</button></div></form>`);
  V.act('tmove', el => {
    const s = T.byId[el.dataset.id];
    modalForm('tmove', s.id, 'Перенести занятие', `<p class="mut2" style="text-align:center">${h(s.student.name)}, сейчас: ${h(V.fDT(s.starts))}</p><div class="dbl"><label class="fld"><span>Новая дата</span><input type="date" name="date" value="${V.inputDate(s.starts)}" required></label><label class="fld"><span>Время</span><input type="time" name="time" value="${V.fTime(s.starts)}" required></label></div>`, 'Перенести и уведомить ученика');
  });
  V.form('tmove', async (fd, f) => { const start = V.zoned(fd.date, fd.time, V.tz()); if (!Number.isFinite(start)) throw new Error('Укажите дату и время'); await api('POST', `/api/teach/sessions/${f.dataset.id}/move`, { start }); V.closeModal(); toast('Перенесено, ученик получил письмо'); V.render(); });
  V.act('tcancel', el => {
    const s = T.byId[el.dataset.id];
    modalForm('tcancel', s.id, 'Отменить занятие?', `<label class="fld"><span>Причина (увидит ученик)</span><input name="reason" maxlength="200"></label>${s.series ? '<label class="ck mt16"><input type="checkbox" name="series"><span>Отменить и все следующие занятия этой серии</span></label>' : ''}`, 'Отменить занятие');
  });
  V.form('tcancel', async (fd, f) => { const r = await api('POST', `/api/teach/sessions/${f.dataset.id}/cancel`, { reason: fd.reason, series: !!fd.series }); V.closeModal(); toast(r.cancelled > 1 ? `Отменено занятий: ${r.cancelled}` : 'Занятие отменено'); V.render(); });
  V.act('tdone', el => modalForm('tdone', el.dataset.id, 'Занятие проведено', '<label class="fld"><span>Заметка ученику (необязательно)</span><textarea name="note" class="ta" rows="4" maxlength="1000" placeholder="Что получилось хорошо, что повторить к следующему разу"></textarea></label>', 'Сохранить'));
  V.form('tdone', async (fd, f) => { await api('POST', `/api/teach/sessions/${f.dataset.id}/done`, { note: fd.note }); V.closeModal(); toast('Готово'); V.render(); });
  V.act('tnote', el => { const s = T.byId[el.dataset.id]; modalForm('tnote', s.id, 'Заметка ученику', `<label class="fld"><span>Ученик получит уведомление</span><textarea name="note" class="ta" rows="4" maxlength="1000">${h(s.note || '')}</textarea></label>`, 'Сохранить'); });
  V.form('tnote', async (fd, f) => { await api('POST', `/api/teach/sessions/${f.dataset.id}/note`, { note: fd.note }); V.closeModal(); toast('Заметка сохранена'); V.render(); });
})();
