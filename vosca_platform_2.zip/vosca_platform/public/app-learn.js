/* Vosca · клиент: кабинет, курсы, уроки, домашние задания, профиль */
(() => {
  'use strict';
  const V = window.V, S = V.S, app = V.app, h = V.h, api = V.api, plural = V.plural;
  const hdr = V.header;

  /* ── блоки, которые используются на нескольких страницах ── */
  V.joinHtml = (s, before) => {
    before = before || 600e3;
    if (s.status !== 'planned') return '';
    if (!s.url) return '<span class="bdg lock">Ссылка появится позже</span>';
    const t = V.now(), on = t >= s.starts - before && t <= s.end + 1800e3, a = `data-join="${s.starts}" data-end="${s.end}" data-before="${before}"`;
    return `<a class="btn pri jn ${on ? '' : 'hide'}" ${a} href="${h(s.url)}" target="_blank" rel="noopener noreferrer">🎥 Подключиться</a><button class="btn jn-off ${on ? 'hide' : ''}" ${a} disabled>🎥 Подключиться — за ${Math.round(before / 60000)} мин до начала</button>`;
  };
  V.liveCard = (s, opt) => {
    opt = opt || {};
    return `<div class="live ${opt.big ? 'big' : ''}"><div class="lvt"><small>${opt.label || 'Ближайший живой урок'}</small>
      <h3>${h(V.fDay(s.starts))}, ${V.fTime(s.starts)}</h3>
      <div class="lm"><span class="cdp" data-cd="${s.starts}" data-end="${s.end}">${V.cd(s.starts - V.now())}</span> · ${s.dur} мин · ${h(s.title)}${s.teacher ? ' · преподаватель <b>' + h(s.teacher.name) + '</b>' : ''}</div>
      ${s.declined ? '<div class="lm"><span class="bdg hw">Вы сообщили, что не сможете прийти</span></div>' : ''}</div>
      <div class="lacts">${V.joinHtml(s)}${opt.noSchedule ? '' : '<a class="btn" href="#/schedule">Расписание</a>'}</div></div>`;
  };
  const expiryNote = c => {
    if (!c.enrolled || !c.expires) return '';
    const left = Math.ceil((c.expires - V.now()) / 864e5);
    return left <= 7 ? `<span class="bdg hw">Доступ ещё ${left} ${plural(left, ['день', 'дня', 'дней'])}</span>` : `<span class="bdg">Доступ до ${V.fdate(c.expires)}</span>`;
  };
  const buyBtn = (c, label) => c.buyUrl ? `<a class="btn pri sm" href="${h(c.buyUrl)}" target="_blank" rel="noopener noreferrer">${label || 'Получить доступ'}</a>` : `<a class="btn pri sm" href="mailto:${h((S.cfg.contacts || {}).email || '')}">${label || 'Получить доступ'}</a>`;

  function courseCard(c) {
    if (!c.ready) return `<div class="crs soon"><div class="cfl">${c.flag}</div><h3>${h(c.title)}</h3><div class="nat" data-notr>${h(c.native)}</div><p>Готовим уроки — скоро откроем набор.</p><div><span class="bdg lock">Скоро</span></div></div>`;
    if (!c.enrolled) return `<div class="crs lockd"><div class="cfl">${c.flag}</div><h3>${h(c.title)}</h3><div class="nat" data-notr>${h(c.native)}</div><p>${h(c.about)}</p>
      <div class="row">${c.expired ? `<span class="bdg bad">Доступ закончился ${V.fdate(c.expires)}</span>` : '<span class="bdg lock">🔒 Не подключён</span>'}</div>
      <div class="row">${buyBtn(c, c.expired ? 'Продлить' : 'Получить доступ')}<button class="btn sm gho" data-act="focuscode">У меня есть код</button></div></div>`;
    return `<a class="crs" href="#/course/${c.id}"><div class="cfl">${c.flag}</div><h3>${h(c.title)}</h3><div class="nat" data-notr>${h(c.native)}</div><p>${h(c.about)}</p>
      <div><div class="pr"><span>Пройдено ${c.passed} из ${c.total}</span><span>${c.percent}%</span></div><div class="bar"><i style="width:${c.percent}%"></i></div></div>${c.expires ? `<div>${expiryNote(c)}</div>` : ''}</a>`;
  }
  const hwItem = x => `<div class="hwi"><div class="e">📝</div><div class="t"><b>ДЗ к уроку «${h(x.title)}»</b><span>${x.size} ${plural(x.size, ['вопрос', 'вопроса', 'вопросов'])}${x.attempts ? ' · попыток: ' + x.attempts : ''}</span></div><a class="btn pri sm" href="#/hw/${x.lesson}">Выполнить</a></div>`;
  const greet = () => { const hr = +V.fTime(V.now()).slice(0, 2); return hr < 5 ? 'Доброй ночи' : hr < 12 ? 'Доброе утро' : hr < 18 ? 'Добрый день' : 'Добрый вечер'; };

  /* ── кабинет ── */
  V.route(/^\/cabinet$/, async () => {
    V.loading(); await V.loadOverview(); hdr('cabinet');
    const o = S.ov, st = o.stats, first = h(S.user.name.split(' ')[0]), sk = o.streak;
    const skText = sk.days ? (sk.today ? `${sk.days} ${plural(sk.days, ['день', 'дня', 'дней'])} подряд — так держать!` : `${sk.days} ${plural(sk.days, ['день', 'дня', 'дней'])} подряд — позанимайтесь сегодня, чтобы не прервать серию`) : 'Позанимайтесь сегодня — и начнётся ваша серия';
    const enrolledAny = o.courses.some(c => c.enrolled);
    app.innerHTML = `<section class="phero"><span class="pill"><span class="dot"></span> Личный кабинет</span>
      <h1>${greet()}, ${first}! 👋</h1><p>${o.continue ? 'Ваш следующий шаг уже готов — продолжайте с того же места.' : enrolledAny ? 'Вы прошли всё, что сейчас доступно. Новые уроки скоро появятся.' : 'Подключите курс — и учёба начнётся.'}</p>
      <div class="pstats"><div class="meta fire ${sk.days ? 'on' : ''}"><b>🔥 ${sk.days}</b><span>дней подряд</span></div>
        <div class="meta"><b>${st.lessonsPassed}</b><span>уроков пройдено</span></div><div class="meta"><b>${st.hwDone}</b><span>ДЗ выполнено</span></div><div class="meta"><b>${st.xp}</b><span>очков опыта</span></div><div class="meta"><b>${st.minutes}</b><span>минут учёбы</span></div></div>
      <div class="skline">${skText}</div></section>
      ${o.nextLive ? V.liveCard(o.nextLive, { big: 1 }) : (enrolledAny ? `<div class="live empty-live"><div class="lvt"><small>Живые уроки</small><h3>Пока нет запланированных уроков</h3><div class="lm">Преподаватель назначит время — оно появится здесь, и мы напомним по почте.</div></div><div class="lacts"><a class="btn" href="#/schedule">Расписание</a></div></div>` : '')}
      ${V.clubCard(o.club, o.clubNext)}
      ${o.continue ? `<div class="next"><div class="nt"><small>Продолжить обучение</small><h3>Урок ${o.continue.index}. ${h(o.continue.title)}</h3></div><a class="btn pri" href="#/lesson/${o.continue.lesson}">Открыть урок →</a></div>`
        : enrolledAny ? '<div class="next"><div class="nt"><small>Всё пройдено</small><h3>Вы прошли все доступные уроки 🎉</h3></div></div>' : ''}
      ${o.checklist ? `<div class="sect"><h2>Первые шаги <small>${o.checklist.filter(x => x.done).length} из ${o.checklist.length}</small></h2><div class="chk">${o.checklist.map(x => `<${x.link && !x.done ? 'a href="' + h(x.link) + '"' : 'div'} class="ci ${x.done ? 'done' : ''}"><span class="cbx">${x.done ? '✓' : ''}</span><span>${h(x.title)}</span></${x.link && !x.done ? 'a' : 'div'}>`).join('')}</div></div>` : ''}
      ${o.pendingHw.length ? `<div class="sect"><h2>📝 Домашние задания <small>ждут вас</small></h2><div class="hwlist">${o.pendingHw.map(hwItem).join('')}</div></div>` : ''}
      <div class="sect"><h2>Мои курсы</h2>${o.courses.length ? `<div class="courses">${o.courses.map(courseCard).join('')}</div>` : '<div class="empty"><div style="font-size:38px">🔑</div><b>Языкового курса пока нет.</b><br>Введите код доступа ниже — и откроется нужный язык. Подписка на Разговорный клуб уже работает: загляните в раздел «Клуб».</div>'}</div>
      <div class="sect"><h2>Есть код доступа?</h2><form class="card codebox" data-form="redeem" data-err="cerr"><p class="mut2" style="font-size:14px;margin-bottom:10px">Код приходит после оплаты курса. Введите его — курс откроется сразу.</p>
        <div class="row"><input name="code" id="codeIn" class="srch" style="flex:1;min-width:220px;text-transform:uppercase" placeholder="VOSCA-XXXX-XXXX" autocomplete="off" required><button class="btn pri" type="submit">Активировать</button></div>
        <div class="ferr hide" id="cerr"></div></form></div>
      <div class="sect"><h2>Достижения <small>${o.achievements.filter(a => a.at).length} из ${o.achievements.length}</small></h2><div class="achs">${o.achievements.map(a => `<div class="ach ${a.at ? 'on' : ''}" title="${h(a.desc)}"><span class="ae">${a.at ? a.emoji : '🔒'}</span><b>${h(a.title)}</b><small>${h(a.desc)}</small></div>`).join('')}</div></div>`;
    V.refreshLive();
  });
  V.act('focuscode', () => { const i = document.getElementById('codeIn'); if (i) { i.scrollIntoView({ behavior: 'smooth', block: 'center' }); setTimeout(() => i.focus(), 350); } else V.go('#/cabinet'); });
  V.form('redeem', async fd => {
    V.hideEl('cerr'); const r = await api('POST', '/api/redeem', { code: fd.code });
    S.ov = null; burst(160);
    if (r.club) { toast('Подписка на Разговорный клуб открыта! 🎤'); return V.go('#/club'); }
    toast(`Курс «${r.title}» открыт! 🎉`); V.go('#/course/' + r.course);
  });

  V.route(/^\/courses$/, async () => {
    V.loading(); await V.loadOverview(); hdr('courses');
    app.innerHTML = `<section class="phero"><h1>Курсы</h1><p>Каждый язык — отдельный курс. Вам доступны только те, что вы подключили.</p></section>
      <div class="sect"><div class="courses">${S.ov.courses.map(courseCard).join('')}</div></div>`;
  });

  /* ── курс ── */
  function lessonRow(c, l) {
    const prev = c.lessons[l.index - 1];
    const num = `<div class="lnum">${l.status === 'passed' ? '✓' : l.status === 'locked' ? '🔒' : l.index + 1}</div>`;
    const hw = l.hw ? (l.hw.status === 'done' ? `<span class="bdg ok">ДЗ ✓ ${l.hw.best}%</span>` : `<a class="bdg hw" href="#/hw/${l.key}" style="text-decoration:none">📝 ДЗ ждёт</a>`) : '';
    let mid, acts;
    if (l.status === 'locked') { mid = `<span class="lhint">Откроется после урока ${prev ? prev.index + 1 : ''} — нужно набрать ${S.cfg.passScore}%</span>`; acts = '<span class="bdg lock">Закрыт</span>'; }
    else if (l.status === 'open') { mid = `<span class="lhint">${l.min} мин · ${l.tasks} ${plural(l.tasks, ['задание', 'задания', 'заданий'])}${l.accuracy && l.done ? ' · последняя попытка: ' + l.accuracy + '%' : ''}</span>`; acts = `<a class="btn pri sm" href="#/lesson/${l.key}">Начать урок</a>`; }
    else { mid = `<span class="lhint">Пройден · лучший результат ${l.best || l.accuracy}%${l.manual ? ' (отмечен школой)' : ''}</span>`; acts = `${hw}<a class="btn sm" href="#/lesson/${l.key}">Повторить</a>`; }
    if (l.status === 'open' && hw) acts = hw + acts;
    return `<div class="lrow ${l.status}">${num}<div class="ltx"><b>${h(l.title)}</b>${l.th ? `<span class="th">${h(l.th)}</span>` : ''}${mid}</div><div class="acts">${acts}</div></div>`;
  }
  V.route(/^\/course\/([a-z0-9-]+)$/, async m => {
    V.loading(); await V.loadOverview(); hdr('courses');
    const c = S.ov.courses.find(x => x.id === m[1]);
    if (!c || !c.ready) return V.notFound('Курс не найден');
    if (!c.enrolled) {
      app.innerHTML = `<a class="back" href="#/courses">← Все курсы</a><div class="empty mt16"><div style="font-size:46px">🔒</div><b>${c.expired ? `Доступ к курсу «${h(c.title)}» закончился ${V.fdate(c.expires)}.` : `Курс «${h(c.title)}» пока не подключён к вашему аккаунту.`}</b><br>Прогресс сохранён — после продления вы продолжите с того же места.
        <div class="row mt16" style="justify-content:center">${buyBtn(c, c.expired ? 'Продлить доступ' : 'Получить доступ')}<button class="btn gho" data-act="focuscode">У меня есть код</button></div></div>`;
      return;
    }
    app.innerHTML = `<a class="back" href="#/cabinet">← Кабинет</a>
      <div class="chead"><div class="cfl">${c.flag}</div><div style="flex:1;min-width:240px"><h1>${h(c.title)}</h1><div class="mut2">Пройдено ${c.passed} из ${c.total} · ${c.percent}% ${expiryNote(c)}</div><div class="bar"><i style="width:${c.percent}%"></i></div></div></div>
      <div class="notice mt16" style="background:#EFF6FF;border-color:#BFDBFE;color:#1E3A8A">🔓 Каждый следующий урок открывается, когда вы проходите предыдущий на ${S.cfg.passScore}% и больше. Домашнее задание появляется после урока.</div>
      ${c.modules.map(mo => { const ls = c.lessons.filter(l => l.module === mo.id), done = ls.filter(l => l.status === 'passed').length; return `<div class="mod"><h2>${h(mo.title)} <span class="bdg">${done}/${ls.length}</span></h2>${ls.map(l => lessonRow(c, l)).join('')}</div>`; }).join('')}`;
  });

  /* ── список ДЗ ── */
  V.route(/^\/homework$/, async () => {
    V.loading(); await V.loadOverview(); hdr('homework');
    const items = []; S.ov.courses.forEach(c => (c.lessons || []).forEach(l => { if (l.hw) items.push(l); }));
    const pend = items.filter(l => l.hw.status === 'new'), done = items.filter(l => l.hw.status === 'done');
    app.innerHTML = `<section class="phero"><h1>Домашние задания</h1><p>Появляются автоматически после каждого пройденного урока. Зачёт — от ${S.cfg.hwPass}% верных ответов.</p></section>
      <div class="sect"><h2>Ждут выполнения <small>${pend.length}</small></h2>${pend.length ? `<div class="hwlist">${pend.map(l => hwItem({ lesson: l.key, title: l.title, size: l.hw.size, attempts: l.hw.attempts })).join('')}</div>` : '<div class="empty">Нет заданий. Пройдите урок — и здесь появится новое ДЗ.</div>'}</div>
      ${done.length ? `<div class="sect"><h2>Выполнено <small>${done.length}</small></h2><div class="hwlist">${done.map(l => `<div class="hwi" style="border-color:#86EFAC;box-shadow:0 4px 0 #86EFAC"><div class="e">✅</div><div class="t"><b>${h(l.title)}</b><span>Результат ${l.hw.best}% · попыток: ${l.hw.attempts}</span></div></div>`).join('')}</div></div>` : ''}`;
  });

  /* ── плеер урока ── */
  const gauges = pl => {
    const l = pl.last || {}, need = pl.need, done = Math.min(l.done || (pl.info.lesson.done || 0), need);
    const acc = l.tries ? Math.round(l.hits / l.tries * 100) : (pl.passed ? (pl.info.lesson.best || 100) : 0);
    return `<div class="pst"><small>Задания <b>${done}/${need}</b></small><div class="gauge"><i style="width:${Math.round(done / need * 100)}%"></i></div></div>
      <div class="pst"><small>Точность <b>${l.tries || pl.passed ? acc + '%' : '—'}</b> · нужно ${S.cfg.passScore}%</small><div class="gauge"><i class="${acc >= S.cfg.passScore ? 'good' : ''}" style="width:${acc}%"></i><u style="left:${S.cfg.passScore}%"></u></div></div>`;
  };
  function paintStrip() {
    const pl = S.player; if (!pl) return;
    const el = document.getElementById('pstat'); if (el) el.innerHTML = gauges(pl);
    const b = document.getElementById('pbadge'); if (b) b.innerHTML = pl.passed ? '<span class="bdg ok">Пройден ✓</span>' : '';
  }
  const showNote = (html, cls) => { const n = document.getElementById('pnote'); if (n) n.innerHTML = html ? `<div class="notice ${cls || ''}">${html}</div>` : ''; };
  V.mountLesson = (fr, key) => { fr.src = '/lessons/' + key + (VoscaI18n.lang === 'en' ? '?lang=en' : ''); };

  V.route(/^\/lesson\/([a-z0-9-]+)$/, async m => {
    const key = m[1]; V.loading(); let info;
    try { info = await api('GET', '/api/lesson/' + key); }
    catch (e) {
      if (e.data && e.data.needConsent) { hdr('courses'); V.loading(); return; }
      V.header(); await V.loadOverview().catch(() => { }); hdr('courses');
      if (e.status === 403) {
        const noCourse = e.data && e.data.noCourse, need = e.data && e.data.need, c = noCourse && S.ov && S.ov.courses.find(x => x.id === noCourse);
        app.innerHTML = `<a class="back" href="#/courses">← Курсы</a><div class="empty mt16"><div style="font-size:46px">🔒</div>${noCourse ? `<b>Этот курс не подключён к вашему аккаунту.</b><br>Откройте доступ — и уроки станут доступны.<div class="row mt16" style="justify-content:center">${c ? buyBtn(c) : ''}<button class="btn gho" data-act="focuscode">У меня есть код</button></div>`
          : `<b>Этот урок пока закрыт.</b><br>${need ? `Пройдите урок «${h(need)}» на ${S.cfg.passScore}% и больше — и он откроется сам.` : ''}<div class="mt16"><a class="btn pri" href="#/cabinet">В кабинет</a></div>`}</div>`;
        return;
      }
      return V.notFound(e.message);
    }
    if (!S.ov) await V.loadOverview().catch(() => { });
    hdr('courses');
    S.player = { key, info, need: info.lesson.tasks, passed: info.lesson.status === 'passed', last: null, sentAt: 0, lastDone: -1, lastTries: -1, inflight: null, shown: {} };
    const L = info.lesson;
    app.innerHTML = `<div class="pstrip"><a class="back" href="#/course/${info.course.id}">← ${h(info.course.title)}</a><div class="pti"><small>Урок ${L.index + 1}</small><b>${h(L.title)}</b></div><div id="pbadge"></div><div class="row" id="pstat" style="gap:18px"></div></div>
      <div id="pnote"></div><iframe id="lessonFrame" class="frame" title="${h(L.title)}" allow="autoplay; speech-synthesis"></iframe>`;
    V.mountLesson(document.getElementById('lessonFrame'), key);
    paintStrip();
  });
  async function sendProgress() {
    const pl = S.player; if (!pl || !pl.last) return null;
    const d = pl.last; pl.sentAt = Date.now(); pl.lastDone = d.done; pl.lastTries = d.tries;
    const p = api('POST', '/api/progress/' + pl.key, { done: d.done, total: d.total, tries: d.tries, hits: d.hits, xp: d.xp, seconds: d.seconds })
      .then(r => { if (S.player === pl) onProgress(r); return r; })
      .catch(e => { if (e.status !== 401) toast('Не удалось сохранить прогресс: ' + e.message); })
      .finally(() => { if (pl.inflight === p) pl.inflight = null; });
    pl.inflight = p; return p;
  }
  function onProgress(r) {
    const pl = S.player;
    if (r.passedNow) { pl.passed = true; paintStrip(); showNote(''); S.ov = null; burst(180); passModal(r); }
    else if (r.lowScore && !pl.shown.low) { pl.shown.low = true; showNote(`<span class="sp1">Урок завершён, но точность <b>${r.accuracy}%</b> — нужно ${r.need}%. Пройдите урок ещё раз — следующий откроется сразу после этого.</span><button class="btn sm pri" data-act="restart">Пройти заново</button>`); }
    else if (r.tooFast && !pl.shown.fast) { pl.shown.fast = true; showNote('Урок пройден слишком быстро, чтобы засчитать его. Не торопитесь — послушайте примеры и выполните задания внимательно.'); }
  }
  function passModal(r) {
    const pl = S.player, nxt = r.next;
    V.modal(`<div class="mbig">🎉</div><h2>Урок пройден!</h2><p>Точность ${r.accuracy}% — проходной балл ${r.need}% набран.</p>
      <div class="unl">${nxt ? `<div><span class="e">🔓</span><span>Открыт следующий урок: <b>${h(nxt.title)}</b></span></div>` : '<div><span class="e">🏁</span><span>Это последний урок курса — поздравляем!</span></div>'}${r.hwCreated ? '<div><span class="e">📝</span><span>Появилось домашнее задание к этому уроку</span></div>' : ''}</div>
      <div class="acts">${r.hwCreated ? `<a class="btn pri" href="#/hw/${pl.key}" data-act="closemodal">Сделать ДЗ сейчас</a>` : ''}${nxt ? `<a class="btn ${r.hwCreated ? '' : 'pri'}" href="#/lesson/${nxt.key}" data-act="closemodal">Следующий урок →</a>` : ''}<button class="btn gho" data-act="closemodal">Остаться в уроке</button></div>`);
  }
  V.act('restart', () => { const fr = document.getElementById('lessonFrame'), pl = S.player; if (fr && pl) { pl.last = null; pl.shown = {}; pl.lastDone = -1; pl.lastTries = -1; showNote(''); V.mountLesson(fr, pl.key); paintStrip(); } });
  window.addEventListener('message', async ev => {
    const pl = S.player, fr = document.getElementById('lessonFrame');
    if (!pl || !fr || ev.source !== fr.contentWindow) return;
    const d = ev.data; if (!d || d.source !== 'vosca-lesson') return;
    if (d.type === 'progress') {
      pl.last = d; paintStrip();
      if (pl.passed && !pl.inflight) return;
      const finished = d.done >= pl.need;
      if (!pl.inflight && (finished || d.done !== pl.lastDone || Date.now() - pl.sentAt > 20000)) { if (finished && d.tries === pl.lastTries && pl.lastDone === d.done) return; sendProgress(); }
    } else if (d.type === 'next') {
      if (pl.inflight) await pl.inflight; else if (pl.last && !pl.passed && pl.last.done >= pl.need) await sendProgress();
      if (S.player !== pl) return;
      if (pl.passed) { const nx = pl.info.next; V.go(nx ? '#/lesson/' + nx.key : '#/course/' + pl.info.course.id); }
      else toast(`Чтобы открыть следующий урок, пройдите этот на ${S.cfg.passScore}% и больше`);
    }
  });

  /* ── выполнение ДЗ ── */
  V.route(/^\/hw\/([a-z0-9-]+)$/, async m => {
    const key = m[1]; V.loading(); let hw;
    try { hw = await api('GET', '/api/homework/' + key); } catch (e) { await V.loadOverview().catch(() => { }); hdr('homework'); return V.notFound(e.message); }
    if (!S.ov) await V.loadOverview().catch(() => { });
    hdr('homework');
    const hs = V.hw = { key, hw, answers: {}, order: {}, done: hw.status === 'done' };
    if (hw.status === 'done') { app.innerHTML = `<a class="back" href="#/homework">← Домашние задания</a><div class="score ok mt16"><div style="font-size:46px">✅</div><h2>ДЗ уже выполнено</h2><p class="mut2">Лучший результат: ${hw.best}%</p><div class="mt16"><a class="btn pri" href="#/cabinet">В кабинет</a></div></div>`; return; }
    const body = hw.questions.map((q, qi) => {
      const ord = shuffle(q.opts.map((_, i) => i)); hs.order[q.id] = ord;
      return `<div class="hwq" data-q="${q.id}"><div class="qn">ВОПРОС ${qi + 1} ИЗ ${hw.questions.length}</div><div class="q"><div class="q-t"><span data-notr>${q.q}</span>${q.say ? `<span class="ear-inline">${spBtn(q.say)}${spSlow(q.say)}</span>` : ''}</div>
        <div class="opts">${ord.map(i => `<button class="op" data-notr data-act="pick" data-q="${q.id}" data-i="${i}">${q.opts[i]}</button>`).join('')}</div><div class="q-fb" id="fb-${q.id}" data-notr></div></div></div>`;
    }).join('');
    app.innerHTML = `<a class="back" href="#/homework">← Домашние задания</a><div class="hwhead"><span class="bdg hw">Домашнее задание</span><h1 class="mt8">${h(hw.title)}</h1>
      <p class="mut2">${hw.questions.length} ${plural(hw.questions.length, ['вопрос', 'вопроса', 'вопросов'])} · зачёт от ${hw.pass}% · проверяется мгновенно${hw.attempts ? ` · попытка ${hw.attempts + 1}` : ''}</p></div>
      ${body}<div id="hwres"></div><div class="stick"><button class="btn pri" id="hwSubmit" data-act="hwsubmit" disabled>Проверить ответы</button></div>`;
    hwProgress();
  });
  function hwProgress() {
    const hs = V.hw; if (!hs) return;
    const n = Object.keys(hs.answers).length, tot = hs.hw.questions.length, b = document.getElementById('hwSubmit');
    if (b && !hs.done) { b.disabled = n < tot; b.textContent = n < tot ? `Отвечено ${n} из ${tot}` : 'Проверить ответы'; }
  }
  V.act('pick', el => {
    const hs = V.hw; if (!hs || hs.done) return;
    hs.answers[el.dataset.q] = +el.dataset.i;
    el.closest('.opts').querySelectorAll('.op').forEach(b => b.classList.toggle('sel', b === el)); hwProgress();
  });
  V.act('hwretry', () => V.render());
  V.act('hwsubmit', async () => {
    const hs = V.hw; if (!hs || hs.done || hs.busy) return; hs.busy = true;
    const b = document.getElementById('hwSubmit'); if (b) { b.disabled = true; b.textContent = 'Проверяем…'; }
    try {
      const r = await api('POST', `/api/homework/${hs.key}/submit`, { answers: hs.answers }); hs.done = true;
      r.results.forEach(x => {
        const box = app.querySelector(`.hwq[data-q="${CSS.escape(x.id)}"]`); if (!box) return;
        box.querySelectorAll('.op').forEach(btn => { const i = +btn.dataset.i; btn.style.pointerEvents = 'none'; btn.classList.remove('sel'); if (i === x.correct) btn.classList.add('ok'); else if (i === x.chosen) btn.classList.add('bad'); });
        const fb = document.getElementById('fb-' + x.id); fb.innerHTML = (x.ok ? '✓ ' : '✗ ') + x.why; fb.classList.add('show');
      });
      S.ov = null; document.querySelector('.stick').remove();
      document.getElementById('hwres').innerHTML = `<div class="score ${r.passed ? 'ok' : 'bad'}"><div class="sc">${r.score}%</div><h2 style="margin-top:6px">${r.passed ? 'ДЗ зачтено! 🎉' : 'Пока не зачтено'}</h2>
        <p class="mut2">Верно ${r.correct} из ${r.total}. ${r.passed ? '' : `Для зачёта нужно ${r.pass}%. Разберите ошибки выше — и пересдайте: вопросы будут другие.`}</p>
        <div class="row mt16" style="justify-content:center">${r.passed ? '<a class="btn pri" href="#/cabinet">В кабинет</a>' : '<button class="btn pri" data-act="hwretry">Пересдать с новыми вопросами</button>'}<a class="btn" href="#/homework">К списку ДЗ</a></div></div>`;
      document.getElementById('hwres').scrollIntoView({ behavior: 'smooth', block: 'center' }); if (r.passed) burst(160);
    } catch (e) { toast(e.message); hs.busy = false; hwProgress(); }
    hs.busy = false;
  });

  /* ── профиль ── */
  V.route(/^\/profile$/, async () => {
    V.loading(); await V.loadOverview(); hdr('profile');
    const u = S.user, teach = u.role !== 'student';
    let extra = { meeting_url: '', bio: '' };
    if (teach) { try { const t = await api('GET', '/api/teach'); extra.meeting_url = t.teacher.meeting_url || ''; } catch (e) { } }
    app.innerHTML = `<section class="phero"><h1>Профиль</h1><p>${S.cfg.legal === false ? 'Здесь вы управляете данными и уведомлениями.' : 'Здесь вы управляете данными, уведомлениями и согласиями.'}</p></section>
      <div class="cols2 mt16">
      <form class="card" data-form="profile" data-err="perr1"><h3>Данные и уведомления</h3>
        <label class="fld"><span>Email</span><input value="${h(u.email)}" disabled></label>
        <label class="fld"><span>Имя</span><input name="name" value="${h(u.name)}" maxlength="60" required></label>
        <label class="fld"><span>Часовой пояс (по нему приходят время уроков и напоминания)</span><select name="tz" class="sel">${V.tzOptions(u.tz)}</select></label>
        <label class="ck mt16"><input type="checkbox" name="notify" ${S.notify !== false ? 'checked' : ''}><span>Присылать напоминания об уроках и важные уведомления на email</span></label>
        ${S.cfg.legal === false ? '' : `<label class="ck"><input type="checkbox" name="ads" ${S.ads ? 'checked' : ''}><span>Получать новости, акции и рекламу Vosca (${V.legalLink('consent-ads', 'условия')}). Согласие можно отозвать здесь в любой момент.</span></label>`}
        ${teach ? `<label class="fld"><span>Моя ссылка на видеовстречу (Zoom, Google Meet, Яндекс Телемост…) — https://</span><input name="meeting_url" value="${h(extra.meeting_url)}" placeholder="https://meet.google.com/…" maxlength="300"></label>` : ''}
        <div class="fok hide" id="pok1"></div><div class="ferr hide" id="perr1"></div><button class="btn pri mt16" type="submit">Сохранить</button></form>
      ${teach ? '<div id="tprofBox" style="grid-column:1/-1"></div>' : ''}
      <form class="card" data-form="password" data-err="perr2"><h3>Сменить пароль</h3>
        <label class="fld"><span>Текущий пароль</span><input name="old" type="password" autocomplete="current-password" required></label>
        <label class="fld"><span>Новый пароль (от 8 символов)</span><input name="password" type="password" autocomplete="new-password" required></label>
        <div class="fok hide" id="pok2"></div><div class="ferr hide" id="perr2"></div><button class="btn pri mt16" type="submit">Сменить</button></form>
      ${S.cfg.legal === false ? '' : `<div class="card"><h3>Ваши данные и документы</h3><p class="mut2" style="font-size:14px;margin:8px 0 14px">Вы вправе получить копию своих данных и удалить аккаунт. Согласия сохраняются в журнале как факт, но обезличиваются.</p>
        <div class="row"><button class="btn" data-act="export">⬇️ Скачать мои данные</button>${V.demo ? '' : ''}</div>
        <div class="legal-links mt16">${V.legalLink('offer', 'Публичная оферта')} · ${V.legalLink('privacy', 'Политика обработки данных')} · ${V.legalLink('consent-pd', 'Согласие на обработку ПД')} · ${V.legalLink('consent-ads', 'Согласие на рассылки')}</div></div>`}
      ${u.role === 'admin' ? '' : `<form class="card danger" data-form="delacc" data-err="perr3"><h3>Удалить аккаунт</h3><p class="mut2" style="font-size:14px;margin:8px 0">Все данные, прогресс и расписание будут удалены без возможности восстановления. Для подтверждения введите пароль.</p>
        <label class="fld"><span>Пароль</span><input name="password" type="password" autocomplete="current-password" required></label><div class="ferr hide" id="perr3"></div><button class="btn mt16 dng" type="submit">Удалить навсегда</button></form>`}</div>`;
    if (teach) V.loadTeacherProfile('tprofBox');
  });
  V.form('profile', async fd => {
    V.hideEl('perr1'); const body = { name: fd.name, tz: fd.tz, notify: !!fd.notify }; if (S.cfg.legal !== false) body.ads = !!fd.ads; if (fd.meeting_url !== undefined) body.meeting_url = fd.meeting_url.trim();
    const r = await api('POST', '/api/account', body); S.user = r.user; S.ads = r.ads; S.notify = r.notify; S.ov = null; V.okMsg('pok1', 'Сохранено'); hdr('profile');
  });
  V.form('password', async (fd, f) => { V.hideEl('perr2'); await api('POST', '/api/account/password', { old: fd.old, password: fd.password }); f.reset(); V.okMsg('pok2', 'Пароль изменён'); });
  V.form('delacc', async fd => {
    V.hideEl('perr3'); if (!confirm('Удалить аккаунт и все данные безвозвратно?')) return;
    await api('POST', '/api/account/delete', { password: fd.password }); S.user = null; S.ov = null; S.checked = true; toast('Аккаунт удалён'); V.go('#/');
  });
  V.act('export', async () => {
    const d = await api('GET', '/api/account/export'), blob = new Blob([JSON.stringify(d, null, 2)], { type: 'application/json' }), a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = 'vosca-my-data.json'; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  });
})();
