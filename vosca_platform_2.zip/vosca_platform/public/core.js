'use strict';
/* ═══════════ ЯДРО: помощники, язык, транскрипция, озвучка ═══════════ */
const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => [...(r || document).querySelectorAll(s)];
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const shuffle = a => a.map(v => [Math.random(), v]).sort((x, y) => x[0] - y[0]).map(v => v[1]);
const rnd = a => a[Math.random() * a.length | 0];
const pad = n => String(n).padStart(2, '0');

/* контакты школы — меняются здесь, в одном месте */
const VOSCA = {
  site: 'https://voscaschool.com',
  email: 'voscaofficial0@gmail.com',
  phone: '+7 931 393-66-85',
  tel: '+79313936685',
  telegram: 'https://t.me/+79313936685'
};

/* хранилище: localStorage, а если он запрещён — память */
const Store = (() => {
  let ok = true, mem = {};
  try { localStorage.setItem('__v', '1'); localStorage.removeItem('__v'); } catch (e) { ok = false; }
  return {
    get(k, d) { try { const v = ok ? localStorage.getItem('vosca_g_' + k) : mem[k]; return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { const s = JSON.stringify(v); if (ok) localStorage.setItem('vosca_g_' + k, s); else mem[k] = s; } catch (e) { } },
    del(k) { try { if (ok) localStorage.removeItem('vosca_g_' + k); else delete mem[k]; } catch (e) { } }
  };
})();

/* язык интерфейса: ru / en. Тайский в уроке остаётся тайским. */
let LANG = 'ru';
/* t(['русский','english']) — выбирает строку по языку */
const t = p => Array.isArray(p) ? p[0] : p;

/* ═══════════ ТРАНСКРИПЦИЯ: латиница → кириллица с тонами ═══════════ */
const Cyr = (() => {
  const TONES = '̀́̂̌̄̋̃';
  const VOWELS_CYR = 'аеёиоуыэюя';
  const RULES = [
    ['iao', 'иау'], ['iaw', 'иау'], ['aai', 'аай'], ['aay', 'аай'], ['aao', 'аау'], ['aaw', 'аау'],
    ['ʉai', 'ыай'], ['uai', 'уай'], ['uay', 'уай'], ['ɔɔi', 'оой'], ['ooi', 'оой'], ['ooy', 'оой'],
    ['ɛɛo', 'ээу'], ['ɛɛw', 'ээу'], ['eeo', 'ееу'], ['eew', 'ееу'], ['iiu', 'ииу'], ['iiw', 'ииу'],
    ['kh', 'кх'], ['ph', 'пх'], ['th', 'тх'], ['ch', 'ч'], ['ng', 'нг'],
    ['ʉʉa', 'ыа'], ['ʉa', 'ыа'], ['iia', 'иа'], ['ia', 'иа'], ['uua', 'уа'], ['ua', 'уа'],
    ['aa', 'аа'], ['ii', 'ии'], ['uu', 'уу'], ['ʉʉ', 'ыы'], ['ee', 'ее'], ['ɛɛ', 'ээ'],
    ['ɔɔ', 'оо'], ['oo', 'оо'], ['əə', 'ээ'],
    ['ai', 'ай'], ['ay', 'ай'], ['ao', 'ау'], ['aw', 'ау'], ['oi', 'ой'], ['oy', 'ой'],
    ['ɔi', 'ой'], ['ɔy', 'ой'], ['ui', 'уй'], ['uy', 'уй'], ['iu', 'иу'], ['iw', 'иу'],
    ['eo', 'еу'], ['ew', 'еу'], ['ɛo', 'эу'], ['ɛw', 'эу'], ['əi', 'эй'],
    ['a', 'а'], ['i', 'и'], ['u', 'у'], ['ʉ', 'ы'], ['e', 'е'], ['ɛ', 'э'],
    ['ɔ', 'о'], ['o', 'о'], ['ə', 'э'],
    ['k', 'к'], ['p', 'п'], ['t', 'т'], ['d', 'д'], ['b', 'б'], ['f', 'ф'], ['s', 'с'],
    ['h', 'х'], ['l', 'л'], ['r', 'р'], ['m', 'м'], ['n', 'н'], ['w', 'в'], ['y', 'й'],
    ['c', 'ч'], ['j', 'дж'], ['g', 'г'], ['v', 'в'], ['z', 'з'], ['x', 'кс'], ['q', 'к'],
    ['ŋ', 'нг'], ['ʔ', ''], ['ʌ', 'а']
  ];
  const IDX = {};
  RULES.forEach(r => { (IDX[r[0][0]] = IDX[r[0][0]] || []).push(r); });
  function syl(s) {
    const nfd = s.normalize('NFD');
    let tone = '', bare = '';
    for (const ch of nfd) { if (TONES.includes(ch)) { if (!tone) tone = ch; } else bare += ch; }
    const upper = /^[A-ZА-Я]/.test(bare);
    bare = bare.toLowerCase();
    let out = '', i = 0;
    while (i < bare.length) {
      const list = IDX[bare[i]];
      let hit = null;
      if (list) for (const r of list) { if (bare.startsWith(r[0], i)) { hit = r; break; } }
      if (hit) { out += hit[1]; i += hit[0].length; } else { out += bare[i]; i++; }
    }
    if (tone) {
      const p = [...out].findIndex(c => VOWELS_CYR.includes(c));
      if (p >= 0) out = out.slice(0, p + 1) + tone + out.slice(p + 1);
    }
    if (upper && out) out = out[0].toUpperCase() + out.slice(1);
    return out.normalize('NFC');
  }
  const LETTER = /[A-Za-zɛɔəʉŋʔʌ̀-ͯ]/;
  function ru(txt) {
    if (!txt) return '';
    const s = String(txt).normalize('NFD');
    let out = '', buf = '';
    for (const ch of s) {
      if (LETTER.test(ch)) buf += ch;
      else { if (buf) { out += syl(buf); buf = ''; } out += ch; }
    }
    if (buf) out += syl(buf);
    return out.normalize('NFC');
  }
  return { ru, syl };
})();

const TrMode = {
  mode: Store.get('trmode', 'cyr'),
  hidden: Store.get('trhide', false),
  eff() { return this.mode; },
  apply() {
    document.body.classList.remove('trm-lat', 'trm-cyr', 'trm-both');
    document.body.classList.add('trm-' + this.eff());
    document.body.classList.toggle('tr-off', !!this.hidden);
    Store.set('trmode', this.mode); Store.set('trhide', this.hidden);
    const b = $('#trHideBtn');
    if (b) b.innerHTML = this.hidden ? t(['👁 Показать транскрипцию', '👁 Show transcription'])
      : t(['🙈 Скрыть транскрипцию', '🙈 Hide transcription']);
    $$('#trModeBtns .chip').forEach(c => c.classList.toggle('on', c.dataset.m === this.mode));
  },
  set(m) { this.mode = m; this.hidden = false; this.apply(); },
  toggleHide() { this.hidden = !this.hidden; this.apply(); }
};

const PH_SEL = '.ph,.w-ph,.ln-ph,.ex-ph,.tr-auto';
const LAT_RE = /[A-Za-zɛɔəʉŋ]/;
function upgradePh(root) {
  (root || document).querySelectorAll(PH_SEL).forEach(el => {
    if (el.dataset.phup) return;
    el.dataset.phup = '1';
    [...el.childNodes].forEach(n => {
      if (n.nodeType !== 3) return;
      const s = n.nodeValue;
      if (!s || !LAT_RE.test(s)) return;
      const wrap = document.createElement('span'); wrap.className = 'phw';
      const a = document.createElement('span'); a.className = 'tr-lat'; a.textContent = s;
      const b = document.createElement('span'); b.className = 'tr-cyr'; b.textContent = Cyr.ru(s);
      wrap.appendChild(a); wrap.appendChild(b);
      n.parentNode.replaceChild(wrap, n);
    });
  });
}
let _phT = null;
new MutationObserver(() => { clearTimeout(_phT); _phT = setTimeout(() => upgradePh(), 40); })
  .observe(document.body, { childList: true, subtree: true });

/* ═══════════ ОЗВУЧКА (устойчивая к iOS) ═══════════ */
const IS_IOS = /iP(hone|ad|od)/.test(navigator.userAgent) ||
  (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
const IS_SAFARI = /^((?!chrome|android|crios|fxios).)*safari/i.test(navigator.userAgent);

const Speech = {
  ready: false, unlocked: false, voices: [], th: [], ru: null,
  voiceIdx: Store.get('voice', 0),
  rate: Store.get('rate', 0.8),
  queue: [], busy: false, keepAlive: null, watchdog: null,
  supported() { return typeof speechSynthesis !== 'undefined' && typeof SpeechSynthesisUtterance !== 'undefined'; },
  init() {
    if (!this.supported()) {
      this.warn(t(['Браузер не поддерживает озвучку. Откройте урок в Safari (iPhone) или Chrome.',
        'This browser has no speech support. Open the lesson in Safari (iPhone) or Chrome.']));
      return;
    }
    let tries = 0;
    const load = () => {
      this.voices = speechSynthesis.getVoices() || [];
      if (this.voices.length) {
        this.th = this.voices.filter(v => /^th/i.test(v.lang));
        this.ru = this.voices.find(v => /^ru/i.test(v.lang)) || null;
        this.ready = true; this.fillVoiceSelect(); this.checkThai();
      } else if (tries++ < 40) setTimeout(load, 250);
      else { this.fillVoiceSelect(); this.checkThai(); }
    };
    load();
    try { speechSynthesis.onvoiceschanged = load; } catch (e) { }
    const unlock = () => {
      if (this.unlocked) return;
      this.unlocked = true;
      try {
        const u = new SpeechSynthesisUtterance('​');
        u.volume = 0.01; u.rate = 1; u.lang = 'th-TH'; speechSynthesis.speak(u);
      } catch (e) { }
      setTimeout(load, 300);
      ['touchend', 'pointerdown', 'click'].forEach(ev => document.removeEventListener(ev, unlock, true));
    };
    ['touchend', 'pointerdown', 'click'].forEach(ev => document.addEventListener(ev, unlock, true));
    document.addEventListener('visibilitychange', () => { if (document.hidden) this.stop(); });
  },
  checkThai() {
    const bar = $('#voicewarn'), tx = $('#voicewarntxt');
    if (!bar || !tx) return;
    if (this.th.length) { bar.classList.remove('show'); return; }
    bar.classList.add('show');
    tx.innerHTML = IS_IOS
      ? t(['<b>На этом iPhone не установлен тайский голос.</b> Включите его один раз: <b>Настройки → Универсальный доступ → Устный контент → Голоса → Тайский</b> (скачать). Потом вернитесь и нажмите 🔊. Пока голоса нет, фразы читаются системным голосом и звучат неточно.',
        '<b>No Thai voice on this iPhone.</b> Add it once: <b>Settings → Accessibility → Spoken Content → Voices → Thai</b> (download). Then come back and press 🔊. Until then phrases use the system voice and sound inaccurate.'])
      : t(['Тайский голос не найден — озвучка может звучать неточно. Android: Настройки → Система → Язык и ввод → Синтез речи → добавить тайский. Windows: Параметры → Время и язык → Речь → Добавить голоса → Thai. Лучше всего открыть урок в Chrome.',
        'No Thai voice found — audio may sound inaccurate. Android: Settings → System → Language & input → Text-to-speech → add Thai. Windows: Settings → Time & language → Speech → Add voices → Thai. Chrome works best.']);
  },
  warn(msg) { const bar = $('#voicewarn'), tx = $('#voicewarntxt'); if (bar && tx) { bar.classList.add('show'); tx.textContent = msg; } },
  voice(alt) {
    if (!this.th.length) return null;
    if (alt && this.th.length > 1) return this.th[(this.voiceIdx + 1) % this.th.length];
    return this.th[Math.min(this.voiceIdx, this.th.length - 1)];
  },
  fillVoiceSelect() {
    const s = $('#voiceSel'); if (!s) return;
    if (!this.th.length) { s.innerHTML = '<option>' + t(['тайский голос не найден', 'no Thai voice found']) + '</option>'; s.disabled = true; return; }
    s.disabled = false;
    s.innerHTML = this.th.map((v, i) => `<option value="${i}">${esc(v.name)}</option>`).join('');
    s.value = Math.min(this.voiceIdx, this.th.length - 1);
  },
  chunk(text) {
    const s = String(text).trim();
    if (s.length <= 90) return [s];
    const parts = s.split(/(?<=[.!?])\s+|\s{2,}/).filter(Boolean), out = [];
    parts.forEach(p => { while (p.length > 90) { let cut = p.lastIndexOf(' ', 90); if (cut < 40) cut = 90; out.push(p.slice(0, cut)); p = p.slice(cut).trim(); } if (p) out.push(p); });
    return out.length ? out : [s];
  },
  stop() {
    this.queue = []; this.busy = false;
    clearTimeout(this.watchdog); clearInterval(this.keepAlive); this.keepAlive = null;
    try { speechSynthesis.cancel(); } catch (e) { }
  },
  speak(text, opt) {
    opt = opt || {};
    if (!this.supported() || !text) { opt.onend && opt.onend(); return; }
    this.stop();
    const chunks = this.chunk(text);
    chunks.forEach((c, i) => this.queue.push({ text: c, opt, last: i === chunks.length - 1 }));
    setTimeout(() => this.pump(), IS_IOS ? 120 : 20);
  },
  enqueue(text, opt) {
    opt = opt || {};
    if (!this.supported() || !text) { opt.onend && opt.onend(); return; }
    this.chunk(text).forEach((c, i, a) => this.queue.push({ text: c, opt, last: i === a.length - 1 }));
    if (!this.busy) this.pump();
  },
  pump() {
    if (this.busy) return;
    const it = this.queue.shift();
    if (!it) { clearInterval(this.keepAlive); this.keepAlive = null; return; }
    this.busy = true;
    const o = it.opt, u = new SpeechSynthesisUtterance(it.text);
    u.lang = o.lang || 'th-TH';
    let r = o.rate != null ? o.rate : this.rate;
    r = IS_IOS ? Math.max(0.5, Math.min(1.6, r)) : Math.max(0.3, Math.min(2, r));
    u.rate = r; u.pitch = 1; u.volume = 1;
    const v = this.voice(o.alt); if (v) u.voice = v;
    const done = () => {
      if (u._done) return; u._done = 1; clearTimeout(this.watchdog); this.busy = false;
      if (it.last && o.onend) { try { o.onend(); } catch (e) { } }
      setTimeout(() => this.pump(), IS_IOS ? 90 : 10);
    };
    u.onend = done; u.onerror = done;
    this.watchdog = setTimeout(done, Math.max(1400, (it.text.length * 145) / r + 1200));
    try { speechSynthesis.speak(u); } catch (e) { done(); return; }
    if (!this.keepAlive) {
      this.keepAlive = setInterval(() => {
        try {
          if (!this.busy && !this.queue.length) { clearInterval(this.keepAlive); this.keepAlive = null; return; }
          if (speechSynthesis.paused) speechSynthesis.resume();
          else if (IS_SAFARI) { speechSynthesis.pause(); speechSynthesis.resume(); }
        } catch (e) { }
      }, 4000);
    }
  },
  seq(items, i) {
    i = i || 0;
    if (i === 0) this.stop();
    if (i >= items.length) return;
    const it = items[i];
    if (it.before) try { it.before(); } catch (e) { }
    const next = () => { if (it.after) try { it.after(); } catch (e) { } setTimeout(() => this.seq(items, i + 1), it.gap || 300); };
    if (i === 0) this.speak(it.text, { rate: it.rate, onend: next }); else this.enqueue(it.text, { rate: it.rate, onend: next });
  },
  test() {
    this.speak('สวัสดีครับ ยินดีต้อนรับ');
    const v = this.voice();
    toast(v ? t(['Голос: ', 'Voice: ']) + v.name + ' · ' + this.rate.toFixed(2) + '×'
      : t(['Тайский голос не найден — читаю системным голосом. См. подсказку вверху страницы.',
        'No Thai voice found — using the system voice. See the tip at the top.']));
  },
  setRate(r) {
    this.rate = +r; Store.set('rate', this.rate);
    const l = $('#rateVal'); if (l) l.textContent = this.rate.toFixed(2) + '×';
    const s = $('#rateSl'); if (s && +s.value !== this.rate) s.value = this.rate;
  }
};
function stopAll() { Speech.stop(); }
function say(text, el) {
  if (!text) return;
  if (el) { $$('.sp.on').forEach(b => b.classList.remove('on')); el.classList.add('on'); }
  Speech.speak(text, { onend: () => el && el.classList.remove('on') });
  if (el) setTimeout(() => el.classList.remove('on'), 9000);
}
function saySlow(text, el) {
  Speech.speak(text, { rate: Math.max(0.5, Speech.rate * 0.65), onend: () => el && el.classList.remove('on') });
  if (el) el.classList.add('on');
}
const spBtn = (txt, cls) => `<button class="sp ${cls || ''}" data-say="${esc(txt)}" title="${t(['Прослушать', 'Listen'])}" aria-label="${t(['Прослушать', 'Listen'])}">🔊</button>`;
const spSlow = txt => `<button class="sp mini slow" data-slow="${esc(txt)}" title="${t(['Медленно', 'Slowly'])}" aria-label="${t(['Медленно', 'Slowly'])}">🐢</button>`;

/* ═══════════ ИНТЕРФЕЙС: тост, очки, конфетти ═══════════ */
function toast(m) { const el = $('#toast'); el.textContent = m; el.classList.add('show'); clearTimeout(el._t); el._t = setTimeout(() => el.classList.remove('show'), 3200); }

const cfx = $('#cfx'); let cctx, parts = [];
function rz() { cfx.width = innerWidth; cfx.height = innerHeight; }
addEventListener('resize', rz); rz(); cctx = cfx.getContext('2d');
function burst(n) {
  const c = ['#3B8CFF', '#22D3EE', '#8B5CF6', '#34D399', '#FBBF24', '#FB7185'];
  for (let i = 0; i < (n || 150); i++) parts.push({ x: innerWidth / 2 + (Math.random() - .5) * 260, y: innerHeight * .34, vx: (Math.random() - .5) * 13, vy: Math.random() * -14 - 4, s: Math.random() * 7 + 3, c: c[i % c.length], r: Math.random() * 6, vr: (Math.random() - .5) * .35, l: 1 });
  if (!cfx._on) { cfx._on = 1; tick(); }
}
function tick() {
  cctx.clearRect(0, 0, cfx.width, cfx.height); parts = parts.filter(p => p.l > 0);
  parts.forEach(p => { p.x += p.vx; p.y += p.vy; p.vy += .36; p.vx *= .99; p.r += p.vr; p.l -= .0075; cctx.save(); cctx.translate(p.x, p.y); cctx.rotate(p.r); cctx.globalAlpha = Math.max(p.l, 0); cctx.fillStyle = p.c; cctx.fillRect(-p.s / 2, -p.s / 2, p.s, p.s * .6); cctx.restore(); });
  parts.length ? requestAnimationFrame(tick) : (cfx._on = 0);
}
