/* Vosca · ученики преподавателя, материалы для преподавания (преподаватель, админ, ученик) */
(function () {
  'use strict';
  const V = window.V, S = V.S, app = V.app, h = V.h, api = V.api, hdr = V.header;
  const KIND = { link: ['🔗', 'Ссылка'], text: ['📝', 'Текст'], file: ['📎', 'Файл'] };
  const kb = n => n > 1048576 ? (n / 1048576).toFixed(1).replace('.0', '') + ' МБ' : Math.max(1, Math.round(n / 1024)) + ' КБ';
  const tzShort = tz => (tz || '').split('/').pop().replace(/_/g, ' ');
  const MAT = {};                                   // id → материал (для модалов)
  let MSTU = [];                                    // ученики преподавателя (для отправки материала)

  /* ───────────── ученики преподавателя ───────────── */
  V.route(/^\/teach\/students$/, async () => {
    if (S.user && S.user.role === 'student') { hdr('cabinet'); return V.notFound('Нет доступа'); }
    V.loading(); await V.loadOverview(); hdr('tstudents');
    const d = await api('GET', '/api/teach/students'); TS = d;
    const langs = d.langs.map(l => `${l.flag} ${h(l.title)}`).join(' · ');
    app.innerHTML = `<section class="phero"><span class="pill">Преподаватель</span><h1>Мои ученики</h1>
      <p>Здесь все ученики, которых вы ведёте: назначайте им занятия и отправляйте материалы. Вы ведёте: <b>${langs}</b>.</p></section>
      <div class="sect"><h2>Закреплены за вами <small>${d.students.length}</small></h2>${d.students.length ? `<div class="stgrid">${d.students.map(stCard).join('')}</div>`
        : `<div class="empty"><div style="font-size:42px">👩‍🎓</div><b>Пока за вами нет учеников.</b><br>Ниже — ученики вашего языка без преподавателя: нажмите «Взять себе». Ещё ученики приходят двумя способами: сами запрашивают у вас урок на странице «Преподаватели» или их закрепляет администратор (в том числе сразу при выдаче кода).</div>`}</div>
      <div class="sect"><h2>Свободные ученики ваших языков <small>${d.free.length}</small></h2>
        <p class="mut2" style="font-size:14px;margin-bottom:10px">У этих учеников есть доступ к вашему языку, но пока нет преподавателя. Возьмите себе тех, с кем будете заниматься.</p>
        ${d.free.length ? `<div class="atw"><table class="at"><thead><tr><th>Ученик</th><th>Язык</th><th>Доступ открыт</th><th></th></tr></thead><tbody>${d.free.map(s => `<tr><td class="unm"><b>${h(s.name)}</b><span>${h(s.email)}</span></td><td>${s.flag} ${h(s.courseTitle)}</td><td>${V.fdate(s.since)}</td><td class="nw"><button class="btn pri sm" data-act="take" data-id="${s.id}" data-course="${h(s.course)}">Взять себе</button></td></tr>`).join('')}</tbody></table></div>`
          : '<div class="empty">Свободных учеников сейчас нет — все уже с преподавателями.</div>'}</div>`;
    V.refreshLive();
  });
  let TS = null;
  function stCard(s) {
    const lesson = s.next ? `<div class="stl ok">📅 Ближайший урок: <b>${h(V.fDay(s.next.starts))}, ${V.fTime(s.next.starts)}</b> <span class="mut">· у ученика ${V.fTime(s.next.starts, s.tz)} (${h(tzShort(s.tz))})</span></div>` : '<div class="stl">📅 Занятий пока не назначено</div>';
    const prog = s.ready ? `<div class="stp"><div class="bar"><i style="width:${s.percent}%"></i></div><span>${s.passed} из ${s.total} уроков · ${s.percent}%</span></div>` : '<div class="mut" style="font-size:13px;margin:8px 0">Уроков в платформе пока нет — занятия проходят онлайн с вами</div>';
    return `<div class="card stc"><div class="sth"><div class="tav ini" style="--h:${(s.id * 47) % 360}">${h(s.name.trim()[0] || '?')}</div><div><h3>${h(s.name)}</h3><div class="mut" style="font-size:13px">${h(s.email)}</div></div></div>
      <div class="row" style="gap:6px;margin:10px 0 2px"><span class="bdg">${s.flag} ${h(s.courseTitle)}</span>${s.active ? `<span class="bdg ok">доступ${s.until ? ' до ' + V.fdate(s.until) : ' бессрочно'}</span>` : '<span class="bdg bad">доступ закончился</span>'}${s.club === 'active' || s.club === 'expiring' ? '<span class="bdg go">🎤 клуб</span>' : ''}${s.pending ? `<a class="bdg hw" href="#/teach">🙋 запрос урока: ${s.pending}</a>` : ''}</div>
      ${prog}${lesson}<div class="mut" style="font-size:12.5px">${s.lastDone ? 'Последний проведённый урок: ' + h(V.fDayShort(s.lastDone)) : 'Проведённых уроков ещё нет'} · ${s.materials ? 'материалов отправлено: ' + s.materials : 'материалов не отправлено'}</div>
      <div class="row mt16"><button class="btn pri sm" data-act="stnew" data-id="${s.id}" data-course="${h(s.course)}" ${s.active ? '' : 'disabled'}>＋ Назначить урок</button><button class="btn sm" data-act="stmat" data-id="${s.id}" data-course="${h(s.course)}">📚 Отправить материал</button></div></div>`;
  }
  V.act('take', async el => { await api('POST', '/api/teach/students/take', { student: +el.dataset.id, course: el.dataset.course }); toast('Ученик теперь с вами. Назначьте ему первое занятие'); V.render(); });
  V.act('stnew', el => V.sessionModal({ students: TS.students.filter(s => s.active), tz: TS.tz, pick: el.dataset.id + '|' + el.dataset.course }));
  V.act('stmat', async el => {                                       // выбрать, какой материал отправить этому ученику
    const d = await api('GET', '/api/teach/materials'), cid = el.dataset.course, all = d.mine.concat(d.school).filter(m => !m.course || m.course === cid);
    d.mine.concat(d.school).forEach(m => { MAT[m.id] = m; });
    if (!all.length) return V.modal(`<div class="mbig">📚</div><h2>Материалов пока нет</h2><p>Добавьте материал в разделе «Материалы» — потом его можно отправить ученику отсюда.</p><div class="acts"><a class="btn pri" href="#/teach/materials" data-act="closemodal">Перейти в «Материалы»</a></div>`);
    V.modal(`<h2>Отправить материал</h2><form data-form="matshare1" data-sid="${el.dataset.id}" data-err="merr" style="text-align:left">
      <div class="matpick">${all.map((m, i) => `<label class="ck"><input type="radio" name="mat" value="${m.id}" ${i ? '' : 'checked'}><span>${KIND[m.kind][0]} <b>${h(m.title)}</b> <span class="mut">· ${m.school ? 'от школы' : 'мой'}</span></span></label>`).join('')}</div>
      <label class="fld mt16"><span>Записка ученику (необязательно)</span><input name="note" maxlength="300" placeholder="Например: посмотрите до пятницы"></label>
      <div class="ferr hide" id="merr"></div><div class="acts"><button class="btn pri" type="submit">Отправить ученику</button><button type="button" class="btn gho" data-act="closemodal">Отмена</button></div></form>`, { cls: 'wide' });
  });
  V.form('matshare1', async (fd, f) => { await api('POST', `/api/materials/${fd.mat}/share`, { students: [+f.dataset.sid], note: fd.note }); V.closeModal(); toast('Материал отправлен, ученик получил уведомление'); V.render(); });

  /* ───────────── карточки материалов ───────────── */
  function matBody(m) {
    if (m.kind === 'link') return `<a class="btn sm pri" href="${h(m.url)}" target="_blank" rel="noopener noreferrer">Открыть ссылку ↗</a>`;
    if (m.kind === 'file') return `<button class="btn sm pri" data-act="matfile" data-id="${m.id}">⬇ Скачать · ${h(m.file.name)} <span class="mut" style="color:inherit;opacity:.8">(${kb(m.file.size)})</span></button>`;
    return `<details class="mtext"><summary>Показать текст</summary><div>${h(m.text)}</div></details>`;
  }
  function matCard(m, o) {
    MAT[m.id] = m; o = o || {};
    const shares = m.mine && m.shares && m.shares.length ? `<div class="mem">${m.shares.map(x => `<span class="chip">${h(x.name)}${o.canShare ? `<button class="x" title="Отозвать доступ" data-act="matunshare" data-id="${m.id}" data-user="${x.id}">×</button>` : ''}</span>`).join('')}</div>` : '';
    return `<div class="card mat"><div class="mth"><span class="mic">${KIND[m.kind][0]}</span><div style="flex:1;min-width:0"><h3>${h(m.title)}</h3>
        <div class="row" style="gap:6px;margin-top:4px"><span class="bdg">${m.flag} ${h(m.courseTitle)}</span>${m.school ? '<span class="bdg go">от школы</span>' : o.student ? `<span class="bdg">${h(m.from.name)}</span>` : '<span class="bdg">мой</span>'}${o.admin ? `<span class="bdg">${h(m.ownerName)}</span>` : ''}${m.audience === 'all' && m.school ? '<span class="bdg ok">видят и ученики</span>' : ''}${o.admin && m.school && m.teachers.length ? `<span class="bdg">только: ${m.teachers.map(t => h(t.name)).join(', ')}</span>` : ''}</div></div></div>
      ${m.desc ? `<p class="mdesc">${h(m.desc)}</p>` : ''}${m.note ? `<div class="tnote">💬 ${h(m.note)}</div>` : ''}
      <div class="row mt16">${matBody(m)}${o.canShare ? `<button class="btn sm" data-act="matshare" data-id="${m.id}">📤 Отправить ученику</button>` : ''}${m.mine || o.admin ? `<button class="btn sm gho" data-act="matdel" data-id="${m.id}">Удалить</button>` : ''}</div>${shares}</div>`;
  }
  V.act('matfile', async el => {
    const f = await api('GET', `/api/materials/${el.dataset.id}/file`), bin = atob(f.b64), arr = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    const url = URL.createObjectURL(new Blob([arr], { type: f.mime })), a = document.createElement('a'); a.href = url; a.download = f.name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 5000);
  });
  V.act('matdel', el => V.confirm('Удалить материал?', 'Он пропадёт и у учеников, которым вы его отправляли.', 'Удалить', 'matdel2', { id: el.dataset.id }));
  V.act('matdel2', async el => { await api('POST', `/api/materials/${el.dataset.id}/delete`, {}); V.closeModal(); toast('Материал удалён'); V.render(); });
  V.act('matunshare', async el => { await api('POST', `/api/materials/${el.dataset.id}/unshare`, { student: +el.dataset.user }); toast('Доступ отозван'); V.render(); });
  V.act('matshare', el => {
    const m = MAT[el.dataset.id], list = MSTU.filter(s => !m.course || s.course === m.course), had = new Set((m.shares || []).map(x => x.id));
    if (!list.length) return V.modal(`<div class="mbig">👩‍🎓</div><h2>Некому отправлять</h2><p>Материал можно отправить только своим ученикам этого языка. <a href="#/teach/students" data-act="closemodal">Открыть «Ученики»</a> и возьмите учеников себе.</p>`);
    V.modal(`<h2>Отправить «${h(m.title)}»</h2><form data-form="matshare2" data-id="${m.id}" data-err="merr" style="text-align:left">
      <div class="matpick">${list.map(s => `<label class="ck"><input type="checkbox" name="stu" value="${s.id}" ${had.has(s.id) ? 'disabled checked' : ''}><span>${h(s.name)} <span class="mut">· ${s.flag} ${h(s.courseTitle)}${had.has(s.id) ? ' · уже отправлено' : ''}</span></span></label>`).join('')}</div>
      <label class="fld mt16"><span>Записка ученику (необязательно)</span><input name="note" maxlength="300" placeholder="Например: посмотрите до пятницы"></label>
      <div class="ferr hide" id="merr"></div><div class="acts"><button class="btn pri" type="submit">Отправить</button><button type="button" class="btn gho" data-act="closemodal">Отмена</button></div></form>`, { cls: 'wide' });
  });
  V.form('matshare2', async (fd, f) => {
    const ids = [...f.querySelectorAll('input[name=stu]:checked:not(:disabled)')].map(i => +i.value); if (!ids.length) throw new Error('Отметьте хотя бы одного ученика');
    const r = await api('POST', `/api/materials/${f.dataset.id}/share`, { students: ids, note: fd.note }); V.closeModal(); toast(`Отправлено учеников: ${r.shared}`); V.render();
  });

  /* ───────────── добавление материала (преподаватель и админ) ───────────── */
  V.matAddModal = o => {
    V.modal(`<div class="mbig">📚</div><h2>Добавить материал</h2>
      <form data-form="matadd" data-err="merr" data-admin="${o.admin ? 1 : ''}" style="text-align:left">
        <label class="fld"><span>Название</span><input name="title" maxlength="120" required placeholder="Например: Тоны тайского — шпаргалка"></label>
        <label class="fld"><span>Язык</span><select name="course" class="sel">${o.admin ? '<option value="">🌍 Все языки</option>' : ''}${o.langs.map(l => `<option value="${h(l.id)}">${l.flag} ${h(l.title)}</option>`).join('')}</select></label>
        <div class="fld"><span>Что добавляете</span><div class="seg" id="mkinds"><label><input type="radio" name="kind" value="link" checked data-chg="matkind"><span>🔗 Ссылка</span></label><label><input type="radio" name="kind" value="text" data-chg="matkind"><span>📝 Текст</span></label><label><input type="radio" name="kind" value="file" data-chg="matkind"><span>📎 Файл</span></label></div></div>
        <label class="fld mk mk-link"><span>Ссылка (https://…)</span><input name="url" maxlength="500" placeholder="https://drive.google.com/…"></label>
        <label class="fld mk mk-text hide"><span>Текст</span><textarea name="text" class="ta" rows="6" maxlength="8000" placeholder="Слова, правила, домашние заметки…"></textarea></label>
        <label class="fld mk mk-file hide"><span>Файл (до 3 МБ: PDF, картинка, Word, Excel, PowerPoint, TXT, MP3)</span><input type="file" name="file" accept=".pdf,.png,.jpg,.jpeg,.webp,.gif,.txt,.mp3,.m4a,.doc,.docx,.ppt,.pptx,.xls,.xlsx"><small class="mut">Больше 3 МБ? Загрузите на Google Drive или Яндекс Диск и добавьте ссылкой.</small></label>
        <label class="fld"><span>Описание (необязательно)</span><textarea name="desc" class="ta" rows="2" maxlength="600" placeholder="Для чего этот материал, на каком уроке использовать"></textarea></label>
        ${o.admin ? `<label class="ck mt8"><input type="checkbox" name="audience" value="all"><span>Показать также <b>ученикам</b> этого языка (по умолчанию — только преподавателям)</span></label>
          <div class="fld mt8"><span>Кому из преподавателей (если никого не отметить — всем преподавателям языка)</span><div class="langs">${o.teachers.map(t => `<label class="lg"><input type="checkbox" name="tch" value="${t.id}"><span>${h(t.name)}</span></label>`).join('')}</div></div>` : ''}
        <div class="ferr hide" id="merr"></div><div class="acts"><button class="btn pri" type="submit">Добавить</button><button type="button" class="btn gho" data-act="closemodal">Отмена</button></div></form>`, { cls: 'wide' });
  };
  V.act('matkind', el => { const f = el.closest('form'); ['link', 'text', 'file'].forEach(k => f.querySelector('.mk-' + k).classList.toggle('hide', k !== el.value)); });
  const readFile = file => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result)); r.onerror = () => rej(new Error('Не удалось прочитать файл')); r.readAsDataURL(file); });
  V.form('matadd', async (fd, f) => {
    const kind = fd.kind, body = { title: fd.title, course: fd.course, kind, desc: fd.desc };
    if (kind === 'link') body.url = (fd.url || '').trim(); else if (kind === 'text') body.text = fd.text;
    else { const file = f.querySelector('input[name=file]').files[0]; if (!file) throw new Error('Выберите файл'); if (file.size > 3 * 1048576) throw new Error('Файл больше 3 МБ — добавьте его ссылкой (Google Drive, Яндекс Диск)'); body.file = { name: file.name, data: await readFile(file) }; }
    if (f.dataset.admin) { body.audience = f.querySelector('input[name=audience]:checked') ? 'all' : 'teachers'; body.teachers = [...f.querySelectorAll('input[name=tch]:checked')].map(i => +i.value); }
    await api('POST', '/api/materials', body); V.closeModal(); toast('Материал добавлен'); V.render();
  });

  /* ───────────── преподаватель: материалы ───────────── */
  let MT = null;
  V.route(/^\/teach\/materials$/, async () => {
    if (S.user && S.user.role === 'student') { hdr('cabinet'); return V.notFound('Нет доступа'); }
    V.loading(); await V.loadOverview(); hdr('tmaterials');
    const d = MT = await api('GET', '/api/teach/materials'); MSTU = d.students;
    app.innerHTML = `<section class="phero"><span class="pill">Преподаватель</span><h1>Материалы для уроков</h1>
      <p>Всё, чем вы пользуетесь на занятиях: ссылки, тексты и файлы. Материалы школы добавляет администратор, свои — вы сами. Любой материал можно отправить ученику — он появится у него в разделе «Материалы».</p></section>
      <div class="row mt16"><button class="btn pri" data-act="matnew">＋ Добавить материал</button></div>
      ${d.school.length ? `<div class="sect"><h2>От школы <small>${d.school.length}</small></h2><div class="matgrid">${d.school.map(m => matCard(m, { canShare: 1 })).join('')}</div></div>` : ''}
      <div class="sect"><h2>Мои материалы <small>${d.mine.length}</small></h2>${d.mine.length ? `<div class="matgrid">${d.mine.map(m => matCard(m, { canShare: 1 })).join('')}</div>`
        : `<div class="empty"><div style="font-size:42px">📚</div><b>Своих материалов пока нет.</b><br>Нажмите «Добавить материал»: вставьте ссылку на видео, текст с правилами или загрузите PDF. ${d.school.length ? '' : 'Материалы школы появятся здесь, когда администратор их добавит.'}</div>`}</div>`;
  });
  V.act('matnew', () => V.matAddModal({ langs: MT.langs }));

  /* ───────────── админ: материалы ───────────── */
  let AM = null;
  V.route(/^\/admin\/materials$/, async () => {
    if (!S.user || S.user.role !== 'admin') { hdr('cabinet'); return V.notFound('Нет доступа'); }
    V.loading(); await V.loadOverview(); hdr('admin');
    const d = AM = await api('GET', '/api/admin/materials'), tabs = V.adminTabs ? V.adminTabs('materials') : '';
    const school = d.items.filter(m => m.school), teach = d.items.filter(m => !m.school);
    app.innerHTML = `<section class="phero"><span class="pill">Админка</span><h1>Материалы</h1>
      <p>Добавляйте материалы для преподавателей: ссылки, тексты, файлы. Можно выбрать язык и конкретных преподавателей, а ещё сделать материал видимым ученикам. Материалы, которые преподаватели добавили себе, видны ниже — их можно удалить.</p></section>${tabs}
      <div class="row mt16"><button class="btn pri" data-act="amnew">＋ Добавить материал</button></div>
      <div class="sect"><h2>Материалы школы <small>${school.length}</small></h2>${school.length ? `<div class="matgrid">${school.map(m => matCard(m, { admin: 1 })).join('')}</div>` : '<div class="empty">Пока нет. Добавьте первый — преподаватели увидят его в разделе «Материалы».</div>'}</div>
      <div class="sect"><h2>Добавили преподаватели <small>${teach.length}</small></h2>${teach.length ? `<div class="matgrid">${teach.map(m => matCard(m, { admin: 1 })).join('')}</div>` : '<div class="empty">Преподаватели ещё не добавляли свои материалы.</div>'}</div>`;
  });
  V.act('amnew', () => V.matAddModal({ admin: 1, langs: AM.langs, teachers: AM.teachers }));

  /* ───────────── ученик: материалы ───────────── */
  V.route(/^\/materials$/, async () => {
    if (S.user && S.user.role !== 'student') return V.go('#/teach/materials');
    V.loading(); await V.loadOverview(); hdr('materials');
    const d = await api('GET', '/api/materials');
    app.innerHTML = `<section class="phero"><span class="pill"><span class="dot"></span> От преподавателей</span><h1>Материалы</h1>
      <p>Ссылки, тексты и файлы, которые отправил вам преподаватель или школа. Когда появится новый материал, вы получите уведомление.</p></section>
      ${d.items.length ? `<div class="matgrid mt16">${d.items.map(m => matCard(m, { student: 1 })).join('')}</div>`
        : '<div class="empty mt24"><div style="font-size:42px">📚</div><b>Материалов пока нет.</b><br>Здесь появятся ссылки, тексты и файлы от вашего преподавателя — после занятий или по вашей просьбе.</div>'}`;
  });
})();
