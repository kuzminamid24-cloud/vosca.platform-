/* Vosca · клиент платформы — основа: состояние, запросы, маршруты, шапка, вход, юридические документы */
(() => {
  'use strict';
  const V = window.V = { S: { user: null, cfg: { passScore: 80, hwPass: 70, legal: true, contacts: {} }, ov: null, player: null, needConsent: [], checked: false, unread: 0 }, R: [], A: {}, F: {}, demo: !!window.VOSCA_DEMO };
  const S = V.S;
  const app = V.app = document.getElementById('app'), hdr = document.getElementById('hdr'), ftr = document.getElementById('ftr'), modalRoot = document.getElementById('modalRoot');

  /* ── помощники ── */
  const h = V.h = esc;
  V.t = VoscaI18n.t;
  V.plural = (n, a) => a[(n % 100 > 4 && n % 100 < 21) ? 2 : [2, 0, 1, 1, 1, 2][Math.min(n % 10, 5)]];
  V.fdate = ts => ts ? new Date(ts).toLocaleDateString(VoscaI18n.locale(), { day: 'numeric', month: 'short', year: 'numeric' }) : '—';
  V.fago = ts => {
    if (!ts) return 'никогда';
    const m = Math.round((Date.now() - ts) / 60000);
    if (m < 2) return 'только что'; if (m < 60) return m + ' мин назад';
    if (m < 1440) return Math.round(m / 60) + ' ч назад';
    const d = Math.round(m / 1440); return d + ' ' + V.plural(d, ['день', 'дня', 'дней']) + ' назад';
  };
  const DEVICE_TZ = (() => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'Europe/Moscow'; } catch (e) { return 'Europe/Moscow'; } })();
  V.deviceTz = DEVICE_TZ;
  V.tz = () => (S.user && S.user.tz) || DEVICE_TZ;
  V.now = () => Date.now() + (V.skew || 0);
  const fmt = (ts, o, tz) => { try { return new Intl.DateTimeFormat(VoscaI18n.locale(), Object.assign({ timeZone: tz || V.tz() }, o)).format(ts); } catch (e) { return new Date(ts).toLocaleString(VoscaI18n.locale()); } };
  V.fTime = (ts, tz) => fmt(ts, { hour: '2-digit', minute: '2-digit', hour12: false }, tz);
  V.fDay = (ts, tz) => { const x = fmt(ts, { weekday: 'long', day: 'numeric', month: 'long' }, tz); return x.charAt(0).toUpperCase() + x.slice(1); };
  V.fDayShort = (ts, tz) => fmt(ts, { weekday: 'short', day: 'numeric', month: 'short' }, tz);
  V.fDT = (ts, tz) => fmt(ts, { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit', hour12: false }, tz);
  V.dayKey = (ts, tz) => fmt(ts, { year: 'numeric', month: '2-digit', day: '2-digit' }, tz);
  /* «настенное» время в поясе → момент в UTC (с учётом перехода на летнее время) */
  function tzOffset(ts, tz) {
    const p = Object.fromEntries(new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' }).formatToParts(new Date(ts)).map(x => [x.type, +x.value]));
    return Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second) - Math.floor(ts / 1000) * 1000;
  }
  V.zoned = (dateStr, timeStr, tz) => {
    const d = String(dateStr).split('-').map(Number), t = String(timeStr).split(':').map(Number);
    if (d.length < 3 || t.length < 2 || d.some(isNaN) || t.some(isNaN)) return NaN;
    const guess = Date.UTC(d[0], d[1] - 1, d[2], t[0], t[1]); let ts = guess - tzOffset(guess, tz); ts = guess - tzOffset(ts, tz); return ts;
  };
  V.inputDate = (ts, tz) => { const p = Object.fromEntries(new Intl.DateTimeFormat('en-CA', { timeZone: tz || V.tz(), year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(new Date(ts)).map(x => [x.type, x.value])); return `${p.year}-${p.month}-${p.day}`; };
  V.cd = ms => {
    if (ms <= 0) return 'идёт сейчас';
    const m = Math.ceil(ms / 60000);
    if (m < 60) return 'через ' + m + ' мин';
    if (m < 1440) { const hh = Math.floor(m / 60), mm = m % 60; return 'через ' + hh + ' ч' + (mm ? ' ' + mm + ' мин' : ''); }
    const d = Math.floor(m / 1440); return 'через ' + d + ' ' + V.plural(d, ['день', 'дня', 'дней']);
  };
  V.TZ_LIST = ['Europe/Kaliningrad', 'Europe/Moscow', 'Europe/Samara', 'Asia/Yekaterinburg', 'Asia/Omsk', 'Asia/Novosibirsk', 'Asia/Krasnoyarsk', 'Asia/Irkutsk', 'Asia/Yakutsk', 'Asia/Vladivostok', 'Asia/Magadan', 'Asia/Kamchatka',
    'Europe/Kyiv', 'Europe/Minsk', 'Europe/Berlin', 'Europe/London', 'Europe/Istanbul', 'Asia/Tbilisi', 'Asia/Yerevan', 'Asia/Baku', 'Asia/Almaty', 'Asia/Tashkent', 'Asia/Dubai', 'Asia/Bangkok', 'Asia/Ho_Chi_Minh', 'Asia/Singapore', 'Asia/Shanghai', 'Asia/Tokyo', 'Australia/Sydney', 'America/New_York', 'America/Chicago', 'America/Los_Angeles'];
  V.tzOptions = cur => { const l = V.TZ_LIST.includes(cur) ? V.TZ_LIST : [cur].concat(V.TZ_LIST); return l.map(z => `<option value="${h(z)}" ${z === cur ? 'selected' : ''}>${h(z.replace(/_/g, ' '))} (${tzLabel(z)})</option>`).join(''); };
  function tzLabel(z) { try { const o = tzOffset(Date.now(), z) / 60000, a = Math.abs(o); return 'UTC' + (o < 0 ? '−' : '+') + Math.floor(a / 60) + (a % 60 ? ':' + String(a % 60).padStart(2, '0') : ''); } catch (e) { return ''; } }
  V.tzLabel = tzLabel;

  /* ── запросы ── */
  async function netApi(method, url, body) {
    const r = await fetch(url, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined, credentials: 'same-origin' });
    let data = null; try { data = await r.json(); } catch (e) { }
    return { status: r.status, data };
  }
  V.api = async (method, url, body) => {
    if (/^\/api\//.test(url) && VoscaI18n.lang === 'en') url += (url.includes('?') ? '&' : '?') + 'lang=en';      // названия уроков и вопросы ДЗ — на языке интерфейса
    const r = await (window.VOSCA_API || netApi)(method, url, body);
    if (r.status >= 200 && r.status < 300) return r.data;
    const err = new Error((r.data && r.data.error) || 'Ошибка ' + r.status); err.status = r.status; err.data = r.data;
    if (r.status === 401 && S.user) { S.user = null; S.ov = null; V.go('#/'); }
    if (r.status === 403 && r.data && r.data.needConsent) { S.needConsent = r.data.needConsent; consentModal(); }
    throw err;
  };
  const api = V.api;
  V.home = () => !S.user ? '#/' : S.user.role === 'admin' ? '#/admin' : S.user.role === 'teacher' ? '#/teach' : '#/cabinet';
  V.go = hash => { if (location.hash === hash) V.render(); else location.hash = hash; };
  V.loading = () => { app.innerHTML = '<div class="loading">Загружаем<span class="dots"></span></div>'; };
  V.loadOverview = async () => {
    const ov = await api('GET', '/api/overview');
    S.ov = ov; S.user = ov.user; S.cfg = ov.config; S.needConsent = ov.needConsent || []; S.unread = ov.unread || 0; S.ads = ov.ads; S.notify = ov.notify;
    if (ov.now) V.skew = ov.now - Date.now();
    if (S.needConsent.length) consentModal();
    return ov;
  };
  V.route = (re, fn, opt) => V.R.push({ re, fn, pub: !!(opt && opt.pub) });
  V.act = (name, fn) => { V.A[name] = fn; };
  V.form = (name, fn) => { V.F[name] = fn; };
  V.showErr = (id, msg) => { const e = document.getElementById(id); if (e) { e.textContent = msg; e.classList.remove('hide'); } };
  V.hideEl = id => { const e = document.getElementById(id); if (e) e.classList.add('hide'); };
  V.okMsg = (id, msg) => { const e = document.getElementById(id); if (e) { e.textContent = msg; e.classList.remove('hide'); } };
  V.notFound = msg => { app.innerHTML = `<div class="empty mt32"><div style="font-size:46px">🤔</div><b>${h(msg || 'Страница не найдена')}</b><div class="mt16"><a class="btn pri" href="${V.home()}">${S.user && S.user.role !== 'student' ? 'На главную' : 'В кабинет'}</a></div></div>`; };
  V.copy = async txt => { try { await navigator.clipboard.writeText(txt); toast('Скопировано'); } catch (e) { const i = document.createElement('input'); i.value = txt; document.body.appendChild(i); i.select(); try { document.execCommand('copy'); toast('Скопировано'); } catch (e2) { toast(txt); } i.remove(); } };

  /* ── модальные окна ── */
  V.modal = (html, opt) => { modalRoot.innerHTML = `<div class="mback" ${opt && opt.sticky ? 'data-sticky="1"' : ''}><div class="modal ${opt && opt.cls || ''}">${html}</div></div>`; const f = modalRoot.querySelector('input:not([type=checkbox]),textarea,select'); if (f && matchMedia('(min-width:700px)').matches) f.focus(); };
  V.closeModal = () => { modalRoot.innerHTML = ''; };
  V.confirm = (title, text, okLabel, act, data) => V.modal(`<div class="mbig">🤔</div><h2>${h(title)}</h2><p>${text}</p><div class="acts"><button class="btn pri" data-act="${act}" ${Object.entries(data || {}).map(([k, v]) => `data-${k}="${h(v)}"`).join(' ')}>${h(okLabel)}</button><button class="btn gho" data-act="closemodal">Отмена</button></div>`);

  /* ── шапка и подвал ── */
  const KIND_ICON = { welcome: '👋', course: '🔓', unlock: '🔓', hw_new: '📝', achievement: '🏆', live_new: '🎥', live_moved: '🕒', live_cancelled: '❌', live_r24: '⏰', live_r15: '🎥', live_series: '📅', live_decline: '🙋', teacher_note: '💬', teacher: '👩‍🏫', req_new: '🙋', req_declined: '🙅', club_booked: '🎤', club_join: '🎤', material: '📚', club_link: '🔗' };
  V.header = active => {
    if (!S.user) { delete document.documentElement.dataset.role; hdr.innerHTML = `<div class="hd"><a class="logo" href="#/"><img src="/logo.png" alt=""><div><b>Vosca</b><span>language school</span></div></a><div class="uwho">${VoscaI18n.switcher()}</div></div>`; V.footer(); return; }
    const pend = S.ov ? S.ov.pendingHw.length : 0, role = S.user.role;
    document.documentElement.dataset.role = role;
    const links = role === 'student'
      ? [['#/cabinet', 'cabinet', 'Кабинет'], ['#/courses', 'courses', 'Курсы'], ['#/schedule', 'schedule', 'Расписание'], ['#/club', 'club', 'Клуб'], ['#/teachers', 'teachers', 'Преподаватели'], ['#/materials', 'materials', 'Материалы'], ['#/homework', 'homework', 'ДЗ' + (pend ? `<span class="n">${pend}</span>` : '')], ['#/profile', 'profile', 'Профиль']]
      : role === 'teacher' ? [['#/teach', 'teach', 'Занятия'], ['#/teach/students', 'tstudents', 'Ученики'], ['#/teach/materials', 'tmaterials', 'Материалы'], ['#/teach/club', 'teachclub', 'Разговорный клуб'], ['#/profile', 'profile', 'Профиль']]
        : [['#/admin', 'admin', 'Админка'], ['#/profile', 'profile', 'Профиль']];
    const badge = role === 'student' ? '' : `<span class="rbadge ${role}">${role === 'admin' ? 'Администратор' : 'Преподаватель'}</span>`;
    hdr.innerHTML = `<div class="hd"><a class="logo" href="${V.home()}"><img src="/logo.png" alt=""><div><b>Vosca</b><span>language school</span></div></a>
      <div class="uwho">${VoscaI18n.switcher()}<button class="bell" data-act="bell" aria-label="Уведомления" title="Уведомления">🔔${S.unread ? `<i>${S.unread > 9 ? '9+' : S.unread}</i>` : ''}</button>${badge}<span class="unm">${h(S.user.name)}</span><a class="uavl" href="#/profile">${S.user.photo ? `<img class="uav" src="${h(S.user.photo)}" alt="">` : `<div class="uav">${h(S.user.name.trim()[0] || '?')}</div>`}</a><button class="btn sm gho" data-act="logout">Выйти</button></div></div>
      <nav class="navs">${links.map(l => `<a href="${l[0]}" class="${active === l[1] ? 'on' : ''}">${l[2]}</a>`).join('')}</nav><div id="bellPanel" class="bellp hide"></div>`;
    V.footer();
  };
  V.footer = () => {
    const c = (S.cfg && S.cfg.contacts) || {};
    ftr.innerHTML = `<div class="ftr ${S.cfg.legal === false ? 'solo' : ''}">${S.cfg.legal === false ? '' : '<div class="fl"><a href="#/legal/offer">Оферта</a><a href="#/legal/privacy">Политика обработки данных</a><a href="#/legal/consent-pd">Согласие на обработку ПД</a><a href="#/legal/consent-ads">Согласие на рассылки</a></div>'}
      <div class="fr">© Vosca · Нужна помощь? ${c.email ? `<a href="mailto:${h(c.email)}">${h(c.email)}</a>` : ''}${c.phone ? ` · <a href="tel:${h(c.phone.replace(/[^\d+]/g, ''))}">${h(c.phone)}</a>` : ''}</div></div>`;
  };
  async function toggleBell() {
    const p = document.getElementById('bellPanel'); if (!p) return;
    if (!p.classList.contains('hide')) { p.classList.add('hide'); return; }
    p.classList.remove('hide'); p.innerHTML = '<div class="bn-empty">Загружаем…</div>';
    try {
      const r = await api('GET', '/api/notifications');
      p.innerHTML = `<div class="bn-h"><b>Уведомления</b><button class="btn sm gho" data-act="closebell">Закрыть</button></div>` + (r.items.length ? r.items.slice(0, 25).map(n => `<a class="bn ${n.read ? '' : 'new'}" href="${h(n.link || '#/cabinet')}" data-act="closebell"><span class="e">${KIND_ICON[n.kind] || '🔔'}</span><span class="t"><b>${h(n.title)}</b>${n.body ? `<small>${h(n.body)}</small>` : ''}<em>${V.fago(n.at)}</em></span></a>`).join('') : '<div class="bn-empty">Пока тихо. Здесь будут напоминания об уроках, новых ДЗ и достижениях.</div>');
      if (r.unread) { await api('POST', '/api/notifications/read', {}); S.unread = 0; const b = document.querySelector('.bell i'); if (b) b.remove(); }
    } catch (e) { p.innerHTML = `<div class="bn-empty">${h(e.message)}</div>`; }
  }
  V.act('bell', toggleBell);
  V.act('closebell', () => { const p = document.getElementById('bellPanel'); if (p) p.classList.add('hide'); });

  /* ── юридические документы ── */
  const LEGAL_LINK = (d, t) => `<a href="#/legal/${d}" target="_blank" rel="noopener">${t}</a>`;
  V.legalLink = LEGAL_LINK;
  function consentModal() {
    if (!S.needConsent.length || document.getElementById('consentBox')) return;
    V.modal(`<div class="mbig">📄</div><h2>Мы обновили документы</h2><p>Чтобы продолжить, ознакомьтесь и подтвердите согласие с новой редакцией:</p>
      <div class="unl" id="consentBox">${S.needConsent.map(d => `<div><span class="e">📄</span><span>${LEGAL_LINK(d.id, h(d.title))}</span></div>`).join('')}</div>
      <div class="acts"><button class="btn pri" data-act="accept">Ознакомился(лась) и принимаю</button><button class="btn gho" data-act="logout">Выйти</button></div>`, { sticky: true });
  }
  V.act('accept', async () => {
    try { const r = await api('POST', '/api/consent/accept', { docs: S.needConsent.map(d => d.id) }); S.needConsent = r.needConsent || []; V.closeModal(); toast('Спасибо!'); V.render(); } catch (e) { toast(e.message); }
  });

  V.route(/^\/legal\/([a-z-]+)$/, async m => {
    if (S.user) { V.header(''); } else V.header();
    if (S.cfg.legal === false) return V.notFound('Документ не найден');
    V.loading();
    let d; try { d = await api('GET', '/api/legal/' + m[1]); } catch (e) { return V.notFound('Документ не найден'); }
    const adm = S.user && S.user.role === 'admin';
    app.innerHTML = `<a class="back" href="${V.home()}">← ${S.user ? (S.user.role === 'student' ? 'В кабинет' : 'На главную') : 'Назад'}</a>
      <article class="legal"><h1>${h(d.title)}</h1><div class="lv">Редакция от ${h(d.version)}</div>
      ${adm && d.missing.length ? `<div class="notice">⚠️ Не заполнены реквизиты оператора (${d.missing.length}) — они подсвечены в тексте. <a class="btn sm pri" href="#/admin/legal">Заполнить</a></div>` : ''}
      <div class="lbody">${d.html}</div>
      <div class="lnav">${['offer', 'privacy', 'consent-pd', 'consent-ads'].filter(x => x !== m[1]).map(x => `<a href="#/legal/${x}">${h({ offer: 'Публичная оферта', privacy: 'Политика обработки данных', 'consent-pd': 'Согласие на обработку ПД', 'consent-ads': 'Согласие на рассылки' }[x])}</a>`).join('')}</div></article>`;
  }, { pub: true });

  /* ── вход и регистрация: три отдельных входа — ученик, преподаватель, администратор ── */
  const PORTAL = {
    student: { pill: 'Платформа Vosca', h1: 'Учитесь в своём темпе. <em>Всё под рукой.</em>', lead: 'Один аккаунт — ваши курсы, расписание живых уроков, домашние задания и прогресс.' },
    teacher: { pill: 'Для преподавателей', h1: 'Ваши занятия. <em>Без суеты.</em>', lead: 'Ваши ученики, расписание занятий, ссылка на видеовстречу и заметки после урока — в одном месте.' },
    admin: { pill: 'Для администраторов', h1: 'Школа под контролем. <em>Всё в одной панели.</em>', lead: 'Ученики, преподаватели, доступ к курсам, коды и приглашения, контент и письма.' }
  };
  const PERKS = {
    student: [['🔓', 'Уроки открываются сами', `Прошли урок на ${'${PASS}'}% и больше — следующий уже открыт.`], ['🎥', 'Живые уроки с преподавателем', 'Расписание, ссылка на видеовстречу и напоминание на почту — в одном месте.'], ['📝', 'Домашние задания появляются сами', 'Сразу после урока, проверка мгновенная.']],
    teacher: [['📅', 'Назначайте занятия', 'Один раз или каждую неделю — ученик получит письмо и напоминания.'], ['🎥', 'Одна постоянная ссылка', 'Кнопка «Подключиться» появляется у ученика за 10 минут до начала.'], ['💬', 'Заметки после урока', 'Ученик видит их в своём кабинете.']],
    admin: [['👥', 'Ученики и преподаватели', 'Доступ к курсам, роли, прогресс.'], ['🔑', 'Коды и приглашения', 'Коды курсов — ученикам, приглашения — преподавателям и администраторам.'], ['📚', 'Контент', 'Загрузка уроков на русском и английском.']]
  };
  const codeFromHash = () => { const q = (location.hash.split('?')[1] || ''); try { return (new URLSearchParams(q).get('code') || '').toUpperCase(); } catch (e) { return ''; } };
  function viewAuth(portal, mode) {
    V.header();
    portal = PORTAL[portal] ? portal : 'student';
    const reg = mode === 'register', join = mode === 'join', P = PORTAL[portal];
    const base = portal === 'student' ? '' : '/' + portal, canJoin = portal !== 'student';
    const pre = portal === 'admin' ? '#/admin' : '#/teacher';
    const title = join ? (portal === 'admin' ? 'Регистрация администратора' : 'Регистрация преподавателя') : reg ? 'Создать аккаунт' : portal === 'student' ? 'С возвращением!' : portal === 'teacher' ? 'Вход для преподавателей' : 'Вход для администраторов';
    const sub = join ? 'Введите код приглашения, который выдал администратор школы.' : reg ? (S.cfg.requireCode === false ? 'Это бесплатно. Доступ к курсу откроется после покупки или по коду.' : 'Для регистрации нужен код доступа Vosca — его выдаёт школа после оплаты. По коду вам откроется нужный язык.') : portal === 'student' ? 'Войдите, чтобы продолжить учёбу.' : portal === 'teacher' ? 'Войдите в кабинет преподавателя.' : 'Войдите в панель администратора.';
    const legalBox = (reg || join) && S.cfg.legal !== false ? `<div class="cons">
          <label class="ck"><input type="checkbox" name="c_offer"><span>Принимаю условия ${LEGAL_LINK('offer', 'Публичной оферты')} <b class="req">*</b></span></label>
          <label class="ck"><input type="checkbox" name="c_pd"><span>Даю согласие на обработку моих персональных данных на условиях ${LEGAL_LINK('consent-pd', 'Согласия')} и ${LEGAL_LINK('privacy', 'Политики обработки данных')} <b class="req">*</b></span></label>
          <label class="ck"><input type="checkbox" name="c_age"><span>Мне исполнилось 18 лет либо у меня есть согласие родителя (законного представителя) на регистрацию и обучение <b class="req">*</b></span></label>
          ${reg ? `<label class="ck opt"><input type="checkbox" name="c_ads"><span>Хочу получать новости, акции и рекламные материалы Vosca по email — ${LEGAL_LINK('consent-ads', 'условия согласия')}. Необязательно, отозвать можно в любой момент.</span></label>` : ''}
        </div>` : '';
    const demoHint = V.demo ? (join ? `<div class="notice dnote">Демо-версия: для проверки используйте код <b>${portal === 'admin' ? 'ADMIN-DEMO-0001' : 'TEACH-DEMO-0001'}</b>. Данные хранятся только в этом браузере.</div>`
      : `<div class="notice dnote">${reg ? 'Демо-версия: аккаунт хранится только в этом браузере и никуда не отправляется. Придумайте любое имя и вымышленный email — настоящие данные вводить не нужно. Коды для проверки: VOSCA-DEMO-TEST (тайский), VOSCA-DEMO-FREN (французский), VOSCA-DEMO-ENGL (английский), VOSCA-DEMO-ESPA (испанский), VOSCA-DEMO-ZHON (китайский), VOSCA-DEMO-RUSS (русский).' : (portal === 'student' ? 'Демо-версия: можно войти кнопками «Войти как» внизу страницы или зарегистрироваться.' : 'Демо-версия: войдите кнопками «Войти как» внизу страницы или зарегистрируйтесь по коду приглашения.')}</div>`) : '';
    const sw = join ? `Уже есть аккаунт? <a href="${pre}">Войти</a>` : reg ? 'Уже есть аккаунт? <a data-act="mode" data-m="login">Войти</a>'
      : portal === 'student' ? 'Впервые здесь? <a data-act="mode" data-m="register">Создать аккаунт</a>' : `Есть код приглашения? <a href="${pre}/join">Зарегистрироваться по коду</a>`;
    const others = portal === 'student' ? '<a href="#/teacher">Вход для преподавателей</a>' : portal === 'teacher' ? '<a href="#/">Вход для учеников</a><a href="#/admin">Вход для администраторов</a>' : '<a href="#/">Вход для учеников</a><a href="#/teacher">Вход для преподавателей</a>';
    app.innerHTML = `<div class="auth ${'p-' + portal}">
      <div class="lead">
        <span class="pill"><span class="dot"></span> ${P.pill}</span>
        <h1>${P.h1}</h1>
        <p>${P.lead}</p>
        <div class="perks">${PERKS[portal].map(x => `<div class="perk"><div class="e">${x[0]}</div><div><b>${x[1]}</b><span>${x[2].replace('${PASS}', S.cfg.passScore)}</span></div></div>`).join('')}</div>
      </div>
      <form class="authcard" data-form="${join ? 'join' : reg ? 'register' : 'login'}" novalidate>
        <h2>${title}</h2>
        <p class="mut2" style="font-size:14px">${sub}</p>
        ${demoHint}
        <input type="hidden" name="portal" value="${portal}">
        ${join ? `<label class="fld"><span>Код приглашения</span><input name="code" value="${h(codeFromHash())}" autocomplete="off" autocapitalize="characters" placeholder="${portal === 'admin' ? 'ADMIN' : 'TEACH'}-XXXX-XXXX" required></label>` : ''}
        ${reg && S.cfg.requireCode !== false ? `<label class="fld"><span>Код доступа Vosca</span><input name="code" value="${h(codeFromHash())}" autocomplete="off" autocapitalize="characters" placeholder="VOSCA-XXXX-XXXX" required><small class="mut" style="font-size:12.5px">Код выдаёт школа после оплаты. Нет кода? Напишите: ${((S.cfg.contacts || {}).email) ? `<a href="mailto:${h(S.cfg.contacts.email)}">${h(S.cfg.contacts.email)}</a>` : ''}${(S.cfg.contacts || {}).phone ? ` · <a href="tel:${h(S.cfg.contacts.phone.replace(/[^\d+]/g, ''))}">${h(S.cfg.contacts.phone)}</a>` : ''}</small></label>` : ''}
        ${reg || join ? '<label class="fld"><span>Ваше имя</span><input name="name" autocomplete="name" maxlength="60" required></label>' : ''}
        <label class="fld"><span>Email</span><input name="email" type="email" autocomplete="email" required></label>
        <label class="fld"><span>Пароль${reg || join ? ' (от 8 символов)' : ''}</span><input name="password" type="password" autocomplete="${reg || join ? 'new-password' : 'current-password'}" required></label>
        ${legalBox}
        <div class="ferr hide" id="ferr"></div>
        <button class="btn pri" type="submit">${join ? 'Зарегистрироваться' : reg ? 'Зарегистрироваться' : 'Войти'}</button>
        <div class="switch">${sw}</div>
        <div class="portals">${others}</div>
      </form></div>`;
    const first = app.querySelector('input:not([type=hidden])'); if (first && matchMedia('(min-width:700px)').matches) first.focus();
  }
  V.form('login', async fd => {
    V.hideEl('ferr');
    const r = await api('POST', '/api/login', { email: fd.email, password: fd.password, tz: DEVICE_TZ, portal: fd.portal || 'student' });
    S.user = r.user; S.ov = null; V.go(V.home());
  }, 'ferr');
  V.form('register', async (fd, f) => {
    V.hideEl('ferr');
    if (S.cfg.legal !== false && (!fd.c_offer || !fd.c_pd || !fd.c_age)) throw new Error('Отметьте обязательные согласия (со звёздочкой), чтобы зарегистрироваться');
    if (S.cfg.requireCode !== false && !(fd.code || '').trim()) throw new Error('Введите код доступа Vosca — его выдаёт школа');
    const r = await api('POST', '/api/register', { code: fd.code, name: fd.name, email: fd.email, password: fd.password, tz: DEVICE_TZ, consents: S.cfg.legal === false ? {} : { offer: true, pd: true, age: true, ads: !!fd.c_ads } });
    S.user = r.user; S.ov = null; V.go('#/cabinet'); setTimeout(() => { toast('Добро пожаловать в Vosca! 🎉'); burst(110); }, 400);
  }, 'ferr');
  V.form('join', async fd => {
    V.hideEl('ferr');
    if (S.cfg.legal !== false && (!fd.c_offer || !fd.c_pd || !fd.c_age)) throw new Error('Отметьте обязательные согласия (со звёздочкой), чтобы зарегистрироваться');
    const r = await api('POST', '/api/staff/register', { code: fd.code, name: fd.name, email: fd.email, password: fd.password, tz: DEVICE_TZ, consents: S.cfg.legal === false ? {} : { offer: true, pd: true, age: true } });
    S.user = r.user; S.ov = null; V.go(V.home()); setTimeout(() => { toast('Добро пожаловать в команду Vosca! 🎉'); burst(80); }, 400);
  }, 'ferr');
  V.act('mode', el => { location.hash = el.dataset.m === 'register' ? '#/register' : '#/login'; });
  V.act('logout', async () => { try { await api('POST', '/api/logout', {}); } catch (e) { } S.user = null; S.ov = null; S.checked = true; S.needConsent = []; V.closeModal(); V.go('#/'); });
  V.act('closemodal', () => V.closeModal());
  V.act('lang', el => VoscaI18n.set(el.dataset.l));
  V.act('reload', () => V.render());

  /* ── роутер ── */
  let seq = 0;
  V.render = async () => {
    const my = ++seq;
    if (!document.getElementById('consentBox')) V.closeModal();
    S.player = null; V.hw = null; window.scrollTo(0, 0);
    const hash = (location.hash.replace(/^#/, '') || '/').split('?')[0];
    try {
      if (!S.checked) { const me = await api('GET', '/api/me'); S.checked = true; S.user = me.user; S.cfg = me.config; S.needConsent = me.needConsent || []; S.unread = me.unread || 0; }
      if (my !== seq) return;
      const area = /^\/admin(\/|$)/.test(hash) ? 'admin' : /^\/teach(er)?(\/|$)/.test(hash) ? 'teacher' : null;
      if (S.user) {                                                       // чужие разделы не показываем: просто ведём на «свою» главную
        const role = S.user.role, home = V.home().slice(1);
        const ok = area === 'admin' ? role === 'admin' : area === 'teacher' ? (role !== 'student' && !/^\/teacher/.test(hash)) : /^\/(cabinet|courses|course\/|homework|lesson\/|hw\/|schedule|club|materials)/.test(hash) ? role === 'student' : true;
        if (!ok || hash === '/' || hash === '/login' || hash === '/register' || /^\/(teacher|admin)\/join$/.test(hash)) return V.go('#' + home);
      }
      for (const r of V.R) { const m = hash.match(r.re); if (m && (r.pub || S.user)) return await r.fn(m); }
      if (!S.user) {
        if (area === 'admin') return viewAuth('admin', /\/join$/.test(hash) ? 'join' : 'login');
        if (area === 'teacher') return viewAuth('teacher', /\/join$/.test(hash) ? 'join' : 'login');
        return viewAuth('student', hash === '/register' ? 'register' : 'login');
      }
      V.header(); V.notFound();
    } catch (e) {
      if (e.status === 401 || my !== seq) return;
      V.header(S.user ? 'cabinet' : undefined);
      app.innerHTML = `<div class="empty mt32"><b>Не получилось загрузить страницу.</b><br>${h(e.message)}<div class="mt16"><button class="btn pri" data-act="reload">Обновить</button></div><p class="mut2 mt16" style="font-size:14px">Если ошибка повторяется — напишите нам: voscaofficial0@gmail.com или по телефону +7 931 393-66-85.</p></div>`;
    }
  };
  window.addEventListener('hashchange', V.render);

  /* ── события ── */
  document.addEventListener('submit', async ev => {
    const f = ev.target.closest('form[data-form]'); if (!f) return;
    ev.preventDefault();
    const kind = f.dataset.form, fn = V.F[kind]; if (!fn) return;
    const fd = {}; new FormData(f).forEach((v, k) => { fd[k] = v; });
    const btns = [...f.querySelectorAll('button[type=submit]')]; btns.forEach(b => { b.disabled = true; });
    try { await fn(fd, f, ev); }
    catch (e) { const id = f.dataset.err || 'ferr'; if (document.getElementById(id)) V.showErr(id, e.message); else toast(e.message); }
    finally { btns.forEach(b => { b.disabled = false; }); }
  });
  document.addEventListener('click', async ev => {
    const sayEl = ev.target.closest('[data-say]');
    if (sayEl) { say(sayEl.dataset.say, sayEl.classList.contains('sp') ? sayEl : null); return; }
    const slowEl = ev.target.closest('[data-slow]');
    if (slowEl) { saySlow(slowEl.dataset.slow, slowEl); return; }
    const bp = document.getElementById('bellPanel');
    if (bp && !bp.classList.contains('hide') && !ev.target.closest('#bellPanel') && !ev.target.closest('.bell')) bp.classList.add('hide');
    const bk = ev.target.closest('.mback'); if (bk && ev.target === bk && !bk.dataset.sticky) { V.closeModal(); return; }
    const el = ev.target.closest('[data-act]'); if (!el) return;
    const fn = V.A[el.dataset.act]; if (!fn) return;
    try { await fn(el, ev); } catch (e) { toast(e.message); }
  });
  document.addEventListener('change', async ev => { const el = ev.target.closest('[data-chg]'); if (!el) return; const fn = V.A[el.dataset.chg]; if (!fn) return; try { await fn(el, ev); } catch (e) { toast(e.message); } });
  document.addEventListener('keydown', ev => { if (ev.key === 'Escape') { const b = document.querySelector('.mback'); if (b && !b.dataset.sticky) V.closeModal(); } });

  /* живой пересчёт «через N мин» и кнопок «Подключиться» */
  V.refreshLive = () => {
    const t = V.now();
    document.querySelectorAll('[data-cd]').forEach(el => { const s = +el.dataset.cd, e = +el.dataset.end || s + 3600e3; el.textContent = t > e ? 'завершён' : V.cd(s - t); });
    document.querySelectorAll('[data-join]').forEach(el => {
      const s = +el.dataset.join, e = +el.dataset.end, on = t >= s - (+el.dataset.before || 600e3) && t <= e + 30 * 60e3;
      if (el.tagName === 'A') el.classList.toggle('hide', !on); else el.classList.toggle('hide', on);
    });
  };
  setInterval(() => V.refreshLive(), 15000);
  TrMode.apply(); Speech.init(); VoscaI18n.init();
})();
