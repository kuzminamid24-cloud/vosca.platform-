/* Vosca · клиент: админка */
(() => {
  'use strict';
  const V = window.V, S = V.S, app = V.app, h = V.h, api = V.api, plural = V.plural;
  const guard = () => { if (!S.user || S.user.role !== 'admin') { V.header('cabinet'); V.notFound('Нет доступа'); return false; } return true; };
  const TABS = [['users', 'Ученики'], ['codes', 'Коды для учеников'], ['teachers', 'Преподаватели'], ['materials', 'Материалы'], ['invites', 'Приглашения для команды'], ['schedule', 'Расписание'], ['club', 'Разговорный клуб'], ['content', 'Контент'], ['legal', 'Документы'], ['mail', 'Письма']];
  const tabs = a => `<div class="tabs">${TABS.filter(t => t[0] !== 'legal' || S.cfg.legal !== false).map(t => `<a href="#/admin${t[0] === 'users' ? '' : '/' + t[0]}" class="${a === t[0] ? 'on' : ''}">${t[1]}</a>`).join('')}</div>`;
  V.adminTabs = tabs;
  let USERS = null;
  /* выбор языков: чипы-чекбоксы; список языков школы приходит с сервера (d.courses) */
  const langBoxes = (courses, sel) => `<div class="langs">${courses.map(c => `<label class="lg"><input type="checkbox" name="langs" value="${h(c.id)}" ${(sel || []).includes(c.id) ? 'checked' : ''}><span>${c.flag} ${h(c.title)}</span></label>`).join('')}</div>`;
  const pickLangs = f => [...f.querySelectorAll('input[name=langs]:checked')].map(i => i.value);
  const usersData = async force => (USERS && !force) ? USERS : (USERS = await api('GET', '/api/admin/users'));
  const stat = (n, l) => `<div class="meta"><b>${n}</b><span>${l}</span></div>`;

  /* ── ученики ── */
  V.route(/^\/admin$/, async () => {
    if (!guard()) return; V.loading(); await V.loadOverview(); V.header('admin');
    const d = await usersData(true), t = d.totals;
    app.innerHTML = `<section class="phero"><span class="pill">Админка</span><h1>Ученики</h1><div class="pstats">${stat(t.users, 'учеников')}${stat(t.teachers, 'преподавателей')}${stat(t.active7, 'активны за 7 дней')}${stat(t.passed, 'уроков пройдено')}${stat(t.hwDone, 'ДЗ сдано')}</div></section>${tabs('users')}
      <div class="row mt16"><input class="srch" id="usrch" style="flex:1;min-width:220px" placeholder="Поиск по имени или email" autocomplete="off"><select class="sel" id="ulang" style="width:auto"><option value="">Все языки</option>${d.courses.map(c => `<option value="${h(c.id)}">${c.flag} ${h(c.title)}</option>`).join('')}</select><a class="btn pri" href="#/admin/codes">＋ Код для нового ученика</a></div>
      <div class="atw mt16"><table class="at"><thead><tr><th>Пользователь</th><th>Языки</th><th>Уроков</th><th>ДЗ</th><th>Был(а)</th><th>Регистрация</th></tr></thead><tbody id="utb"></tbody></table></div>`;
    paintUsers('');
  });
  function paintUsers(f) {
    const tb = document.getElementById('utb'); if (!tb) return; f = f.trim().toLowerCase();
    const lg = (document.getElementById('ulang') || {}).value || '', CN = Object.fromEntries(USERS.courses.map(c => [c.id, c]));
    const rows = USERS.users.filter(u => (!f || u.name.toLowerCase().includes(f) || u.email.includes(f)) && (!lg || u.courses.includes(lg) || (u.langs || []).includes(lg)));
    tb.innerHTML = rows.map(u => `<tr class="cl" data-act="user" data-id="${u.id}"><td class="unm"><b>${h(u.name)}${u.role !== 'student' ? ` <span class="bdg go">${u.role === 'admin' ? 'admin' : 'преподаватель'}</span>` : ''}</b><span>${h(u.email)}</span></td>
      <td>${u.role === 'teacher' ? ((u.langs || []).length ? u.langs : Object.keys(CN)).map(c => `<span class="bdg">${(CN[c] || {}).flag || ''} ${h((CN[c] || {}).title || c)}</span>`).join(' ') : u.courses.length ? u.courses.map(c => `<span class="bdg">${(CN[c] || {}).flag || ''} ${h((CN[c] || {}).title || c)}</span>`).join(' ') : '<span class="bdg lock">нет доступа</span>'}</td><td>${u.passed}</td><td>${u.hw_done}${u.hw_open ? ` <span class="mut">(+${u.hw_open})</span>` : ''}</td><td>${V.fago(u.last_login)}</td><td>${V.fdate(u.created_at)}</td></tr>`).join('') || '<tr><td colspan="7" class="mut" style="text-align:center;padding:26px">Ничего не найдено</td></tr>';
  }
  document.addEventListener('input', ev => { if (ev.target.id === 'usrch') paintUsers(ev.target.value); });
  document.addEventListener('change', ev => { if (ev.target.id === 'ulang') paintUsers((document.getElementById('usrch') || {}).value || ''); });
  V.act('user', el => V.go('#/admin/user/' + el.dataset.id));

  /* ── карточка пользователя ── */
  let UD = null;
  V.route(/^\/admin\/user\/(\d+)$/, async m => {
    if (!guard()) return; V.loading(); V.header('admin');
    let d; try { d = UD = await api('GET', '/api/admin/users/' + m[1]); } catch (e) { return V.notFound(e.message); }
    const ud = await usersData(), isS = d.user.role === 'student', allC = d.courses, ready = allC.filter(c => c.ready), uid = d.user.id;
    const enr = Object.fromEntries(d.enroll.map(e => [e.course, e])), asg = Object.fromEntries(d.assign.map(a => [a.course, a.teacher]));
    app.innerHTML = `<a class="back" href="#/admin">← Все пользователи</a>
      <section class="phero" style="padding-top:12px"><h1>${h(d.user.name)} ${d.user.role !== 'student' ? `<span class="bdg go">${d.user.role}</span>` : ''}</h1><p>${h(d.user.email)} · пояс ${h(d.user.tz)} · регистрация ${V.fdate(d.created_at)} · заходил(а) ${V.fago(d.last_login)}</p>
      <div class="pstats">${stat(d.stats.lessonsPassed, 'уроков')}${stat(d.stats.hwDone, 'ДЗ')}${stat(d.stats.xp, 'XP')}${stat(d.stats.minutes, 'минут')}${stat(d.streak.days, 'серия, дней')}</div></section>
      <div class="sect"><h2>Доступ к языкам</h2>${isS ? '<p class="mut2" style="font-size:14px;margin-bottom:10px">Ученик видит только те языки, которые ему открыты. Откройте нужный язык здесь или выдайте код на странице «Коды доступа».</p>' : ''}<div class="cols2">${allC.map(c => {
        const e = enr[c.id], st = !e ? '<span class="bdg lock">нет доступа</span>' : e.active ? `<span class="bdg ok">открыт${e.expires ? ' до ' + V.fdate(e.expires) : ' бессрочно'}</span>` : `<span class="bdg bad">истёк ${V.fdate(e.expires)}</span>`;
        return `<div class="card"><h3>${c.flag} ${h(c.title)} ${st}</h3>${c.ready ? '' : '<div class="mut" style="font-size:12.5px;margin-top:4px">Уроков в платформе пока нет — занятия идут с преподавателем</div>'}${e ? `<div class="mut" style="font-size:12.5px;margin-top:4px">Источник: ${h({ admin: 'выдан вручную', code: 'по коду', auto: 'автоматически' }[e.source] || e.source)} · с ${V.fdate(e.since)}</div>` : ''}
        <form data-form="enroll" data-id="${uid}" data-course="${c.id}" data-err="eerr-${c.id}" class="row mt16"><select name="days" class="sel" style="flex:1;min-width:150px"><option value="">Без срока</option><option value="30">30 дней</option><option value="90">90 дней</option><option value="180">180 дней</option><option value="365">365 дней</option></select><button class="btn pri sm" type="submit">${e && e.active ? 'Продлить' : 'Открыть'}</button>${e ? `<button type="button" class="btn sm gho" data-act="unenroll" data-id="${uid}" data-course="${c.id}">Закрыть</button>` : ''}</form>
        <div class="ferr hide" id="eerr-${c.id}"></div>
        ${isS ? `<label class="fld"><span>Преподаватель по курсу</span><select class="sel" data-chg="assign" data-id="${uid}" data-course="${c.id}"><option value="">— не назначен —</option>${ud.teachers.filter(t => !t.langs.length || t.langs.includes(c.id)).map(t => `<option value="${t.id}" ${asg[c.id] === t.id ? 'selected' : ''}>${h(t.name)}</option>`).join('')}</select></label>` : ''}</div>`;
      }).join('')}</div></div>
      ${isS ? `<div class="sect" id="clubSect"><h2>Разговорный клуб</h2>${V.adminClubBlock(uid, d.club, d.clubHist)}</div>` : ''}
      ${isS ? `<div class="sect"><div class="row"><button class="btn pri" data-act="admsess">🎥 Назначить занятие</button></div></div>` : ''}
      ${ready.filter(c => c.enrolled).map(c => `<div class="sect"><h2>${c.flag} ${h(c.title)} <small>${c.passed}/${c.total}</small></h2><div class="atw"><table class="at"><thead><tr><th>Урок</th><th>Статус</th><th>Точность</th><th>ДЗ</th><th></th></tr></thead><tbody>${c.lessons.map(l => `<tr><td><b>${l.index + 1}. ${h(l.title)}</b></td>
        <td>${l.status === 'passed' ? `<span class="bdg ok">пройден ${V.fdate(l.passedAt)}${l.manual ? ' · вручную' : ''}</span>` : l.status === 'open' ? '<span class="bdg go">открыт</span>' : '<span class="bdg lock">закрыт</span>'}</td>
        <td>${l.attempts || l.accuracy ? `${l.accuracy}% (лучш. ${l.best}%)` : '—'}</td><td>${l.hw ? (l.hw.status === 'done' ? `<span class="bdg ok">${l.hw.best}%</span>` : '<span class="bdg hw">ждёт</span>') : '—'}</td>
        <td style="white-space:nowrap">${l.status !== 'passed' ? `<button class="btn sm" data-act="apass" data-id="${uid}" data-lesson="${l.key}">Засчитать до этого урока</button>` : ''} ${l.status !== 'locked' && (l.status === 'passed' || l.done) ? `<button class="btn sm gho" data-act="areset" data-id="${uid}" data-lesson="${l.key}">Сбросить с этого</button>` : ''}</td></tr>`).join('')}</tbody></table></div></div>`).join('')}
      ${S.cfg.legal === false ? '' : `<div class="sect"><h2>Согласия</h2><div class="atw"><table class="at"><thead><tr><th>Документ</th><th>Статус</th><th>Редакция</th><th>Когда</th></tr></thead><tbody>${d.consents.map(c => `<tr><td>${h(c.title)}</td><td>${c.accepted ? '<span class="bdg ok">дано</span>' : '<span class="bdg lock">нет</span>'}</td><td>${h(c.version || '—')}</td><td>${c.at ? V.fdate(c.at) : '—'}</td></tr>`).join('')}</tbody></table></div></div>`}
      ${d.user.role === 'teacher' ? `<div class="sect"><h2>Языки преподавателя</h2><form class="card" data-form="tlangs" data-id="${uid}" data-err="lerr"><p class="mut2" style="font-size:14px">Преподаватель видит и ведёт только учеников этих языков; ученики видят его только в своих языках.${(d.user.langs || []).length ? '' : ' <b>Сейчас языки не заданы — он считается преподавателем всех языков.</b>'}</p>${langBoxes(allC, d.user.langs)}<div class="ferr hide" id="lerr"></div><button class="btn pri sm mt16" type="submit">Сохранить языки</button></form></div>` : ''}
      ${!isS && d.profile ? `<div class="sect"><h2>Публичный профиль преподавателя</h2>${V.tprofHTML(d.profile, { admin: true, withUrl: true })}</div>` : ''}
      <div class="sect"><h2>Управление</h2><div class="cols2">
        ${d.user.role !== 'admin' ? `<div class="card"><h3>Роль</h3><div class="row mt8"><select id="roleSel" class="sel" style="flex:1"><option value="student" ${isS ? 'selected' : ''}>Ученик</option><option value="teacher" ${d.user.role === 'teacher' ? 'selected' : ''}>Преподаватель</option></select><button class="btn sm pri" data-act="setrole" data-id="${uid}">Сохранить</button></div></div>` : ''}
        <form class="card" data-form="admpw" data-id="${uid}" data-err="aperr"><h3>Новый пароль</h3><p class="mut2" style="font-size:13.5px">Для тех, кто забыл пароль. Все сессии завершатся.</p><label class="fld"><span>Пароль (от 8 символов)</span><input name="password" type="text" autocomplete="off" required></label><div class="fok hide" id="apok"></div><div class="ferr hide" id="aperr"></div><button class="btn pri sm mt16" type="submit">Установить</button></form>
        ${d.user.role !== 'admin' ? `<div class="card danger"><h3>Удалить пользователя</h3><p class="mut2" style="font-size:13.5px;margin:6px 0 12px">Все данные удаляются безвозвратно.${S.cfg.legal === false ? '' : ' Журнал согласий сохраняется в обезличенном виде.'}</p><button class="btn dng sm" data-act="deluser" data-id="${uid}">Удалить</button></div>` : ''}
      </div></div>`;
  });
  const refreshUser = id => { USERS = null; V.render(); };
  V.form('enroll', async (fd, f) => { await api('POST', `/api/admin/users/${f.dataset.id}/enroll`, { course: f.dataset.course, days: fd.days ? +fd.days : 0 }); toast('Доступ открыт, ученику отправлено письмо'); refreshUser(); });
  V.act('unenroll', async el => { if (!confirm('Закрыть доступ к курсу? Прогресс сохранится.')) return; await api('POST', `/api/admin/users/${el.dataset.id}/enroll`, { course: el.dataset.course, on: false }); toast('Доступ закрыт'); refreshUser(); });
  V.act('assign', async el => { await api('POST', `/api/admin/users/${el.dataset.id}/assign`, { course: el.dataset.course, teacher: el.value ? +el.value : 0 }); toast(el.value ? 'Преподаватель назначен' : 'Назначение снято'); USERS = null; });
  V.act('setrole', async el => { await api('POST', `/api/admin/users/${el.dataset.id}/role`, { role: document.getElementById('roleSel').value }); toast('Роль изменена'); refreshUser(); });
  V.act('apass', async el => { if (!confirm('Засчитать этот и все предыдущие уроки курса? Откроется следующий урок и появятся ДЗ.')) return; await api('POST', `/api/admin/users/${el.dataset.id}/pass`, { lesson: el.dataset.lesson }); toast('Готово'); V.render(); });
  V.act('areset', async el => { if (!confirm('Сбросить прогресс и ДЗ этого и всех следующих уроков?')) return; await api('POST', `/api/admin/users/${el.dataset.id}/reset`, { lesson: el.dataset.lesson }); toast('Сброшено'); V.render(); });
  V.act('deluser', el => V.confirm('Удалить пользователя?', 'Это действие необратимо: прогресс, расписание и данные будут удалены.', 'Да, удалить', 'deluser2', { id: el.dataset.id }));
  V.act('deluser2', async el => { await api('POST', `/api/admin/users/${el.dataset.id}/delete`, {}); V.closeModal(); toast('Пользователь удалён'); USERS = null; V.go('#/admin'); });
  V.form('admpw', async (fd, f) => { V.hideEl('aperr'); await api('POST', `/api/admin/users/${f.dataset.id}/password`, { password: fd.password }); f.reset(); V.okMsg('apok', 'Пароль установлен'); });
  V.act('admsess', () => {
    const d = UD, courses = d.courses.filter(c => c.ready && c.enrolled);
    if (!courses.length) return toast('Сначала откройте ученику курс');
    USERS_T().then(ud => {
      if (!ud.teachers.length) return toast('Сначала создайте преподавателя');
      const asg = Object.fromEntries(d.assign.map(a => [a.course, a.teacher]));
      V.sessionModal({ students: courses.map(c => ({ id: d.user.id, name: d.user.name, course: c.id, courseTitle: c.title })), teachers: ud.teachers, teacher: asg[courses[0].id] || ud.teachers[0].id, tz: V.tz() });
    });
  });
  const USERS_T = () => usersData();

  V.form('tlangs', async (fd, f) => { await api('POST', `/api/admin/users/${f.dataset.id}/langs`, { langs: pickLangs(f) }); USERS = null; toast('Языки сохранены'); V.render(); });

  /* ── преподаватели ── */
  V.route(/^\/admin\/teachers$/, async () => {
    if (!guard()) return; V.loading(); await V.loadOverview(); V.header('admin');
    const d = await usersData(true), ts = d.users.filter(u => u.role === 'teacher');
    app.innerHTML = `<section class="phero"><span class="pill">Админка</span><h1>Преподаватели</h1><p>Создайте аккаунт преподавателя, закрепите учеников в их карточках — и преподаватель сам назначает занятия.</p></section>${tabs('teachers')}
      <div class="notice mt16">💡 Не нужно придумывать пароль за человека: создайте <a href="#/admin/invites">приглашение</a> — преподаватель зарегистрируется сам по ссылке.</div>
      <div class="cols2 mt16"><div class="card"><h3>Преподаватели <span class="bdg">${ts.length}</span></h3>${ts.length ? ts.map(t => `<a class="trow" href="#/admin/user/${t.id}"><b>${h(t.name)}</b><span>${h(t.email)} · ${(t.langs || []).length ? t.langs.map(id => (d.courses.find(c => c.id === id) || {}).flag || id).join(' ') : 'все языки'}</span></a>`).join('') : '<p class="mut2 mt8">Пока нет. Создайте первого справа.</p>'}</div>
      <form class="card" data-form="newteacher" data-err="terr"><h3>Новый преподаватель</h3>
        <label class="fld"><span>Имя</span><input name="name" required maxlength="60"></label><label class="fld"><span>Email</span><input name="email" type="email" required></label>
        <div class="fld"><span>Какие языки ведёт</span>${langBoxes(d.courses, [])}</div>
        <label class="fld"><span>Пароль (от 8 символов)</span><input name="password" type="text" autocomplete="off" required></label>
        <label class="fld"><span>Ссылка на видеовстречу (https://)</span><input name="meeting_url" placeholder="https://meet.google.com/…"></label>
        <label class="fld"><span>Часовой пояс</span><select name="tz" class="sel">${V.tzOptions('Asia/Bangkok')}</select></label>
        <label class="fld"><span>О преподавателе (видят ученики)</span><input name="bio" maxlength="400"></label>
        <div class="ferr hide" id="terr"></div><button class="btn pri mt16" type="submit">Создать</button></form></div>`;
  });
  V.form('newteacher', async (fd, f) => { V.hideEl('terr'); await api('POST', '/api/admin/teachers', Object.assign({}, fd, { langs: pickLangs(f) })); toast('Преподаватель создан. Передайте ему email и пароль.'); USERS = null; V.render(); });

  /* ── расписание ── */
  V.route(/^\/admin\/schedule$/, async () => {
    if (!guard()) return; V.loading(); await V.loadOverview(); V.header('admin');
    const d = await api('GET', '/api/admin/sessions');
    const row = s => `<tr><td>${h(V.fDT(s.starts))}</td><td>${h(s.studentName)}</td><td>${h(s.teacher.name)}</td><td>${h(s.courseTitle)}</td><td><span class="bdg ${s.status === 'done' ? 'ok' : s.status === 'cancelled' ? 'bad' : 'go'}">${{ planned: 'в плане', done: 'проведён', cancelled: 'отменён' }[s.status]}</span>${s.declined ? ' <span class="bdg hw">ученик просит перенос</span>' : ''}</td><td>${s.status === 'planned' ? `<button class="btn sm gho" data-act="admcancel" data-id="${s.id}">Отменить</button>` : ''}</td></tr>`;
    app.innerHTML = `<section class="phero"><span class="pill">Админка</span><h1>Расписание занятий</h1><p>Время показано в вашем часовом поясе. Назначать занятия удобнее из карточки ученика.</p></section>${tabs('schedule')}
      <div class="sect"><h2>Предстоящие <small>${d.upcoming.length}</small></h2><div class="atw"><table class="at"><thead><tr><th>Когда</th><th>Ученик</th><th>Преподаватель</th><th>Курс</th><th>Статус</th><th></th></tr></thead><tbody>${d.upcoming.map(row).join('') || '<tr><td colspan="6" class="mut" style="text-align:center;padding:22px">Пусто</td></tr>'}</tbody></table></div></div>
      <div class="sect"><h2>Недавние</h2><div class="atw"><table class="at"><tbody>${d.recent.map(row).join('') || '<tr><td class="mut" style="text-align:center;padding:22px">Пусто</td></tr>'}</tbody></table></div></div>`;
  });
  V.act('admcancel', async el => { if (!confirm('Отменить занятие? Ученик получит письмо.')) return; await api('POST', `/api/teach/sessions/${el.dataset.id}/cancel`, {}); toast('Отменено'); V.render(); });

  /* ── коды доступа ── */
  const regLink = code => location.href.split('#')[0] + '#/register?code=' + code;
  V.route(/^\/admin\/codes$/, async () => {
    if (!guard()) return; V.loading(); await V.loadOverview(); V.header('admin');
    const d = await api('GET', '/api/admin/codes');
    app.innerHTML = `<section class="phero"><span class="pill">Админка</span><h1>Коды для учеников</h1><p>Продали курс — выберите язык, создайте код и отправьте ученику. Без кода зарегистрироваться нельзя: ученик вводит его при регистрации, и ему открывается именно этот язык — другие он не увидит. Код можно ограничить по сроку доступа и числу использований. Коды для преподавателей и администраторов — на странице <a href="#/admin/invites">«Приглашения для команды»</a>.</p></section>${tabs('codes')}
      <form class="card mt16" data-form="newcodes" data-err="cerr2"><h3>Создать коды</h3><div class="row mt8">
        <label class="fld" style="flex:1;min-width:160px"><span>Язык</span><select name="course" class="sel" data-chg="codelang">${d.courses.map(c => `<option value="${c.id}">${c.flag} ${h(c.title)}</option>`).join('')}<option value="club">🎤 Разговорный клуб (подписка)</option></select></label>
        <label class="fld" style="width:140px"><span>Срок, дней</span><input name="days" type="number" min="0" max="3650" value="365" title="0 — без ограничения"></label>
        <label class="fld" style="width:120px"><span>Сколько кодов</span><input name="count" type="number" min="1" max="100" value="1"></label>
        <label class="fld" style="width:140px"><span>Использований</span><input name="max" type="number" min="1" max="10000" value="1"></label>
        <label class="fld" style="flex:1;min-width:160px"><span>Заметка</span><input name="note" maxlength="100" placeholder="Кому / откуда заказ"></label></div>
        <div class="row mt8"><label class="fld" style="flex:1;min-width:220px"><span>Преподаватель (необязательно)</span><select name="teacher" class="sel" id="ctch"><option value="" data-langs="*">— без преподавателя —</option>${(d.teachers || []).map(t => `<option value="${t.id}" data-langs="${h((t.langs || []).join(','))}">${h(t.name)}</option>`).join('')}</select><small class="mut">Если выбрать — ученик сразу закрепится за этим преподавателем и появится у него в списке «Ученики».</small></label></div>
        <div class="ferr hide" id="cerr2"></div><button class="btn pri mt16" type="submit">Создать</button><div id="newc" class="mt16"></div></form>
      <div class="sect"><h2>Все коды <small>${d.codes.length}</small></h2><div class="atw"><table class="at"><thead><tr><th>Код</th><th>Курс</th><th>Преподаватель</th><th>Срок</th><th>Использовано</th><th>Заметка</th><th></th></tr></thead><tbody>${d.codes.map(c => `<tr><td><code class="cd">${h(c.code)}</code> <button class="btn sm gho" data-act="copyurl" data-url="${h(c.code)}">копировать</button></td><td>${h(c.courseTitle)}</td><td>${c.teacherName ? h(c.teacherName) : '<span class="mut">—</span>'}</td><td>${c.days ? c.days + ' дн.' : 'бессрочно'}</td><td>${c.used} / ${c.max}</td><td>${h(c.note || '')}</td><td>${!c.active ? '<span class="bdg lock">выключен</span>' : c.used >= c.max ? '<span class="bdg">использован</span>' : `<button class="btn sm gho" data-act="codeoff" data-code="${h(c.code)}">Выключить</button>`}</td></tr>`).join('') || '<tr><td colspan="6" class="mut" style="text-align:center;padding:22px">Кодов пока нет</td></tr>'}</tbody></table></div></div>`;
  });
  /* список преподавателей в форме кода — только те, кто ведёт выбранный язык */
  V.act('codelang', el => {
    const sel = document.getElementById('ctch'); if (!sel) return; const lang = el.value;
    [...sel.options].forEach(o => { const l = o.dataset.langs; const okk = l === '*' || lang === 'club' ? true : (!l || l.split(',').includes(lang)); o.hidden = o.disabled = !okk; });
    if (sel.selectedOptions[0] && sel.selectedOptions[0].disabled) sel.value = '';
    sel.closest('label').classList.toggle('hide', lang === 'club');
  });
  V.form('newcodes', async (fd, f) => {
    V.hideEl('cerr2'); const langName = (f.querySelector('select[name=course] option:checked') || {}).textContent || '';
    const r = await api('POST', '/api/admin/codes', { course: fd.course, days: +fd.days || 0, count: +fd.count, max: +fd.max, note: fd.note, teacher: fd.course === 'club' ? 0 : (+fd.teacher || 0) });
    document.getElementById('newc').innerHTML = `<div class="fok">Готово. Отправьте ученику код — или готовую ссылку, где код уже подставлен:${r.codes.map(c => `<div class="mt8"><code class="cd big">${h(c)}</code><br><span class="mut" style="word-break:break-all">${h(regLink(c))}</span> <button type="button" class="btn sm gho" data-act="regcopy" data-code="${h(c)}">Скопировать ссылку</button> <button type="button" class="btn sm" data-act="regmsg" data-code="${h(c)}" data-lang="${h(langName)}" data-days="${+fd.days || 0}">Скопировать сообщение ученику</button></div>`).join('')}</div>`; toast('Коды созданы');
    const list = await api('GET', '/api/admin/codes'); void list;
  });
  V.act('regcopy', el => V.copy(regLink(el.dataset.code)));
  /* готовое сообщение, которое можно сразу отправить ученику в мессенджер или на почту */
  V.act('regmsg', el => {
    const c = S.cfg.contacts || {}, days = +el.dataset.days, lang = el.dataset.lang.replace(/^\S+\s/, '');
    V.copy(`Здравствуйте! Ваш доступ к урокам Vosca готов 🎉\nЯзык: ${lang}${days ? `\nДоступ: ${days} дн. с момента регистрации` : ''}\nКод доступа: ${el.dataset.code}\n\nКак начать: откройте ${regLink(el.dataset.code)} — код уже подставлен, останется ввести имя, email и пароль.\n\nЕсли что-то не получится — напишите нам: ${c.email || ''}${c.phone ? ', телефон ' + c.phone : ''}.\n\nHello! Your Vosca access is ready. Language: ${lang}. Access code: ${el.dataset.code}. Sign up here: ${regLink(el.dataset.code)}`);
  });
  V.act('codeoff', async el => { await api('POST', `/api/admin/codes/${el.dataset.code}/off`, {}); toast('Код выключен'); V.render(); });

  /* ── приглашения для преподавателей и администраторов ── */
  const inviteLink = (role, code) => location.href.split('#')[0] + '#/' + (role === 'admin' ? 'admin' : 'teacher') + '/join?code=' + code;
  const INV_STATE = { active: ['go', 'действует'], used: ['ok', 'использовано'], expired: ['lock', 'истёк срок'], off: ['bad', 'выключено'] };
  V.route(/^\/admin\/invites$/, async () => {
    if (!guard()) return; V.loading(); await V.loadOverview(); V.header('admin');
    const d = await api('GET', '/api/admin/invites');
    app.innerHTML = `<section class="phero"><span class="pill">Админка</span><h1>Приглашения</h1><p>Так в команду попадают преподаватели и другие администраторы: вы создаёте код и отправляете человеку ссылку — он сам задаёт имя и пароль на странице входа для преподавателей. Ученикам эти коды не подходят: у них свой вход и свои коды — их создают на странице <a href="#/admin/codes">«Коды для учеников»</a>.</p></section>${tabs('invites')}
      <form class="card mt16" data-form="newinvites" data-err="ierr"><h3>Создать приглашение</h3><div class="row mt8">
        <label class="fld" style="flex:1;min-width:180px"><span>Кого приглашаем</span><select name="role" class="sel" data-chg="invrole"><option value="teacher">Преподавателя</option><option value="admin">Администратора (одноразово)</option></select></label>
        <label class="fld" style="width:150px"><span>Действует, дней</span><input name="days" type="number" min="1" max="90" value="14"></label>
        <label class="fld" style="width:120px"><span>Сколько кодов</span><input name="count" type="number" min="1" max="50" value="1"></label>
        <label class="fld" style="width:140px"><span>Использований</span><input name="max" type="number" min="1" max="100" value="1"></label>
        <label class="fld" style="flex:1;min-width:160px"><span>Заметка</span><input name="note" maxlength="100" placeholder="Кого приглашаете"></label></div>
        <div class="fld mt16" id="invLangs"><span>Какие языки будет вести преподаватель</span>${langBoxes(d.courses, [])}</div>
        <div class="ferr hide" id="ierr"></div><button class="btn pri mt16" type="submit">Создать</button><div id="newi" class="mt16"></div></form>
      <div class="sect"><h2>Все приглашения <small>${d.invites.length}</small></h2>${d.invites.length ? `<div class="atw"><table class="at"><thead><tr><th>Код</th><th>Кого</th><th>Языки</th><th>Статус</th><th>До</th><th>Кто вошёл</th><th>Заметка</th><th></th></tr></thead><tbody>${d.invites.map(c => { const st = INV_STATE[c.state] || ['', c.state]; return `<tr><td><code class="cd">${h(c.code)}</code></td><td>${c.role === 'admin' ? 'администратор' : 'преподаватель'}</td><td>${c.role === 'admin' ? '—' : (c.langs || []).map(h).join(', ') || 'все'}</td><td><span class="bdg ${st[0]}">${st[1]}</span> <span class="mut">${c.used}/${c.max}</span></td><td>${V.fdate(c.expires)}</td><td>${c.users.map(h).join(', ') || '<span class="mut">—</span>'}</td><td>${h(c.note || '')}</td><td>${c.state === 'active' ? `<button class="btn sm gho" data-act="invcopy" data-role="${c.role}" data-code="${h(c.code)}">Ссылка</button> <button class="btn sm gho" data-act="invoff" data-code="${h(c.code)}">Выключить</button>` : ''}</td></tr>`; }).join('')}</tbody></table></div>` : '<div class="empty">Пока нет приглашений</div>'}</div>`;
  });
  V.act('invrole', el => { const b = document.getElementById('invLangs'); if (b) b.classList.toggle('hide', el.value !== 'teacher'); });
  V.form('newinvites', async (fd, f) => {
    V.hideEl('ierr'); const r = await api('POST', '/api/admin/invites', { role: fd.role, days: +fd.days, count: +fd.count, max: +fd.max, note: fd.note, langs: fd.role === 'teacher' ? pickLangs(f) : [] });
    document.getElementById('newi').innerHTML = `<div class="fok">Готово. Отправьте человеку ссылку (или код — его вводят на странице регистрации):${r.codes.map(c => `<div class="mt8"><code class="cd big">${h(c)}</code><br><span class="mut" style="word-break:break-all">${h(inviteLink(fd.role, c))}</span> <button type="button" class="btn sm gho" data-act="invcopy" data-role="${h(fd.role)}" data-code="${h(c)}">Скопировать ссылку</button></div>`).join('')}</div>`; toast('Приглашения созданы');
  });
  V.act('invcopy', el => V.copy(inviteLink(el.dataset.role, el.dataset.code)));
  V.act('invoff', async el => { await api('POST', `/api/admin/invites/${el.dataset.code}/off`, {}); toast('Приглашение выключено'); V.render(); });

  /* ── письма ── */
  V.route(/^\/admin\/mail$/, async () => {
    if (!guard()) return; V.loading(); await V.loadOverview(); V.header('admin');
    const d = await api('GET', '/api/admin/outbox'), ST = { queued: ['go', 'в очереди'], sent: ['ok', 'отправлено'], logged: ['lock', 'только в журнале'], failed: ['bad', 'ошибка'] };
    app.innerHTML = `<section class="phero"><span class="pill">Админка</span><h1>Письма</h1><p>Напоминания об уроках, приглашения и уведомления. Здесь видно, что и когда ушло.</p></section>${tabs('mail')}
      ${V.demo ? '<div class="notice mt16">ℹ️ Демо: письма никуда не отправляются, но здесь видно, какие письма и кому ушли бы (приветствия, «назначен урок», напоминания за 24 часа и за 15 минут). Перемотайте время в панели внизу и обновите страницу.</div>' : d.smtp === 'smtp' ? '<div class="notice ok mt16">✉️ Почта подключена (SMTP): письма отправляются автоматически.</div>' : '<div class="notice mt16">⚠️ Почта не настроена (SMTP): письма только записываются в журнал и ученикам не уходят. Как подключить — в README, раздел «Почта».</div>'}
      <div class="atw mt16"><table class="at"><thead><tr><th>Когда</th><th>Кому</th><th>Тема</th><th>Статус</th></tr></thead><tbody>${d.items.map(m => `<tr><td>${V.fago(m.created)}</td><td>${h(m.to)}</td><td>${h(m.subject)}</td><td><span class="bdg ${ST[m.status][0]}">${ST[m.status][1]}</span>${m.error ? `<div class="mut" style="font-size:12px">${h(m.error)}</div>` : ''}</td></tr>`).join('') || '<tr><td colspan="4" class="mut" style="text-align:center;padding:22px">Писем пока нет</td></tr>'}</tbody></table></div>`;
  });

  /* ── юридические реквизиты ── */
  V.route(/^\/admin\/legal$/, async () => {
    if (!guard()) return; if (S.cfg.legal === false) return V.go('#/admin'); V.loading(); await V.loadOverview(); V.header('admin');
    const d = await api('GET', '/api/admin/settings');
    app.innerHTML = `<section class="phero"><span class="pill">Админка</span><h1>Документы и реквизиты</h1><p>Оферта, политика обработки данных и согласия формируются из шаблонов и ваших реквизитов. Заполните поля — они подставятся во все документы. Редакция документов: <b>${h(d.version)}</b>.</p></section>${tabs('legal')}
      <div class="notice mt16">⚖️ Шаблоны подготовлены с учётом 152-ФЗ, закона «О рекламе» и закона о защите прав потребителей, но это <b>не юридическая консультация</b>. Перед запуском покажите документы юристу.</div>
      ${d.missing.length ? `<div class="notice mt16">Не заполнено: <b>${d.missing.length}</b> из ${d.fields.length}. Пока реквизиты не заполнены, в документах будут подсвеченные пропуски.</div>` : '<div class="notice ok mt16">✅ Все реквизиты заполнены.</div>'}
      <form class="card mt16" data-form="legal" data-err="lerr"><div class="cols2">${d.fields.map(f => `<label class="fld"><span>${h(f.label)}</span><input name="${f.key}" value="${h(f.value)}" maxlength="300" class="${d.missing.includes(f.key) ? 'miss' : ''}"></label>`).join('')}</div>
        <div class="fok hide" id="lok"></div><div class="ferr hide" id="lerr"></div><div class="row mt16"><button class="btn pri" type="submit">Сохранить</button>
        ${['offer', 'privacy', 'consent-pd', 'consent-ads'].map(x => `<a class="btn sm gho" href="#/legal/${x}" target="_blank" rel="noopener">${{ offer: 'Оферта', privacy: 'Политика', 'consent-pd': 'Согласие ПД', 'consent-ads': 'Согласие на рекламу' }[x]}</a>`).join('')}</div></form>
      <div class="sect"><h2>Что нужно сделать вне платформы</h2><div class="card"><ul class="todo">
        <li><b>Хранить данные россиян в России</b> (ст. 18 ч. 5 152-ФЗ): разместите сервер платформы у хостера с дата-центром в РФ и укажите его в поле «Где хранятся данные».</li>
        <li><b>Уведомить Роскомнадзор</b> об обработке персональных данных (ст. 22 152-ФЗ) — через сайт pd.rkn.gov.ru, до начала обработки. Для ИП и самозанятых обычно достаточно подать уведомление один раз.</li>
        <li><b>Опубликовать политику</b> на сайте и по ссылке при регистрации — это уже сделано в платформе, проверьте также ссылку на лендинге.</li>
        <li><b>Рассылки только с согласия</b>: рекламное согласие отдельное и необязательное (ст. 18 закона «О рекламе»). Не отправляйте рекламу тем, кто не поставил галочку; служебные письма об уроках — отдельно.</li>
        <li><b>Передача данных за границу</b> (почта, видеосвязь, хостинг): если сервис за пределами РФ — укажите это в политике и убедитесь, что соблюдены требования ст. 12 152-ФЗ.</li>
        <li><b>Несовершеннолетние</b>: до 18 лет нужно согласие родителя или законного представителя — в форме регистрации это отдельная обязательная отметка.</li>
        <li><b>Платежи и возвраты</b>: условия оплаты и возврата (ст. 32 закона «О защите прав потребителей») указаны в оферте — проверьте их под вашу реальную модель.</li>
      </ul></div></div>`;
  });
  V.form('legal', async fd => { V.hideEl('lerr'); await api('POST', '/api/admin/settings', fd); toast('Реквизиты сохранены'); V.render(); });

  /* ── контент: курсы и загрузка уроков ── */
  let CAT = null, STAGE = null;
  V.route(/^\/admin\/content$/, async () => {
    if (!guard()) return; V.loading(); await V.loadOverview(); V.header('admin');
    const d = CAT = await api('GET', '/api/admin/catalog'); STAGE = null;
    app.innerHTML = `<section class="phero"><span class="pill">Админка</span><h1>Курсы и уроки</h1><p>Загрузите готовый HTML-урок — платформа сама прочитает название, число заданий и вопросы для домашки. Уроки попадают в выбранный курс.</p></section>${tabs('content')}
      ${V.demo ? '<div class="notice mt16">ℹ️ Демо: загруженные уроки сохраняются в этом браузере. Тот же HTML-файл потом загружается на сервер этой же кнопкой.</div>' : ''}
      <div class="card mt16"><h3>＋ Загрузить новый урок</h3>
        <p class="mut2" style="font-size:14px;margin:6px 0 12px">Файл урока, собранный нашим конструктором (HTML). Обычный HTML-файл без связи с платформой не подойдёт.</p>
        <div class="row"><input type="file" id="lessonFile" accept=".html,text/html"><button class="btn pri" data-act="stagefile">Прочитать урок</button></div><div id="stageBox" class="mt16"></div></div>
      ${d.courses.map(c => `<div class="sect"><h2>${c.flag} ${h(c.title)} <small>${c.ready ? 'опубликован' : 'не опубликован — добавьте первый урок'}</small> <button class="btn sm gho" data-act="editcourse" data-id="${c.id}">Изменить</button></h2>
        ${(c.modules || []).map(m => `<div class="mod"><h2 style="font-size:16px">${h(m.title)}</h2>${m.lessons.map((k, i) => { const l = d.lessons[k]; return `<div class="lrow open" style="padding:10px 16px"><div class="lnum" style="width:34px;height:34px;font-size:14px">${i + 1}</div><div class="ltx"><b>${h(l ? l.title : k)}</b><span class="lhint"><code>${h(k)}</code>${l ? ` · ${l.min} мин · ${l.tasks} заданий · ${l.questions} вопросов в банке ДЗ · ${(l.langs || ['ru']).map(x => `<span class="bdg ${x === 'en' ? 'go' : ''}">${x.toUpperCase()}</span>`).join(' ')}` : ' · файл не найден'}</span></div><div class="acts"><button class="btn sm gho" data-act="lmove" data-key="${k}" data-dir="-1" ${i === 0 ? 'disabled' : ''}>↑</button><button class="btn sm gho" data-act="lmove" data-key="${k}" data-dir="1" ${i === m.lessons.length - 1 ? 'disabled' : ''}>↓</button><a class="btn sm" href="#/lesson/${k}">Открыть</a><button class="btn sm gho" data-act="lrem" data-key="${k}">Убрать из курса</button></div></div>`; }).join('')}</div>`).join('') || '<div class="empty">В курсе пока нет уроков.</div>'}</div>`).join('')}
      <div class="sect"><h2>Новый курс (язык)</h2><form class="card" data-form="course" data-err="kerr"><div class="cols2">
        <label class="fld"><span>Код (латиницей, например en)</span><input name="id" required maxlength="20" pattern="[a-z0-9\\-]{2,20}"></label><label class="fld"><span>Название</span><input name="title" required maxlength="80" placeholder="Английский язык"></label>
        <label class="fld"><span>Название на языке курса</span><input name="native" maxlength="60" placeholder="English"></label><label class="fld"><span>Флаг-эмодзи</span><input name="flag" maxlength="8" value="🌍"></label>
        <label class="fld"><span>Описание</span><input name="about" maxlength="300"></label><label class="fld"><span>Ссылка «Купить» (https://)</span><input name="buyUrl" maxlength="300"></label></div>
        <div class="ferr hide" id="kerr"></div><button class="btn pri mt16" type="submit">Сохранить курс</button></form></div>`;
  });
  V.act('stagefile', async () => {
    const inp = document.getElementById('lessonFile'), box = document.getElementById('stageBox'); if (!inp.files[0]) return toast('Выберите файл урока');
    box.innerHTML = '<span class="mut">Читаем урок…</span>';
    try {
      const f = inp.files[0], html = await f.text(), r = await api('POST', '/api/admin/lessons/stage', { html });
      const meta = await new Promise((res, rej) => {
        const fr = document.createElement('iframe'); fr.className = 'hide'; if (V.demo) fr.srcdoc = r.html; else fr.src = '/staging/' + r.id; document.body.appendChild(fr);
        const done = (v, e) => { clearTimeout(tm); window.removeEventListener('message', on); fr.remove(); e ? rej(e) : res(v); };
        const on = ev => { if (ev.source !== fr.contentWindow || !ev.data || ev.data.source !== 'vosca-lesson') return; if (ev.data.type === 'ready') fr.contentWindow.postMessage({ source: 'vosca-host', type: 'getMeta' }, '*'); else if (ev.data.type === 'meta') ev.data.error ? done(null, new Error(ev.data.error)) : done(ev.data); };
        window.addEventListener('message', on); const tm = setTimeout(() => done(null, new Error('Урок не ответил за 10 секунд. Проверьте, что он собран конструктором Vosca.')), 10000);
        fr.addEventListener('load', () => setTimeout(() => { try { fr.contentWindow.postMessage({ source: 'vosca-host', type: 'getMeta' }, '*'); } catch (e) { } }, 300));
      });
      STAGE = { id: r.id, meta: meta.meta, bank: meta.bank };
      const key = f.name.replace(/\.html?$/i, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40);
      const existing = Object.keys(CAT.lessons), isEn = /<html[^>]*\blang=["']?en/i.test(html), baseKey = key.replace(/[-_.]en$/, '');
      box.innerHTML = `<div class="fok">✓ Прочитано: <b>${h(meta.meta.title)}</b> · ${meta.meta.min} мин · ${meta.meta.tasks} заданий · ${meta.bank.length} вопросов для ДЗ</div>${meta.bank.length ? '' : '<div class="notice mt8">В этом уроке нет вопросов-тестов, поэтому домашнее задание к нему создаваться не будет. Урок можно публиковать.</div>'}
        <form data-form="commit" data-err="xerr" class="mt16"><div class="cols2">
        <label class="fld"><span>Язык этого файла</span><select name="lang" class="sel" id="lSel"><option value="ru" ${isEn ? '' : 'selected'}>Русский — основная версия урока</option><option value="en" ${isEn ? 'selected' : ''}>English — перевод уже опубликованного урока</option></select></label>
        <label class="fld" id="kEnBox"><span>К какому уроку относится перевод</span><select name="keyEn" class="sel">${existing.map(k => `<option value="${h(k)}" ${k === baseKey ? 'selected' : ''}>${h(CAT.lessons[k].title)} (${h(k)})${CAT.lessons[k].langs && CAT.lessons[k].langs.includes('en') ? ' — EN уже есть, будет заменён' : ''}</option>`).join('')}</select></label>
        <label class="fld" id="kRuBox"><span>Ключ урока (латиница, уникальный)</span><input name="key" value="${h(key)}" required maxlength="40" pattern="[a-z0-9][a-z0-9\\-]{1,39}"></label>
        <label class="fld rubox"><span>Курс</span><select name="course" class="sel" id="cSel">${CAT.courses.map(c => `<option value="${c.id}">${h(c.title)}</option>`).join('')}</select></label>
        <label class="fld rubox"><span>Модуль (раздел) курса</span><select name="module" class="sel" id="mSel"></select></label>
        <label class="fld hide" id="mNew"><span>Название нового модуля</span><input name="moduleTitle" maxlength="80" placeholder="Например: Грамматика"></label></div>
        <div class="ferr hide" id="xerr"></div><button class="btn pri mt16" type="submit">Опубликовать урок</button> <span class="mut" style="font-size:13px">${existing.length ? 'Если ключ уже существует, файл урока будет заменён.' : ''}</span></form>`;
      fillModules(); langUi();
    } catch (e) { box.innerHTML = `<div class="ferr">${h(e.message)}</div>`; }
  });
  function langUi() {
    const l = document.getElementById('lSel'); if (!l) return; const en = l.value === 'en';
    document.getElementById('kEnBox').classList.toggle('hide', !en); document.getElementById('kRuBox').classList.toggle('hide', en);
    document.querySelectorAll('.rubox').forEach(e => e.classList.toggle('hide', en));
    const k = document.querySelector('#kRuBox input'); if (k) k.required = !en;
    if (en) document.getElementById('mNew').classList.add('hide'); else fillModules();
  }
  function fillModules() {
    const c = CAT.courses.find(x => x.id === document.getElementById('cSel').value), sel = document.getElementById('mSel');
    sel.innerHTML = (c.modules || []).map(m => `<option value="${h(m.id)}">${h(m.title)}</option>`).join('') + '<option value="__new">＋ Новый модуль…</option>';
    document.getElementById('mNew').classList.toggle('hide', sel.value !== '__new');
  }
  document.addEventListener('change', ev => { if (ev.target.id === 'lSel') langUi(); if (ev.target.id === 'cSel') fillModules(); if (ev.target.id === 'mSel') document.getElementById('mNew').classList.toggle('hide', ev.target.value !== '__new'); });
  V.form('commit', async fd => {
    V.hideEl('xerr'); if (!STAGE) throw new Error('Сначала загрузите урок');
    const mod = fd.module === '__new' ? (fd.moduleTitle || 'new').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'new' : fd.module;
    if (fd.lang === 'en') { await api('POST', '/api/admin/lessons/commit', { stage: STAGE.id, key: fd.keyEn, lang: 'en', meta: STAGE.meta, bank: STAGE.bank }); toast('Английская версия добавлена 🇬🇧'); burst(80); V.render(); return; }
    await api('POST', '/api/admin/lessons/commit', { stage: STAGE.id, key: fd.key, course: fd.course, module: mod, moduleTitle: fd.moduleTitle || '', meta: STAGE.meta, bank: STAGE.bank });
    toast('Урок опубликован! 🎉'); burst(120); V.render();
  });
  V.act('lmove', async el => { await api('POST', '/api/admin/lessons/move', { key: el.dataset.key, dir: +el.dataset.dir }); V.render(); });
  V.act('lrem', el => V.confirm('Убрать урок из курса?', 'Файл останется на сервере, но ученики его больше не увидят. Прогресс сохранится.', 'Убрать', 'lrem2', { key: el.dataset.key }));
  V.act('lrem2', async el => { await api('POST', '/api/admin/lessons/remove', { key: el.dataset.key }); V.closeModal(); toast('Убрано'); V.render(); });
  V.act('editcourse', el => {
    const c = CAT.courses.find(x => x.id === el.dataset.id);
    V.modal(`<h2>${h(c.title)}</h2><form data-form="course" data-err="kerr2" style="text-align:left"><input type="hidden" name="id" value="${h(c.id)}">
      <label class="fld"><span>Название</span><input name="title" value="${h(c.title)}" required></label><label class="fld"><span>Название на языке курса</span><input name="native" value="${h(c.native || '')}"></label><label class="fld"><span>Флаг</span><input name="flag" value="${h(c.flag || '')}"></label>
      <label class="fld"><span>Описание</span><input name="about" value="${h(c.about || '')}"></label><label class="fld"><span>Ссылка «Купить» (https://)</span><input name="buyUrl" value="${h(c.buyUrl || '')}"></label>
      <div class="ferr hide" id="kerr2"></div><div class="acts"><button class="btn pri" type="submit">Сохранить</button><button type="button" class="btn gho" data-act="closemodal">Закрыть</button></div></form>`);
  });
  V.form('course', async fd => { await api('POST', '/api/admin/courses', fd); V.closeModal(); toast('Курс сохранён'); V.render(); });
})();
