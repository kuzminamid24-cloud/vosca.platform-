/* Vosca · запуск */
(() => { 'use strict'; Promise.resolve(window.DEMO_READY).then(() => window.V.render()); })();
