/* Vosca · клиент: профили преподавателей, Разговорный клуб (ученик, преподаватель, админ) */
(() => {
  'use strict';
  const V = window.V, S = V.S, app = V.app, h = V.h, api = V.api, plural = V.plural;
  const hdr = V.header;

  /* ── общие мелочи ── */
  const longDate = (ts, tz) => { try { return new Intl.DateTimeFormat(VoscaI18n.locale(), { timeZone: tz || V.tz(), day: 'numeric', month: 'long', year: 'numeric' }).format(ts); } catch (e) { return new Date(ts).toLocaleDateString(); } };
  V.longDate = longDate;
  /* аватар: фото или цветной кружок с буквой */
  V.avatar = (t, cls) => t.photo
    ? `<img class="tav ${cls || ''}" src="${h(t.photo)}" alt="" loading="lazy">`
    : `<div class="tav ini ${cls || ''}" style="--h:${(t.id * 47) % 360}">${h((t.name || '?').trim()[0] || '?')}</div>`;
  const facts = t => [t.teaches && ['Преподаёт', t.teaches], t.speaks && ['Говорит на', t.speaks], t.years && ['Опыт', t.years + ' ' + plural(t.years, ['год', 'года', 'лет'])], t.country && ['Страна', t.country]].filter(Boolean);
  const factsHtml = t => facts(t).map(f => `<div class="tfact"><small>${f[0]}</small><b>${h(f[1])}</b></div>`).join('');
  const dayGroups = list => { const g = []; list.forEach(s => { const k = V.dayKey(s.starts), last = g[g.length - 1]; if (last && last.k === k) last.items.push(s); else g.push({ k, ts: s.starts, items: [s] }); }); return g; };

  /* ───────────── преподаватели: список и страница ───────────── */
  V.route(/^\/teachers$/, async () => {
    V.loading(); await V.loadOverview(); hdr('teachers');
    const d = await api('GET', '/api/teachers');
    app.innerHTML = `<section class="phero"><span class="pill"><span class="dot"></span> Команда</span><h1>Наши преподаватели</h1>
      <p>Познакомьтесь с теми, кто учит в Vosca: опыт, языки и несколько слов о себе. Нажмите на карточку, чтобы узнать больше.</p></section>
      <div class="tgrid">${d.teachers.length ? d.teachers.map(t => `<a class="card tc2" href="#/teachers/${t.id}">${V.avatar(t, 'lg')}<div class="tc2b"><b>${h(t.name)}</b>${t.mine ? ' <span class="bdg go">Ваш преподаватель</span>' : ''}
        <div class="tc2h">${h(t.headline || t.teaches || '')}</div><div class="tc2m">${[t.speaks && '🗣 ' + h(t.speaks), t.years && '⭐ ' + t.years + ' ' + plural(t.years, ['год', 'года', 'лет'])].filter(Boolean).join(' · ')}</div></div></a>`).join('')
        : '<div class="empty">Профили преподавателей скоро появятся.</div>'}</div>`;
  });
  V.route(/^\/teachers\/(\d+)$/, async m => {
    V.loading(); await V.loadOverview(); hdr('teachers');
    let t; try { t = (await api('GET', '/api/teachers/' + m[1])).teacher; } catch (e) { return V.notFound(e.message); }
    const own = S.user && S.user.id === t.id;
    app.innerHTML = `<a class="back" href="#/teachers">← Все преподаватели</a>
      <section class="card tprof">${V.avatar(t, 'xxl')}<div class="tprof-b"><h1>${h(t.name)}</h1>${t.headline ? `<div class="tprof-h">${h(t.headline)}</div>` : ''}
        ${t.mine ? '<span class="bdg go">Ваш преподаватель</span>' : ''}<div class="tfacts">${factsHtml(t)}</div>
        ${own ? '<div class="mt16"><a class="btn sm" href="#/profile">Редактировать мой профиль</a></div>' : ''}</div></section>
      ${t.bio ? `<div class="sect"><h2>О преподавателе</h2><div class="card"><p class="tbio">${h(t.bio)}</p></div></div>` : (own ? '<div class="notice mt16">Вы ещё не рассказали о себе. <a href="#/profile">Заполнить профиль</a></div>' : '')}
      ${S.user.role === 'student' ? `<div class="sect"><button class="btn pri" data-act="reqnew" data-teacher="${t.id}">🙋 Запросить урок у этого преподавателя</button></div>` : ''}
      ${t.video ? `<div class="sect"><a class="btn pri" href="${h(t.video)}" target="_blank" rel="noopener noreferrer">▶ Видео-знакомство</a></div>` : ''}
      ${t.club.length ? `<div class="sect"><h2>Ближайшие занятия Разговорного клуба</h2>${t.club.map(s => `<div class="sess"><div class="tm"><b>${V.fTime(s.starts)}</b><small>${h(V.fDayShort(s.starts))}</small></div><div class="si"><b>${h(s.title)}</b><span>${h(s.lang)}</span></div>${S.user.role === 'student' ? '<div class="sa"><a class="btn sm" href="#/club">Записаться</a></div>' : ''}</div>`).join('')}</div>` : ''}`;
  });

  /* ───────────── редактор профиля (преподаватель — свой, админ — любой) ───────────── */
  V.tprofHTML = (p, o) => {
    o = o || {};
    return `<form class="card" data-form="tprof" data-id="${p.id}" data-err="tperr${p.id}" data-url="${o.withUrl ? 1 : ''}"><h3>Публичный профиль</h3>
      <p class="mut2" style="font-size:13.5px;margin:6px 0 14px">Это увидят ученики: фото, имя и рассказ о себе. Можно написать на двух языках — ученик увидит текст на языке своего интерфейса.</p>
      <div class="tphoto">${V.avatar(p, 'lg')}<div><div class="row"><label class="btn sm pri" style="cursor:pointer">Загрузить фото<input type="file" accept="image/jpeg,image/png,image/webp" hidden data-chg="tphoto" data-id="${p.id}"></label>${p.photo ? `<button type="button" class="btn sm gho" data-act="tphotodel" data-id="${p.id}">Убрать</button>` : ''}</div>
        <small class="mut" style="display:block;margin-top:6px">Лучше квадратное фото лица. Размер уменьшится автоматически.</small></div></div>
      <label class="fld"><span>Имя, как его видят ученики</span><input name="name" value="${h(p.name)}" maxlength="60" required></label>
      <div class="dbl"><label class="fld"><span>Коротко о вас (русский)</span><input name="headline" value="${h(p.headline)}" maxlength="90" placeholder="Например: Английский и разговорная практика"></label>
        <label class="fld"><span>Short tagline (English)</span><input name="headline_en" value="${h(p.headline_en)}" maxlength="90" placeholder="e.g. English & speaking practice"></label></div>
      <label class="fld"><span>О себе (русский)</span><textarea name="bio" class="ta" rows="5" maxlength="1200" placeholder="Опыт, как проходят занятия, чем вы увлечены">${h(p.bio)}</textarea></label>
      <label class="fld"><span>About you (English)</span><textarea name="bio_en" class="ta" rows="5" maxlength="1200" placeholder="Experience, how your classes go, what you enjoy">${h(p.bio_en)}</textarea></label>
      <div class="dbl"><label class="fld"><span>Преподаю</span><input name="teaches" value="${h(p.teaches)}" maxlength="120" placeholder="English, Thai"></label>
        <label class="fld"><span>Говорю на</span><input name="speaks" value="${h(p.speaks)}" maxlength="120" placeholder="English, Thai, Russian"></label></div>
      <div class="dbl"><label class="fld"><span>Опыт, лет</span><input name="years" type="number" min="0" max="60" value="${p.years || ''}"></label>
        <label class="fld"><span>Страна</span><input name="country" value="${h(p.country)}" maxlength="60"></label></div>
      <label class="fld"><span>Ссылка на видео-знакомство (https://, необязательно)</span><input name="video" value="${h(p.video)}" maxlength="300" placeholder="https://youtu.be/…"></label>
      ${o.withUrl ? `<label class="fld"><span>Ссылка на видеовстречу (https://)</span><input name="meeting_url" value="${h(p.meeting_url || '')}" maxlength="300"></label>` : ''}
      ${o.admin ? `<label class="ck mt16"><input type="checkbox" name="hidden" ${p.hidden ? 'checked' : ''}><span>Скрыть профиль от учеников (не показывать в списке преподавателей)</span></label>` : ''}
      <div class="fok hide" id="tpok${p.id}"></div><div class="ferr hide" id="tperr${p.id}"></div>
      <div class="row mt16"><button class="btn pri" type="submit">Сохранить профиль</button><a class="btn gho" href="#/teachers/${p.id}">Как это видят ученики →</a></div></form>`;
  };
  V.form('tprof', async (fd, f) => {
    const id = +f.dataset.id, body = { name: fd.name, headline: fd.headline, headline_en: fd.headline_en, bio: fd.bio, bio_en: fd.bio_en, teaches: fd.teaches, speaks: fd.speaks, years: +fd.years || 0, country: fd.country, video: (fd.video || '').trim() };
    if (S.user.id !== id) body.teacher = id;
    if ('hidden' in fd || f.querySelector('[name=hidden]')) body.hidden = !!fd.hidden;
    await api('POST', '/api/teach/profile', body);
    if (f.dataset.url && S.user.role === 'admin') await api('POST', `/api/admin/users/${id}/profile`, { meeting_url: (fd.meeting_url || '').trim() });
    if (S.user.id === id) { S.user.name = body.name; hdr(S.user.role === 'admin' ? 'admin' : 'profile'); }
    V.okMsg('tpok' + id, 'Профиль сохранён'); toast('Профиль сохранён');
  });
  /* фото: уменьшаем в браузере до 480 px и сжимаем в JPEG, чтобы файл был лёгким */
  const shrink = file => new Promise((res, rej) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      const side = Math.min(img.width, img.height), sx = (img.width - side) / 2, sy = (img.height - side) / 2;      // по центру, квадрат
      for (const [size, q] of [[480, .86], [480, .72], [360, .72], [280, .6]]) {
        const c = document.createElement('canvas'); c.width = c.height = Math.min(size, side); const x = c.getContext('2d');
        x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, sx, sy, side, side, 0, 0, c.width, c.height);
        const d = c.toDataURL('image/jpeg', q); if (d.length * 0.75 < 190 * 1024) return res(d);
      }
      rej(new Error('Не удалось уменьшить фото — выберите другое'));
    };
    img.onerror = () => { URL.revokeObjectURL(url); rej(new Error('Не удалось прочитать изображение')); };
    img.src = url;
  });
  V.act('tphoto', async el => {
    const f = el.files && el.files[0]; if (!f) return;
    if (!/^image\/(jpeg|png|webp)$/.test(f.type)) return toast('Выберите файл JPG, PNG или WebP');
    const data = await shrink(f), id = +el.dataset.id, body = { data }; if (S.user.id !== id) body.teacher = id;
    await api('POST', '/api/teach/photo', body); toast('Фото обновлено 📸'); S.ov = null; if (S.user.id === id) { const me = await api('GET', '/api/me'); S.user = me.user; } V.render();
  });
  V.act('tphotodel', async el => {
    const id = +el.dataset.id, body = { remove: true }; if (S.user.id !== id) body.teacher = id;
    await api('POST', '/api/teach/photo', body); toast('Фото удалено'); if (S.user.id === id) { const me = await api('GET', '/api/me'); S.user = me.user; } V.render();
  });
  /* блок в «Профиле» преподавателя */
  V.loadTeacherProfile = async boxId => {
    const box = document.getElementById(boxId); if (!box) return;
    try { const p = await api('GET', '/api/teach/profile'); box.innerHTML = V.tprofHTML(p, {}); } catch (e) { box.innerHTML = ''; }
  };

  /* ───────────── Разговорный клуб: ученик ───────────── */
  const BLOCK = { nosub: 'Нужна подписка', late: 'Подписка кончится раньше', expired: 'Подписка закончилась', full: 'Мест нет', busy: 'У вас занято' };
  const BLOCK_TIP = { nosub: 'Чтобы записаться, нужна подписка на Разговорный клуб', late: 'Ваша подписка закончится раньше этого занятия — продлите её', expired: 'Подписка закончилась — продлите её', full: 'Все места заняты', busy: 'В это время у вас другое занятие' };
  V.subBox = (c, o) => {
    o = o || {};
    if (!c || c.state === 'none') return `<div class="clubst none"><div class="cs-i">🎤</div><div class="cs-b"><b>Подписки на клуб пока нет</b><span>Разговорный клуб — живая практика в небольшой группе. Доступ открывает школа: напишите нам или введите код.</span></div>${o.compact ? '<a class="btn pri sm" href="#/club">Подробнее</a>' : ''}</div>`;
    if (c.state === 'expired') return `<div class="clubst bad"><div class="cs-i">⌛</div><div class="cs-b"><b>Подписка на клуб закончилась</b><span>Закончилась <b>${longDate(c.until)}</b>. Продлите её, чтобы снова записываться на занятия.</span></div>${o.compact ? '<a class="btn pri sm" href="#/club">Продлить</a>' : ''}</div>`;
    const warn = c.state === 'expiring';
    return `<div class="clubst ${warn ? 'warn' : 'ok'}"><div class="cs-i">${warn ? '⏳' : '🎤'}</div><div class="cs-b"><b>${c.lifetime ? 'Подписка на клуб — без ограничения по времени' : warn ? 'Подписка скоро закончится' : 'Подписка на клуб активна'}</b>
      ${c.lifetime ? '<span>Приходите на любые занятия клуба.</span>' : `<span>Действует до <b>${longDate(c.until)}</b> · ${c.left === 0 ? 'сегодня последний день' : 'осталось ' + c.left + ' ' + plural(c.left, ['день', 'дня', 'дней'])}</span>`}</div>
      ${o.compact ? '<a class="btn sm" href="#/club">Открыть клуб</a>' : ''}</div>`;
  };
  V.clubCard = (c, next) => {
    if (!c) return '';
    return `<div class="sect">${V.subBox(c, { compact: 1 })}${next ? `<div class="sess mt8"><div class="tm"><b>${V.fTime(next.starts)}</b><small>${h(V.fDayShort(next.starts))}</small></div><div class="si"><b>${h(next.title)}</b><span>Вы записаны · ${h(next.teacher.name)}</span><span class="cdp" data-cd="${next.starts}" data-end="${next.end}">${V.cd(next.starts - V.now())}</span></div><div class="sa">${V.joinHtml(next)}</div></div>` : ''}</div>`;
  };
  function clubRow(s) {
    const act = s.joined ? `<button class="btn sm gho" data-act="cunbook" data-id="${s.id}">Отменить запись</button>`
      : s.block ? `<span class="bdg lock" title="${h(BLOCK_TIP[s.block])}">${BLOCK[s.block]}</span>` : `<button class="btn pri sm" data-act="cbook" data-id="${s.id}">Записаться</button>`;
    return `<div class="sess ${s.joined ? 'mine' : ''}"><div class="tm"><b>${V.fTime(s.starts)}</b><small>${s.dur} мин</small></div>
      <div class="si"><b>${h(s.title)}</b><span><span class="bdg">${h(s.lang)}</span>${s.level ? ` <span class="bdg">${h(s.level)}</span>` : ''} · мест занято ${s.taken} из ${s.cap}</span>
        <span class="clt"><a href="#/teachers/${s.teacher.id}">${V.avatar(s.teacher, 'xs')}${h(s.teacher.name)}</a> · <span class="cdp" data-cd="${s.starts}" data-end="${s.end}">${V.cd(s.starts - V.now())}</span></span>
        ${s.joined ? '<span class="bdg ok">Вы записаны</span>' : ''}</div>
      <div class="sa">${s.joined ? V.joinHtml(s) : ''}${act}</div></div>`;
  }
  V.route(/^\/club$/, async () => {
    if (S.user && S.user.role !== 'student') return V.go('#/teach/club');
    V.loading(); await V.loadOverview(); hdr('club');
    const d = await api('GET', '/api/club'), up = d.upcoming, c = d.sub, mail = (S.cfg.contacts || {}).email || '';
    const ACT = { grant: 'Подписка открыта', extend: 'Подписка продлена', revoke: 'Доступ закрыт' };
    app.innerHTML = `<section class="phero"><span class="pill"><span class="dot"></span> Разговорная практика</span><h1>Разговорный клуб</h1>
      <p>Небольшие группы и живая речь с преподавателем. Выберите занятие и запишитесь — на все встречи клуба одна и та же ссылка, её присылает преподаватель клуба, и она появится здесь. Время показано в вашем часовом поясе — <b>${h(d.tz.replace(/_/g, ' '))}</b>.</p></section>
      ${V.subBox(c)}
      ${!d.linkSet && up.some(s => s.joined) ? '<div class="notice mt16">🔗 Преподаватель клуба ещё не прислал ссылку на встречу. Как только она появится, вы получите уведомление и письмо — она будет и на этой странице.</div>' : ''}
      ${c.state === 'none' || c.state === 'expired' || c.state === 'expiring' ? `<div class="card mt16"><h3>${c.state === 'none' ? 'Как получить доступ' : 'Как продлить подписку'}</h3>
        <p class="mut2" style="font-size:14px;margin:6px 0 12px">Напишите в школу${mail ? ` (<a href="mailto:${h(mail)}">${h(mail)}</a>)` : ''} — администратор откроет или продлит доступ. Если у вас есть код, введите его ниже.</p>
        <form class="row" data-form="redeem" data-err="cerr"><input name="code" class="srch" style="flex:1;min-width:220px;text-transform:uppercase" placeholder="VOSCA-XXXX-XXXX" autocomplete="off" required><button class="btn pri" type="submit">Активировать</button></form><div class="ferr hide" id="cerr"></div></div>` : ''}
      <div class="sect"><h2>Ближайшие занятия <small>${up.length}</small></h2>
        ${up.length ? dayGroups(up).map(g => `<div class="dayh">${h(V.fDay(g.ts))}</div>${g.items.map(clubRow).join('')}`).join('') : '<div class="empty"><div style="font-size:42px">🎤</div><b>Занятий клуба пока нет.</b><br>Как только преподаватели назначат время, они появятся здесь.</div>'}</div>
      ${d.past.length ? `<div class="sect"><h2>Вы уже были</h2>${d.past.map(s => `<div class="sess past"><div class="tm"><b>${h(V.fDayShort(s.starts))}</b><small>${V.fTime(s.starts)}</small></div><div class="si"><b>${h(s.title)}</b><span>${h(s.teacher.name)}${s.status === 'cancelled' ? ' · <span class="bdg bad">отменено</span>' : ''}</span></div></div>`).join('')}</div>` : ''}
      ${d.hist.length ? `<div class="sect"><h2>История подписки</h2><div class="card"><ul class="hist">${d.hist.map(x => `<li><span class="mut">${h(V.fdate(x.at))}</span> ${ACT[x.act] || x.act}${x.act !== 'revoke' ? (x.until ? ` — до <b>${longDate(x.until)}</b>` : ' — без ограничения') : ''}</li>`).join('')}</ul></div></div>` : ''}`;
    V.refreshLive();
  });
  V.act('cbook', async el => { await api('POST', `/api/club/${el.dataset.id}/book`, {}); toast('Вы записаны! 🎤'); burst(60); V.render(); });
  V.act('cunbook', async el => { await api('POST', `/api/club/${el.dataset.id}/unbook`, {}); toast('Запись отменена'); V.render(); });

  /* ───────────── Разговорный клуб: общие куски для преподавателя и админа ───────────── */
  const SUB_BDG = { active: ['ok', 'активна'], expiring: ['hw', 'скоро закончится'], expired: ['bad', 'закончилась'] };
  let CT = null;                                   // последние данные страницы (для модалов)
  const memberList = s => (s.members && s.members.length)
    ? `<div class="mem">${s.members.map(m => `<span class="chip">${h(m.name)}${s.status === 'planned' ? `<button class="x" title="Убрать из занятия" data-act="ckick" data-id="${s.id}" data-user="${m.id}">×</button>` : ''}</span>`).join('')}</div>` : '';
  const mrow = (s, o) => `<div class="sess ${s.status === 'cancelled' ? 'dec' : ''}"><div class="tm"><b>${V.fTime(s.starts)}</b><small>${s.dur} мин</small></div>
    <div class="si"><b>${h(s.title)}</b><span><span class="bdg">${h(s.lang)}</span>${s.level ? ` <span class="bdg">${h(s.level)}</span>` : ''} · записано ${s.taken} из ${s.cap}${o.who ? ' · ' + h(s.teacher.name) : ''}${s.series ? ' · серия' : ''}${s.status === 'cancelled' ? ' · <span class="bdg bad">отменено</span>' : s.status === 'done' ? ' · <span class="bdg ok">проведено</span>' : ''}${s.reason ? ' · ' + h(s.reason) : ''}</span>
      ${s.status === 'planned' ? `<span class="cdp" data-cd="${s.starts}" data-end="${s.end}">${V.cd(s.starts - V.now())}</span>` : ''}${memberList(s)}</div>
    <div class="sa">${s.status === 'planned' ? `${V.joinHtml(s)}<button class="btn sm" data-act="cmove" data-id="${s.id}">Перенести</button><button class="btn sm gho" data-act="cdone" data-id="${s.id}">Проведено</button><button class="btn sm gho" data-act="ccancel" data-id="${s.id}">Отменить</button>` : ''}</div></div>`;
  const sessList = (d, o) => {
    const by = {}; d.upcoming.concat(d.recent).forEach(s => { by[s.id] = s; }); d.byId = by; CT = d;
    return `<div class="sect"><h2>Ближайшие занятия <small>${d.upcoming.length}</small></h2>${d.upcoming.length ? dayGroups(d.upcoming).map(g => `<div class="dayh">${h(V.fDay(g.ts))}</div>${g.items.map(s => mrow(s, o)).join('')}`).join('') : '<div class="empty">Занятий клуба пока нет. Нажмите «Назначить занятие клуба».</div>'}</div>
      ${d.recent.length ? `<div class="sect"><h2>Недавние</h2>${d.recent.map(s => mrow(s, o)).join('')}</div>` : ''}`;
  };
  V.clubSessionModal = d => {
    const tz = d.tz || V.tz(), tomorrow = V.inputDate(V.now() + 864e5, tz), tl = d.teachers;
    V.modal(`<div class="mbig">🎤</div><h2>Занятие Разговорного клуба</h2>
      <form data-form="mkclub" data-err="merr" data-tz="${h(tz)}" style="text-align:left">
        ${tl ? `<label class="fld"><span>Преподаватель</span><select name="teacher" class="sel">${tl.map(t => `<option value="${t.id}">${h(t.name)}</option>`).join('')}</select></label>` : ''}
        <label class="fld"><span>Тема</span><input name="title" maxlength="100" placeholder="Например: Знакомство и small talk"></label>
        <div class="dbl"><label class="fld"><span>Язык занятия</span><select name="lang" class="sel">${d.langs.map(l => `<option>${h(l)}</option>`).join('')}</select></label>
          <label class="fld"><span>Уровень (необязательно)</span><input name="level" maxlength="20" placeholder="A2–B1"></label></div>
        <div class="dbl"><label class="fld"><span>Дата (${h(tz.split('/').pop().replace(/_/g, ' '))})</span><input type="date" name="date" value="${tomorrow}" required></label>
          <label class="fld"><span>Время</span><input type="time" name="time" value="19:00" required></label></div>
        <div class="dbl"><label class="fld"><span>Длительность, мин</span><input type="number" name="dur" value="60" min="15" max="180" required></label>
          <label class="fld"><span>Мест в группе</span><input type="number" name="cap" value="${d.cap}" min="2" max="50" required></label></div>
        <label class="fld"><span>Повторять каждую неделю</span><select name="repeat" class="sel"><option value="1">Только один раз</option>${[2, 3, 4, 6, 8, 12, 26].map(n => `<option value="${n}">${n} ${plural(n, ['неделя', 'недели', 'недель'])} подряд</option>`).join('')}</select></label>
        <div class="ferr hide" id="merr"></div><div class="acts"><button class="btn pri" type="submit">Создать занятие</button><button type="button" class="btn gho" data-act="closemodal">Отмена</button></div></form>`, { cls: 'wide' });
  };
  /* одна ссылка на все встречи клуба: её вставляет преподаватель, который ведёт клуб, и при желании рассылает записанным */
  V.clubLinkCard = l => `<form class="card mt16 ${l.url ? '' : 'warn'}" data-form="clublink" data-err="lkerr"><h3>🔗 Ссылка на встречи клуба</h3>
    <p class="mut2" style="font-size:14px;margin:6px 0 12px">${l.url ? 'Одна и та же ссылка для всех занятий клуба. Ученики с записью видят кнопку «Подключиться» за 10 минут до начала. Если вы замените ссылку — она обновится во всех занятиях сразу.' : '<b>Ссылки пока нет</b> — ученики не смогут подключиться. Вставьте ссылку на видеовстречу клуба (Zoom, Google Meet…): она подойдёт ко всем занятиям.'}</p>
    <div class="row"><input name="url" class="srch" style="flex:1;min-width:240px" maxlength="300" value="${h(l.url)}" placeholder="https://meet.google.com/…" autocomplete="off">
      <button class="btn pri" type="submit" data-notify="0">Сохранить</button><button class="btn" type="submit" data-notify="1">Сохранить и разослать записанным</button>${l.url ? '<button type="button" class="btn gho" data-act="lksend">Разослать ещё раз</button>' : ''}</div>
    ${l.url && l.by ? `<div class="mut" style="font-size:12.5px;margin-top:8px">Добавил(а) ${h(l.by)} · ${h(V.fDT(l.at))}</div>` : ''}<div class="ferr hide" id="lkerr"></div></form>`;
  V.form('clublink', async (fd, f, ev) => {
    V.hideEl('lkerr'); const notify = !!(ev && ev.submitter && ev.submitter.dataset.notify === '1');
    const r = await api('POST', '/api/teach/club/link', { url: (fd.url || '').trim(), notify });
    toast(r.sent ? `Ссылка сохранена и отправлена: ${r.sent}` : (notify && fd.url ? 'Ссылка сохранена. Записанных на ближайшие занятия пока нет' : 'Ссылка сохранена')); V.render();
  });
  V.act('lksend', async () => { const r = await api('POST', '/api/teach/club/link/send', {}); toast(r.sent ? `Ссылка отправлена: ${r.sent}` : 'Записанных на ближайшие занятия пока нет'); });
  V.act('newclub', () => V.clubSessionModal(CT));
  V.form('mkclub', async (fd, f) => {
    V.hideEl('merr'); const start = V.zoned(fd.date, fd.time, f.dataset.tz); if (!Number.isFinite(start)) throw new Error('Укажите дату и время');
    const body = { start, dur: +fd.dur, cap: +fd.cap, repeat: +fd.repeat, title: fd.title, lang: fd.lang, level: fd.level }; if (fd.teacher) body.teacher = +fd.teacher;
    const r = await api('POST', '/api/teach/club/sessions', body); V.closeModal(); toast(r.created.length > 1 ? `Создано занятий: ${r.created.length}` : 'Занятие создано'); V.render();
  });
  const mform = (kind, id, title, inner, btn) => V.modal(`<h2>${title}</h2><form data-form="${kind}" data-id="${id}" data-err="merr" style="text-align:left">${inner}<div class="ferr hide" id="merr"></div><div class="acts"><button class="btn pri" type="submit">${btn}</button><button type="button" class="btn gho" data-act="closemodal">Закрыть</button></div></form>`);
  V.act('cmove', el => { const s = CT.byId[el.dataset.id]; mform('cmove', s.id, 'Перенести занятие', `<p class="mut2" style="text-align:center">Сейчас: ${h(V.fDT(s.starts))}. Записавшиеся получат письмо.</p><div class="dbl"><label class="fld"><span>Новая дата</span><input type="date" name="date" value="${V.inputDate(s.starts)}" required></label><label class="fld"><span>Время</span><input type="time" name="time" value="${V.fTime(s.starts)}" required></label></div>`, 'Перенести'); });
  V.form('cmove', async (fd, f) => { const start = V.zoned(fd.date, fd.time, V.tz()); if (!Number.isFinite(start)) throw new Error('Укажите дату и время'); await api('POST', `/api/teach/club/sessions/${f.dataset.id}/move`, { start }); V.closeModal(); toast('Перенесено, участники получили письмо'); V.render(); });
  V.act('ccancel', el => { const s = CT.byId[el.dataset.id]; mform('ccancel', s.id, 'Отменить занятие?', `<label class="fld"><span>Причина (увидят записавшиеся)</span><input name="reason" maxlength="200"></label>${s.series ? '<label class="ck mt16"><input type="checkbox" name="series"><span>Отменить и все следующие занятия серии</span></label>' : ''}`, 'Отменить занятие'); });
  V.form('ccancel', async (fd, f) => { const r = await api('POST', `/api/teach/club/sessions/${f.dataset.id}/cancel`, { reason: fd.reason, series: !!fd.series }); V.closeModal(); toast(r.cancelled > 1 ? `Отменено занятий: ${r.cancelled}` : 'Занятие отменено'); V.render(); });
  V.act('cdone', async el => { await api('POST', `/api/teach/club/sessions/${el.dataset.id}/done`, {}); toast('Отмечено как проведённое'); V.render(); });
  V.act('ckick', async el => { if (!confirm('Убрать ученика из этого занятия?')) return; await api('POST', `/api/teach/club/sessions/${el.dataset.id}/kick`, { user: +el.dataset.user }); toast('Ученик убран из занятия'); V.render(); });

  /* ───────────── Разговорный клуб: преподаватель ───────────── */
  V.route(/^\/teach\/club$/, async () => {
    if (S.user && S.user.role === 'student') return V.go('#/club');
    V.loading(); await V.loadOverview(); hdr('teachclub');
    const d = await api('GET', '/api/teach/club');
    app.innerHTML = `<section class="phero"><span class="pill">Преподаватель</span><h1>Разговорный клуб</h1>
      <p>Назначайте занятия клуба — ученики с активной подпиской смогут записаться сами. Время показано в вашем часовом поясе — <b>${h(d.tz.replace(/_/g, ' '))}</b>.</p></section>
      ${V.clubLinkCard(d.link)}
      <div class="row mt24"><button class="btn pri" data-act="newclub">＋ Назначить занятие клуба</button><a class="btn gho" href="#/profile">Мой публичный профиль</a></div>${sessList(d, {})}`;
    V.refreshLive();
  });

  /* ───────────── Разговорный клуб: админ — подписки и занятия ───────────── */
  let AC = null;
  const subRow = r => `<tr><td class="unm"><b>${h(r.name)}</b><span>${h(r.email)}</span></td>
    <td><span class="bdg ${SUB_BDG[r.state][0]}">${SUB_BDG[r.state][1]}</span>${r.lifetime ? ' <span class="bdg">без срока</span>' : ''}</td>
    <td>${r.lifetime ? '—' : `<b>${longDate(r.until, r.tz)}</b>${r.active ? `<br><span class="mut">${r.left === 0 ? 'последний день' : 'осталось ' + r.left + ' ' + plural(r.left, ['день', 'дня', 'дней'])}</span>` : ''}`}</td>
    <td>${r.booked}</td><td class="mut">${h(r.note || '')}${r.by ? `<br><small>выдал(а): ${h(r.by)}</small>` : ''}</td>
    <td class="nw"><button class="btn sm" data-act="subext" data-id="${r.id}">Продлить</button> ${r.active ? `<button class="btn sm gho" data-act="subrev" data-id="${r.id}">Закрыть доступ</button>` : ''}</td></tr>`;
  V.route(/^\/admin\/club$/, async () => {
    if (!guard2()) return; V.loading(); await V.loadOverview(); hdr('admin');
    const d = AC = await api('GET', '/api/admin/club'), st = d.stats;
    const stat = (n, l) => `<div class="meta"><b>${n}</b><span>${l}</span></div>`;
    app.innerHTML = `<section class="phero"><span class="pill">Админка</span><h1>Разговорный клуб</h1>
      <p>Здесь вы открываете и продлеваете подписки на клуб, видите, у кого и когда они заканчиваются, и управляете занятиями. Ученик видит дату окончания у себя в кабинете и на странице клуба; за 7 дней, за 1 день и в день окончания ему приходит напоминание.</p>
      <div class="pstats">${stat(st.active, 'активных подписок')}${stat(st.expiring, 'скоро закончатся')}${stat(st.expired, 'закончились')}${stat(st.lifetime, 'без срока')}</div></section>${V.adminTabs('club')}
      <form class="card mt16" data-form="subgrant" data-err="gerr"><h3>Открыть или продлить подписку</h3>
        <div class="row mt8"><label class="fld" style="flex:2;min-width:220px"><span>Ученик</span><input name="user" list="stulist" placeholder="Начните вводить имя или email" autocomplete="off" required><datalist id="stulist">${d.students.map(u => `<option value="${h(u.email)}">${h(u.name)}</option>`).join('')}</datalist></label>
          <label class="fld" style="width:190px"><span>Как задать срок</span><select name="mode" class="sel" id="submode"><option value="days">На N дней</option><option value="until">До даты</option><option value="lifetime">Без ограничения</option></select></label>
          <label class="fld" id="subdays" style="width:120px"><span>Дней</span><input name="days" type="number" min="1" max="3650" value="30"></label>
          <label class="fld hide" id="subuntil" style="width:170px"><span>Последний день</span><input name="until" type="date"></label>
          <label class="fld" style="flex:1;min-width:160px"><span>Заметка</span><input name="note" maxlength="100" placeholder="Оплата, акция…"></label></div>
        <p class="mut2" style="font-size:13px;margin:8px 0 0">Если подписка ещё действует, «N дней» добавляются к текущей дате окончания. Доступ действует до конца последнего дня в часовом поясе ученика.</p>
        <div class="ferr hide" id="gerr"></div><button class="btn pri mt16" type="submit">Выдать доступ</button></form>
      <div class="sect"><h2>Подписчики <small>${d.subs.length}</small></h2><div class="atw"><table class="at"><thead><tr><th>Ученик</th><th>Статус</th><th>Действует до</th><th>Записей</th><th>Заметка</th><th></th></tr></thead><tbody>${d.subs.map(subRow).join('') || '<tr><td colspan="6" class="mut" style="text-align:center;padding:26px">Подписок пока нет. Выдайте первую формой выше или создайте код доступа «Разговорный клуб» на вкладке «Коды доступа».</td></tr>'}</tbody></table></div></div>
      ${V.clubLinkCard(d.link)}
      <div class="row mt24"><button class="btn pri" data-act="newclub">＋ Назначить занятие клуба</button></div>${sessList(d, { who: 1 })}`;
    V.refreshLive();
  });
  const guard2 = () => { if (!S.user || S.user.role !== 'admin') { hdr('cabinet'); V.notFound('Нет доступа'); return false; } return true; };
  document.addEventListener('change', ev => {
    if (ev.target.id !== 'submode') return; const m = ev.target.value;
    document.getElementById('subdays').classList.toggle('hide', m !== 'days'); document.getElementById('subuntil').classList.toggle('hide', m !== 'until');
  });
  V.form('subgrant', async fd => {
    V.hideEl('gerr'); const body = { user: fd.user.trim(), note: fd.note };
    if (fd.mode === 'lifetime') body.lifetime = true; else if (fd.mode === 'until') { if (!fd.until) throw new Error('Выберите последний день подписки'); body.until = fd.until; } else body.days = +fd.days;
    const r = await api('POST', '/api/admin/club/grant', body); toast(`Готово: ${r.name} — ${r.sub.lifetime ? 'без ограничения' : 'до ' + longDate(r.sub.until)}. Ученик получил письмо.`); V.render();
  });
  V.act('subext', el => {
    const r = AC.subs.find(x => x.id === +el.dataset.id);
    mform('subgrant2', r.id, 'Продлить подписку', `<p class="mut2" style="text-align:center">${h(r.name)} · ${r.lifetime ? 'сейчас без ограничения' : (r.active ? 'действует до ' : 'закончилась ') + longDate(r.until, r.tz)}</p>
      <div class="row" style="justify-content:center;margin-bottom:12px">${[30, 90, 180, 365].map(n => `<button type="button" class="btn sm gho" data-act="subadd" data-id="${r.id}" data-days="${n}">+${n} дн.</button>`).join('')}</div>
      <div class="dbl"><label class="fld"><span>Или до даты</span><input type="date" name="until"></label><label class="fld"><span>Заметка</span><input name="note" maxlength="100" value="${h(r.note || '')}"></label></div>
      <label class="ck mt8"><input type="checkbox" name="lifetime"><span>Без ограничения по времени</span></label>`, 'Сохранить');
  });
  V.form('subgrant2', async (fd, f) => {
    const body = { user: +f.dataset.id, note: fd.note }; if (fd.lifetime) body.lifetime = true; else if (fd.until) body.until = fd.until; else throw new Error('Выберите дату, быстрое продление или «без ограничения»');
    await api('POST', '/api/admin/club/grant', body); V.closeModal(); toast('Подписка обновлена'); V.render();
  });
  V.act('subadd', async el => { await api('POST', '/api/admin/club/grant', { user: +el.dataset.id, days: +el.dataset.days }); V.closeModal(); toast('Подписка продлена на ' + el.dataset.days + ' дн.'); V.render(); });
  V.act('subrev', el => V.confirm('Закрыть доступ к клубу?', 'Подписка закончится сразу, ученик получит письмо, а его записи на будущие занятия клуба будут отменены.', 'Закрыть доступ', 'subrev2', { id: el.dataset.id }));
  V.act('subrev2', async el => { await api('POST', '/api/admin/club/revoke', { user: +el.dataset.id }); V.closeModal(); toast('Доступ закрыт'); V.render(); });

  /* блок подписки в карточке ученика (админка) */
  V.adminClubBlock = (uid, sub, hist) => {
    const c = sub || { state: 'none' };
    return `<div class="card"><div>${V.subBox(c)}</div>
      <div class="row mt16"><button class="btn sm pri" data-act="subext2" data-id="${uid}">${c.state === 'none' ? 'Открыть доступ' : 'Продлить'}</button>${c.state === 'active' || c.state === 'expiring' ? `<button class="btn sm gho" data-act="subrev" data-id="${uid}">Закрыть доступ</button>` : ''}<a class="btn sm gho" href="#/admin/club">Все подписки</a></div>
      ${hist && hist.length ? `<ul class="hist mt16">${hist.map(x => `<li><span class="mut">${h(V.fdate(x.at))}</span> ${({ grant: 'Открыт доступ', extend: 'Продлено', revoke: 'Доступ закрыт' })[x.act] || x.act}${x.act !== 'revoke' ? (x.until ? ` — до <b>${longDate(x.until)}</b>` : ' — без ограничения') : ''}</li>`).join('')}</ul>` : ''}</div>`;
  };
  V.act('subext2', el => {
    const id = +el.dataset.id;
    mform('subgrant2', id, 'Подписка на клуб', `<div class="row" style="justify-content:center;margin-bottom:12px">${[30, 90, 180, 365].map(n => `<button type="button" class="btn sm gho" data-act="subadd" data-id="${id}" data-days="${n}">+${n} дн.</button>`).join('')}</div>
      <div class="dbl"><label class="fld"><span>Или до даты</span><input type="date" name="until"></label><label class="fld"><span>Заметка</span><input name="note" maxlength="100"></label></div>
      <label class="ck mt8"><input type="checkbox" name="lifetime"><span>Без ограничения по времени</span></label>`, 'Сохранить');
  });

  /* ───────────── запросы на урок: ученик предлагает время, преподаватель отвечает ───────────── */
  const REQ_ST = { pending: ['hw', 'ждёт ответа'], accepted: ['ok', 'принят'], declined: ['bad', 'отклонён'], expired: ['lock', 'время прошло'] };
  V.reqStudent = sc => {
    const can = sc.reqCourses.length && sc.reqTeachers.length;
    return `<div class="row mt16"><button class="btn pri" data-act="reqnew" ${can ? '' : 'disabled'}>🙋 Запросить урок</button>${!sc.reqCourses.length ? '<span class="mut2" style="font-size:14px">Сначала нужен доступ к курсу — он появится после оплаты или кода.</span>' : '<span class="mut2" style="font-size:14px">Предложите удобное время — преподаватель подтвердит или предложит другое.</span>'}</div>
      ${sc.requests.length ? `<div class="sect"><h2>Ваши запросы <small>${sc.requests.length}</small></h2>${sc.requests.map(r => `<div class="sess ${r.status === 'pending' ? '' : 'past'}"><div class="tm"><b>${V.fTime(r.starts)}</b><small>${h(V.fDayShort(r.starts))}</small></div>
        <div class="si"><b>${h(r.courseTitle)} · ${r.dur} мин</b><span><a href="#/teachers/${r.teacher.id}">${h(r.teacher.name)}</a> · <span class="bdg ${REQ_ST[r.status][0]}">${REQ_ST[r.status][1]}</span>${r.reason ? ' · ' + h(r.reason) : ''}</span>${r.note ? `<span class="mut">«${h(r.note)}»</span>` : ''}</div>
        <div class="sa">${r.status === 'pending' ? `<button class="btn sm gho" data-act="reqcancel" data-id="${r.id}">Отозвать</button>` : r.status === 'declined' || r.status === 'expired' ? '<button class="btn sm" data-act="reqnew">Предложить другое время</button>' : ''}</div></div>`).join('')}</div>` : ''}`;
  };
  let REQ_SC = null, REQ_PICK = null;
  /* в списке — только преподаватели выбранного языка (свои — первыми) */
  const reqTeacherOpts = cid => {
    const list = REQ_SC.reqTeachers.filter(t => !t.langs.length || t.langs.includes(cid));
    return list.length ? list.map(t => `<option value="${t.id}" ${REQ_PICK === t.id || (!REQ_PICK && t.mine) ? 'selected' : ''}>${h(t.name)}${t.mine ? ' · ваш преподаватель' : ''}</option>`).join('') : '<option value="">Пока нет преподавателя этого языка</option>';
  };
  V.act('reqcourse', el => { const f = el.closest('form'), sel = f && f.querySelector('select[name=teacher]'); if (sel) sel.innerHTML = reqTeacherOpts(el.value); });
  V.act('reqnew', async el => {
    const sc = await api('GET', '/api/schedule'), tz = sc.tz, pick = el && el.dataset && el.dataset.teacher ? +el.dataset.teacher : null;
    if (!sc.reqCourses.length) return toast('Сначала нужен доступ к курсу');
    const tomorrow = V.inputDate(V.now() + 864e5, tz); REQ_SC = sc; REQ_PICK = pick;
    V.modal(`<div class="mbig">🙋</div><h2>Запросить урок</h2>
      <form data-form="reqsend" data-err="merr" data-tz="${h(tz)}" style="text-align:left">
        <label class="fld"><span>Язык</span><select name="course" class="sel" data-chg="reqcourse">${sc.reqCourses.map(c => `<option value="${c.id}">${h(c.title)}</option>`).join('')}</select></label>
        <label class="fld"><span>Преподаватель</span><select name="teacher" class="sel">${reqTeacherOpts(sc.reqCourses[0].id)}</select></label>
        <div class="dbl"><label class="fld"><span>Дата (${h(tz.split('/').pop().replace(/_/g, ' '))})</span><input type="date" name="date" value="${tomorrow}" required></label>
        <label class="fld"><span>Время</span><input type="time" name="time" value="18:00" required></label></div>
        <label class="fld"><span>Длительность</span><select name="dur" class="sel">${[30, 50, 60, 90].map(n => `<option value="${n}" ${n === 50 ? 'selected' : ''}>${n} мин</option>`).join('')}</select></label>
        <label class="fld"><span>Комментарий (необязательно)</span><textarea name="note" class="ta" rows="3" maxlength="300" placeholder="Например: хочу потренировать разговор"></textarea></label>
        <div class="ferr hide" id="merr"></div><div class="acts"><button class="btn pri" type="submit">Отправить запрос</button><button type="button" class="btn gho" data-act="closemodal">Отмена</button></div></form>`, { cls: 'wide' });
  });
  V.form('reqsend', async (fd, f) => {
    V.hideEl('merr'); const start = V.zoned(fd.date, fd.time, f.dataset.tz); if (!Number.isFinite(start)) throw new Error('Укажите дату и время');
    if (!fd.teacher) throw new Error('Для этого языка пока нет преподавателя — напишите в школу');
    await api('POST', '/api/live/request', { teacher: +fd.teacher, course: fd.course, start, dur: +fd.dur, note: fd.note });
    V.closeModal(); toast('Запрос отправлен — преподаватель ответит в ближайшее время'); V.render();
  });
  V.act('reqcancel', async el => { await api('POST', `/api/live/request/${el.dataset.id}/cancel`, {}); toast('Запрос отозван'); V.render(); });

  V.reqTeach = d => {
    if (!d.requests || !d.requests.length) return '';
    return `<div class="sect"><h2>🙋 Запросы учеников <small>${d.requests.length}</small></h2>${d.requests.map(r => `<div class="sess"><div class="tm"><b>${V.fTime(r.starts)}</b><small>${h(V.fDayShort(r.starts))}</small></div>
      <div class="si"><b>${h(r.student.name)}</b><span>${h(r.courseTitle)} · ${r.dur} мин · у ученика ${V.fTime(r.starts, r.student.tz)}</span>${r.note ? `<span class="mut">«${h(r.note)}»</span>` : ''}</div>
      <div class="sa"><button class="btn pri sm" data-act="reqacc" data-id="${r.id}">Принять</button><button class="btn sm gho" data-act="reqdec" data-id="${r.id}">Отклонить</button></div></div>`).join('')}</div>`;
  };
  V.act('reqacc', async el => { await api('POST', `/api/teach/requests/${el.dataset.id}/accept`, {}); toast('Урок назначен, ученик получил письмо'); V.render(); });
  V.act('reqdec', el => mform('reqdecl', el.dataset.id, 'Отклонить запрос', '<label class="fld"><span>Причина или другое время (увидит ученик)</span><input name="reason" maxlength="200" placeholder="Например: в это время занята — могу в четверг в 18:00"></label>', 'Отклонить и сообщить ученику'));
  V.form('reqdecl', async (fd, f) => { await api('POST', `/api/teach/requests/${f.dataset.id}/decline`, { reason: fd.reason }); V.closeModal(); toast('Ученик получил ответ'); V.render(); });
})();
