'use strict';
/* Vosca · платформа обучения. Без внешних зависимостей: Node 22+. */
require('./lib/env');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const store = require('./lib/store');
const contentLib = require('./lib/content');
const smtp = require('./lib/smtp');
const { load } = require('./lib/loader');

const E = process.env;
const PORT = parseInt(E.PORT, 10) || 3000;
const SECURE = E.COOKIE_SECURE === '1';
const TRUST_PROXY = E.TRUST_PROXY === '1';
const ADMIN_EMAIL = (E.ADMIN_EMAIL || '').trim().toLowerCase();
const DATA_DIR = E.DATA_DIR || path.join(__dirname, 'data');
const CONTENT_DIR = E.CONTENT_DIR || path.join(__dirname, 'content');
const PUBLIC = path.join(__dirname, 'public');
const SESSION_DAYS = 30;
const num = (v, d) => { const n = parseInt(v, 10); return Number.isFinite(n) ? n : d; };

/* ── сборка ядра ── */
const core = load();
const { HttpError } = core;
const st = store.open(DATA_DIR);
const BUNDLED = path.join(__dirname, 'content');
if (path.resolve(CONTENT_DIR) !== BUNDLED && !fs.existsSync(path.join(CONTENT_DIR, 'courses.json'))) { fs.mkdirSync(CONTENT_DIR, { recursive: true }); fs.cpSync(BUNDLED, CONTENT_DIR, { recursive: true }); console.log('Контент скопирован в', CONTENT_DIR); }
const content = contentLib.open(CONTENT_DIR);
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const scryptOpts = { N: 16384, r: 8, p: 1 };

const smtpCfg = E.SMTP_HOST ? { host: E.SMTP_HOST, port: num(E.SMTP_PORT, 587), user: E.SMTP_USER || '', pass: E.SMTP_PASS || '', from: E.MAIL_FROM || E.SMTP_USER, requireTls: E.SMTP_REQUIRE_TLS !== '0' } : null;
const env = {
  now: () => Date.now(),
  random: () => crypto.randomInt(0, 2 ** 31) / 2 ** 31,
  token: n => crypto.randomBytes(n).toString('base64url'),
  hashPassword(pw) { const salt = crypto.randomBytes(16); return 'scrypt$' + salt.toString('hex') + '$' + crypto.scryptSync(pw, salt, 64, scryptOpts).toString('hex'); },
  verifyPassword(pw, stored) {
    try { const [alg, s, k] = String(stored).split('$'); if (alg !== 'scrypt') return false; const key = crypto.scryptSync(pw, Buffer.from(s, 'hex'), 64, scryptOpts), want = Buffer.from(k, 'hex'); return want.length === key.length && crypto.timingSafeEqual(want, key); } catch (e) { return false; }
  },
  dummyHash: (() => { let h; return () => (h = h || env.hashPassword('dummy-for-timing')); })(),
  baseUrl: () => (E.PUBLIC_URL || 'http://localhost:' + PORT).replace(/\/+$/, ''),
  dropSessions(uid) { const d = app.db(); Object.keys(d.sessions).forEach(h => { if (d.sessions[h].uid === uid) delete d.sessions[h]; }); },
  mailMode: () => (smtpCfg ? 'smtp' : 'log')
};
const app = core.createApp({
  db: st.db, content, env, adminEmail: ADMIN_EMAIL,
  cfg: { PASS_SCORE: num(E.PASS_SCORE, 80), HW_SIZE: num(E.HW_SIZE, 8), HW_PASS: num(E.HW_PASS, 70), MIN_LESSON_SECONDS: num(E.MIN_LESSON_SECONDS, 90),
    LEGAL: !/^(0|false|no|off)$/i.test(String(E.LEGAL === undefined ? '1' : E.LEGAL).trim()),
    REQUIRE_CODE: !/^(0|false|no|off)$/i.test(String(E.REQUIRE_CODE === undefined ? '1' : E.REQUIRE_CODE).trim()),
    AUTO_ENROLL: (E.AUTO_ENROLL || '').split(',').map(s => s.trim()).filter(Boolean) }
});
if (ADMIN_EMAIL) { const a = app.bootstrapAdmin(ADMIN_EMAIL, E.ADMIN_PASSWORD, E.ADMIN_NAME); if (a) console.log('Администратор:', ADMIN_EMAIL); st.save(); }

/* ── сессии ── */
function createSession(uid) { const token = crypto.randomBytes(32).toString('base64url'); app.db().sessions[sha(token)] = { uid, exp: Date.now() + SESSION_DAYS * 864e5 }; return token; }
function parseCookies(req) { const o = {}; String(req.headers.cookie || '').split(';').forEach(p => { const i = p.indexOf('='); if (i > 0) o[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); }); return o; }
function userFromReq(req) {
  const t = parseCookies(req).vsid; if (!t) return null;
  const s = app.db().sessions[sha(t)]; if (!s || s.exp < Date.now()) return null;
  return app.db().users[s.uid] || null;
}
const cookie = (t, secure) => `vsid=${t}; HttpOnly; Path=/; SameSite=Lax; Max-Age=${SESSION_DAYS * 86400}${secure ? '; Secure' : ''}`;
const clearCookie = secure => `vsid=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0${secure ? '; Secure' : ''}`;

/* ── HTTP-помощники ── */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.json': 'application/json' };
const SEC = { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin', 'X-Frame-Options': 'SAMEORIGIN' };
const APP_CSP = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; frame-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'self'";
const send = (res, status, body, headers) => { res.writeHead(status, Object.assign({}, SEC, headers)); res.end(body); };
const json = (res, status, obj, headers) => send(res, status, JSON.stringify(obj), Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, headers));
const clientIp = req => (TRUST_PROXY && String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress || '?';

const hits = new Map();
function rateLimit(key, max, windowMs) {
  const t = Date.now(), arr = (hits.get(key) || []).filter(x => t - x < windowMs);
  if (arr.length >= max) { hits.set(key, arr); throw new HttpError(429, 'Слишком много попыток. Подождите несколько минут.'); }
  arr.push(t); hits.set(key, arr);
}
function checkOrigin(req) {
  const o = req.headers.origin; if (!o) return;
  try { if (new URL(o).host !== req.headers.host) throw 0; } catch (e) { throw new HttpError(403, 'Чужой источник запроса'); }
}
function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    if (!String(req.headers['content-type'] || '').startsWith('application/json')) return reject(new HttpError(415, 'Нужен JSON'));
    let size = 0; const chunks = [];
    req.on('data', c => { size += c.length; if (size > limit) { reject(new HttpError(413, 'Слишком большой запрос')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch (e) { reject(new HttpError(400, 'Неверный JSON')); } });
    req.on('error', reject);
  });
}

/* ── загрузка уроков (только админ) ── */
const STAGING = path.join(DATA_DIR, 'staging'); fs.mkdirSync(STAGING, { recursive: true });
function adminLessonApi(path_, body, user) {
  let m;
  if (path_ === '/api/admin/lessons/stage') {
    const raw = String(body.html || '');
    if (raw.length < 2000 || raw.length > 8e6) throw new HttpError(400, 'Файл урока слишком маленький или слишком большой');
    const html = core.adaptLesson(raw);
    if (!html) throw new HttpError(400, 'Не похоже на урок Vosca: в файле не нашлось движка уроков. Загрузите HTML, собранный нашим конструктором.');
    const id = crypto.randomBytes(8).toString('hex'); fs.writeFileSync(path.join(STAGING, id + '.html'), html);
    return { id };
  }
  if (path_ === '/api/admin/lessons/commit') {
    const id = String(body.stage || ''); if (!/^[a-f0-9]{16}$/.test(id)) throw new HttpError(400, 'Нет загруженного файла');
    const f = path.join(STAGING, id + '.html'); if (!fs.existsSync(f)) throw new HttpError(404, 'Файл урока потерян — загрузите заново');
    try { content.commit({ key: String(body.key || ''), html: fs.readFileSync(f), meta: body.meta, bank: body.bank, lang: String(body.lang || 'ru'), course: String(body.course || ''), module: String(body.module || ''), moduleTitle: String(body.moduleTitle || '').slice(0, 80) }); }
    catch (e) { throw new HttpError(400, e.message); }
    fs.unlinkSync(f); return { ok: true };
  }
  if (path_ === '/api/admin/lessons/remove') { content.removeFromCourses(String(body.key || '')); return { ok: true }; }
  if (path_ === '/api/admin/lessons/move') { content.move(String(body.key || ''), body.dir < 0 ? -1 : 1); return { ok: true }; }
  if (path_ === '/api/admin/courses') { try { content.upsertCourse(body); } catch (e) { throw new HttpError(400, e.message); } return { ok: true }; }
  return undefined;
}

/* ── запросы ── */
async function handleApi(req, res, url, p) {
  const method = req.method;
  if (method !== 'GET' && method !== 'HEAD') checkOrigin(req);
  const user = userFromReq(req);
  let body = {};
  if (method === 'POST') {
    if (p === '/api/register') rateLimit('reg:' + clientIp(req), 8, 3600e3);
    if (p === '/api/staff/register' || p === '/api/staff/check') rateLimit('staff:' + clientIp(req), 20, 3600e3);
    if (p === '/api/login') rateLimit('login:' + clientIp(req), 20, 15 * 60e3);
    body = await readBody(req, p === '/api/admin/lessons/stage' ? 9e6 : p === '/api/teach/photo' ? 400 * 1024 : p === '/api/materials' ? 4.6e6 : 128 * 1024);
    if (p === '/api/login') rateLimit('loginu:' + String(body.email || '').toLowerCase().slice(0, 200), 8, 15 * 60e3);
    if (p === '/api/account/password' || p === '/api/account/delete') rateLimit('pw:' + (user ? user.id : clientIp(req)), 8, 3600e3);
    if (p === '/api/redeem') rateLimit('redeem:' + (user ? user.id : clientIp(req)), 12, 3600e3);
  }
  if (p.startsWith('/api/admin/') && (p.startsWith('/api/admin/lessons/') || p === '/api/admin/courses') && method === 'POST') {
    if (!user) throw new HttpError(401, 'Войдите в аккаунт'); if (user.role !== 'admin') throw new HttpError(403, 'Только для администратора');
    const r = adminLessonApi(p, body, user); st.save(); return json(res, 200, r);
  }
  const query = Object.fromEntries(url.searchParams.entries());
  const r = app.handle({ method, path: p, query, body, user, ip: clientIp(req), ua: String(req.headers['user-agent'] || '') });
  const headers = {};
  if (r.login) headers['Set-Cookie'] = cookie(createSession(r.login), SECURE);
  if (r.logout) { const t = parseCookies(req).vsid; if (t) delete app.db().sessions[sha(t)]; headers['Set-Cookie'] = clearCookie(SECURE); }
  if (method !== 'GET') st.save();
  return json(res, r.status, r.body, headers);
}

function serveLesson(req, res, key, lang) {
  const user = userFromReq(req);
  if (!user) return send(res, 401, 'Войдите в аккаунт', { 'Content-Type': 'text/plain; charset=utf-8' });
  const r = app.handle({ method: 'GET', path: '/api/lesson/' + key, user, query: {}, body: {} });
  if (r.status !== 200) return send(res, r.status, r.body.error || 'Нет доступа', { 'Content-Type': 'text/plain; charset=utf-8' });
  const html = content.html(key, lang); if (!html) return send(res, 404, 'Файл урока не найден', { 'Content-Type': 'text/plain; charset=utf-8' });
  send(res, 200, html, { 'Content-Type': MIME['.html'], 'Cache-Control': 'private, no-store', 'Content-Security-Policy': 'frame-ancestors \'self\'' });
}
function serveStatic(req, res, p) {
  const rel = p === '/' ? '/index.html' : p;
  let file = path.normalize(path.join(PUBLIC, rel));
  if (!file.startsWith(PUBLIC + path.sep)) return send(res, 403, 'Нельзя');
  let s; try { s = fs.statSync(file); } catch (e) { s = null; }
  if (!s || !s.isFile()) { if (path.extname(rel)) return send(res, 404, 'Не найдено', { 'Content-Type': 'text/plain; charset=utf-8' }); file = path.join(PUBLIC, 'index.html'); s = fs.statSync(file); }
  const ext = path.extname(file), etag = `"${s.size}-${Math.floor(s.mtimeMs)}"`;
  const h = { 'Content-Type': MIME[ext] || 'application/octet-stream', ETag: etag, 'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=300' };
  if (ext === '.html') h['Content-Security-Policy'] = APP_CSP;
  if (req.headers['if-none-match'] === etag) return send(res, 304, '', h);
  send(res, 200, req.method === 'HEAD' ? '' : fs.readFileSync(file), h);
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    let p; try { p = decodeURIComponent(url.pathname); } catch (e) { throw new HttpError(400, 'Плохой адрес'); }
    if (p.startsWith('/api/')) return await handleApi(req, res, url, p);
    let m;
    if ((m = p.match(/^\/lessons\/([a-z0-9-]+)$/)) && req.method === 'GET') return serveLesson(req, res, m[1], url.searchParams.get('lang') === 'en' ? 'en' : 'ru');
    if ((m = p.match(/^\/staging\/([a-f0-9]{16})$/)) && req.method === 'GET') {
      const u = userFromReq(req); if (!u || u.role !== 'admin') return send(res, 403, 'Нет доступа', { 'Content-Type': 'text/plain; charset=utf-8' });
      const f = path.join(STAGING, m[1] + '.html'); if (!fs.existsSync(f)) return send(res, 404, 'Не найдено');
      return send(res, 200, fs.readFileSync(f), { 'Content-Type': MIME['.html'], 'Cache-Control': 'no-store', 'Content-Security-Policy': "frame-ancestors 'self'" });
    }
    if ((m = p.match(/^\/cal\/([A-Za-z0-9_-]{10,60})\.ics$/)) && req.method === 'GET') {
      rateLimit('cal:' + clientIp(req), 120, 3600e3);
      const ics = app.icsByToken(m[1]); if (!ics) return send(res, 404, 'Не найдено', { 'Content-Type': 'text/plain' });
      return send(res, 200, ics, { 'Content-Type': 'text/calendar; charset=utf-8', 'Cache-Control': 'no-cache' });
    }
    if ((m = p.match(/^\/photo\/(\d{1,9})$/)) && req.method === 'GET') {            // фото преподавателей видят только вошедшие пользователи
      if (!userFromReq(req)) return send(res, 401, 'Войдите в аккаунт', { 'Content-Type': 'text/plain; charset=utf-8' });
      const ph = app.photoOf(+m[1]); if (!ph) return send(res, 404, 'Нет фото', { 'Content-Type': 'text/plain; charset=utf-8' });
      return send(res, 200, ph.buf, { 'Content-Type': ph.mime, 'Cache-Control': 'private, max-age=86400', 'Content-Disposition': 'inline' });
    }
    if (p === '/healthz') return send(res, 200, 'ok', { 'Content-Type': 'text/plain' });
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Метод не поддерживается');
    return serveStatic(req, res, p);
  } catch (e) {
    if (e instanceof HttpError) return json(res, e.status, Object.assign({ error: e.message }, e.extra || {}));
    console.error(e); if (!res.headersSent) json(res, 500, { error: 'Ошибка сервера' }); else res.end();
  }
});

/* ── фоновые задачи: напоминания и отправка писем ── */
let sending = false;
async function deliverMail() {
  if (sending) return; sending = true;
  try {
    const t = Date.now();
    for (const m of app.pendingMail().slice(0, 10)) {
      if (m.next && m.next > t) continue;
      if (!smtpCfg) { app.mailDone(m.id, 'logged', 'SMTP не настроен — письмо записано в журнал'); st.save(); continue; }
      try { await smtp.sendMail(smtpCfg, { to: m.to, subject: m.subject, text: m.text, html: m.html }); app.mailDone(m.id, 'sent'); }
      catch (e) { app.mailDone(m.id, (m.tries || 0) >= 4 ? 'failed' : 'queued', e.message); m.next = Date.now() + 60e3 * Math.pow(2, m.tries || 0); console.error('Письмо не ушло:', m.to, e.message); }
      st.save();
    }
  } finally { sending = false; }
}
function startJobs() {
  setInterval(() => { try { const n = app.tick(); if (n) st.save(); deliverMail(); } catch (e) { console.error('tick', e); } }, 30e3).unref();
  setInterval(() => { const t = Date.now(), d = app.db(); Object.keys(d.sessions).forEach(h => { if (d.sessions[h].exp < t) delete d.sessions[h]; }); for (const [k, v] of hits) if (!v.some(x => t - x < 3600e3)) hits.delete(k); st.save(); }, 3600e3).unref();
  setTimeout(deliverMail, 2000).unref();
}

if (require.main === module) {
  server.listen(PORT, () => { console.log(`Vosca платформа: http://localhost:${PORT}  ·  почта: ${smtpCfg ? 'SMTP ' + smtpCfg.host : 'только журнал (SMTP не настроен)'}`); startJobs(); });
}
module.exports = { server, app, st, content, startJobs, deliverMail, env };
