"""Проверка демо-файла из file://.  Запуск: python3 test/demo.py /путь/Vosca_Platform_Demo.html"""
import sys, time, os
from playwright.sync_api import sync_playwright
F = 'file://' + sys.argv[1]; SH = os.environ.get('SHOTS', '/tmp/vp/shots'); os.makedirs(SH, exist_ok=True)
errors = []; n = 0
def ok(m):
    global n; n += 1; print('  ✓', m)
def wait(pg, s, t=8):
    t0 = time.time()
    while time.time() - t0 < t:
        if s.lower() in pg.inner_text('body').lower(): return
        time.sleep(.15)
    raise AssertionError('нет: ' + s + '\n' + pg.inner_text('body')[:900])
with sync_playwright() as p:
    br = p.chromium.launch(); ctx = br.new_context(viewport={'width': 1240, 'height': 900}, locale='ru-RU', timezone_id='Europe/Moscow')
    pg = ctx.new_page(); pg.on('console', lambda m: errors.append(m.text) if m.type == 'error' else None); pg.on('pageerror', lambda e: errors.append(str(e)))
    pg.goto(F); wait(pg, 'С возвращением'); ok('демо открывается из файла')
    pg.click('[data-d=anna]'); wait(pg, 'Личный кабинет'); wait(pg, 'Ближайший живой урок'); pg.wait_for_timeout(400); pg.screenshot(path=f'{SH}/d1_cabinet.png', full_page=True)
    ok('ученик: кабинет с карточкой живого урока')
    assert pg.locator('a.jn:visible').count() == 0; ok('до начала урока кнопка «Подключиться» неактивна')
    pg.click('[data-d=t30]'); wait(pg, 'Ближайший живой урок'); pg.wait_for_timeout(500)
    assert pg.locator('a.jn:visible').count() >= 1; assert pg.locator('a.jn:visible').first.get_attribute('href').startswith('https://meet.google.com/'); ok('перемотка времени на 30 минут: «Подключиться» загорается и ведёт на видеовстречу')
    pg.click('.bell'); wait(pg, 'Урок начинается'); pg.screenshot(path=f'{SH}/d2_bell.png'); ok('пришло уведомление «Урок начинается» (за 15 минут)')
    pg.goto(F + '#/schedule'); pg.reload(); wait(pg, 'Календарь в телефоне'); pg.screenshot(path=f'{SH}/d3_schedule.png', full_page=True)
    pg.click('[data-d=kim]'); wait(pg, 'Мои ученики и занятия'); pg.wait_for_timeout(400); pg.screenshot(path=f'{SH}/d4_teacher.png', full_page=True); ok('преподаватель: панель занятий')
    pg.click('[data-d=admin]'); wait(pg, 'Ученики'); pg.goto(F + '#/admin/mail'); pg.reload(); wait(pg, 'Демо: письма'); wait(pg, 'Урок начинается')
    pg.screenshot(path=f'{SH}/d5_mail.png', full_page=True); ok('админ: журнал писем содержит напоминания об уроках')
    pg.goto(F + '#/admin/legal'); pg.reload(); wait(pg, 'Ученики'); assert 'Документы и реквизиты' not in pg.inner_text('body'); ok('демо: юридический раздел отсутствует')
    # ── свои уроки в демо ──
    LESSON = os.environ.get('OLD_LESSON') or os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'content', 'lessons', 'grammar-1.html')   # OLD_LESSON — файл старой сборки без связи с платформой
    pg.click('[data-d=admin]'); wait(pg, 'Ученики'); pg.goto(F + '#/admin/content'); pg.reload(); wait(pg, 'Загрузить новый урок')
    pg.set_input_files('#lessonFile', LESSON); pg.click('[data-act=stagefile]'); wait(pg, 'Прочитано', 15)
    pg.fill('input[name=key]', 'my-new-lesson'); pg.select_option('#mSel', '__new'); pg.fill('input[name=moduleTitle]', 'Мои уроки')
    pg.click('form[data-form=commit] button[type=submit]'); wait(pg, 'Урок опубликован'); pg.wait_for_timeout(600)
    assert 'my-new-lesson' in pg.inner_text('body') and 'Мои уроки' in pg.inner_text('body'); pg.screenshot(path=f'{SH}/d8_upload.png', full_page=True)
    ok('демо: админ загрузил свой урок, паспорт и банк вопросов прочитаны, создан новый модуль')
    pg.reload(); wait(pg, 'my-new-lesson'); ok('загруженный урок сохраняется после перезагрузки страницы (IndexedDB)')
    uid = pg.evaluate("Object.values(DEMO_APP.db().users).find(u => u.email === 'anna@vosca.demo').id")
    pg.evaluate("VOSCA_API('POST', '/api/admin/users/%d/pass', { lesson: 'my-new-lesson' })" % uid)
    pg.click('[data-d=anna]'); wait(pg, 'Личный кабинет'); pg.goto(F + '#/lesson/my-new-lesson'); pg.reload(); pg.wait_for_selector('#lessonFrame'); pg.wait_for_timeout(1500)
    assert pg.frame_locator('#lessonFrame').locator('body').inner_text().strip(); ok('ученик открывает загруженный урок')
    pg.click('[data-d=admin]'); wait(pg, 'Ученики'); pg.goto(F + '#/admin/content'); pg.reload(); wait(pg, 'my-new-lesson')
    pg.click('[data-act=lrem][data-key=my-new-lesson]'); pg.click('[data-act=lrem2]'); wait(pg, 'Убрано'); pg.wait_for_timeout(500); assert 'my-new-lesson' not in pg.inner_text('body'); ok('урок можно убрать из курса')
    # новый язык
    pg.fill('form[data-form=course] input[name=id]', 'en'); pg.fill('form[data-form=course] input[name=title]', 'Английский язык (тест)'); pg.click('form[data-form=course] button[type=submit]'); wait(pg, 'Курс сохранён'); ok('демо: можно создать новый курс-язык')
    # новый ученик: регистрация → код → курс → урок
    pg.evaluate("localStorage.removeItem('vosca_demo_bar')"); pg.click('[data-act=logout]'); wait(pg, 'С возвращением')
    pg.click('[data-act=mode][data-m=register]'); pg.fill('input[name=name]', 'Новый'); pg.fill('input[name=email]', 'new@x.io'); pg.fill('input[name=password]', 'secret1234')
    assert pg.locator('input[name=c_offer]').count() == 0                       # в демо нет оферты и согласий
    pg.click('form button[type=submit]'); wait(pg, 'Личный кабинет'); wait(pg, 'Не подключён')
    pg.fill('#codeIn', 'VOSCA-DEMO-TEST'); pg.click('form[data-form=redeem] button[type=submit]'); wait(pg, 'Подготовка к чтению'); ok('новый ученик: регистрация без согласий → код → курс открыт')
    pg.goto(F + '#/lesson/prep-1'); pg.wait_for_selector('#lessonFrame'); pg.wait_for_timeout(1500)
    assert pg.frame_locator('#lessonFrame').locator('body').inner_text().strip(); ok('урок открывается во фрейме внутри одного файла')
    pg.goto(F + '#/lesson/prep-2'); wait(pg, 'пока закрыт'); ok('следующий урок закрыт, пока не пройден первый')
    st = pg.evaluate("document.documentElement.scrollWidth"); 
    # сохранение между перезагрузками
    pg.reload(); wait(pg, 'Урок 2'.lower() if False else 'закрыт'); ok('состояние сохраняется после перезагрузки')
    mc = br.new_context(viewport={'width': 390, 'height': 800}, device_scale_factor=2, is_mobile=True, locale='ru-RU'); mp = mc.new_page(); mp.goto(F); wait(mp, 'С возвращением'); mp.click('[data-d=anna]'); wait(mp, 'Личный кабинет'); mp.wait_for_timeout(500)
    mp.screenshot(path=f'{SH}/d7_mobile.png', full_page=True); assert mp.evaluate('document.documentElement.scrollWidth') <= 392; ok('телефон: нет горизонтальной прокрутки')
    br.close()
bad = [e for e in errors if 'favicon' not in e and 'status of 403' not in e and 'permissions policy' not in e]
print('Ошибки консоли:', bad or 'нет'); print('Проверок:', n); sys.exit(1 if bad else 0)
