"""Обходит все экраны демо под тремя ролями и собирает всё, что осталось непереведённым.
   python3 test/i18n_crawl.py [файл_демо] [en]   — без аргументов: en, ошибка при любых остатках."""
import sys, os, re, json, pathlib, collections
from playwright.sync_api import sync_playwright
ROOT = pathlib.Path(__file__).resolve().parent.parent
DEMO = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/Vosca_Platform_Demo.html'
LANGS = sys.argv[2:] or ['en']
LESSON = str(ROOT / 'content' / 'lessons' / 'grammar-1.html')
LESSON_EN = str(ROOT / 'content' / 'lessons' / 'grammar-1.en.html')
CYR = re.compile('[Ѐ-ӿ]')

SCAN = """() => { const out = [];
  const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT); let n;
  while ((n = w.nextNode())) { const p = n.parentElement; if (p && !p.closest('[data-notr],script,style,textarea') && /[\\u0400-\\u04FF]/.test(n.nodeValue)) out.push(n.nodeValue.replace(/\\s+/g, ' ').trim()); }
  document.querySelectorAll('[placeholder],[title],[aria-label],[alt]').forEach(e => { if (e.closest('[data-notr]')) return; ['placeholder','title','aria-label','alt'].forEach(a => { const v = e.getAttribute(a); if (v && /[\\u0400-\\u04FF]/.test(v)) out.push('@' + a + ': ' + v); }); });
  if (/[\\u0400-\\u04FF]/.test(document.title)) out.push('@title-tag: ' + document.title);
  return out; }"""

def run(lang):
    seen = collections.OrderedDict(); errors = []
    with sync_playwright() as p:
        b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 1100, 'height': 900}); pg = ctx.new_page()
        ctx.add_init_script("try{localStorage.setItem('vosca_lang','%s')}catch(e){}" % lang)
        pg.on('pageerror', lambda e: errors.append('pageerror: ' + str(e)))
        pg.on('console', lambda m: errors.append('console: ' + m.text) if m.type == 'error' and 'permissions policy' not in m.text.lower() else None)
        def on_dialog(d):
            if CYR.search(d.message): seen.setdefault('[dialog] ' + d.message, 'dialog')
            d.accept()
        pg.on('dialog', on_dialog)
        if os.environ.get('TRACE'):
            ctx.add_init_script("(function(){const iv=setInterval(()=>{if(window.VOSCA_API&&!window.__w){window.__w=1;const o=window.VOSCA_API;window.VOSCA_API=async(m,u,b)=>{const r=await o(m,u,b);console.log('API '+m+' '+u+' '+r.status);return r;};clearInterval(iv);}},2);})();")
            pg.on('console', lambda m: print('   ~', m.text[:140]) if m.text.startswith('API') else None)
        pg.goto('file://' + DEMO); pg.wait_for_timeout(1200)

        def settle():
            for _ in range(30):
                if pg.evaluate("!document.querySelector('#app .loading')"): break
                pg.wait_for_timeout(100)
        def snap(label):
            if os.environ.get('TRACE'): print('# step', label, pg.evaluate('location.hash'), 'uid=', pg.evaluate("(()=>{try{const s=JSON.parse(localStorage.getItem('vosca_demo_v2'));return s&&s.uid+'/users:'+Object.keys(s.db.users||{}).length}catch(e){return 'ERR '+e}})()"))
            settle(); pg.wait_for_timeout(350)
            for s in pg.evaluate(SCAN): seen.setdefault(s, label)
            for s in pg.evaluate("[...VoscaI18n.miss]"): seen.setdefault(s, label)
        def go(h):
            cur = pg.evaluate('location.hash')
            if cur == h: pg.reload(); pg.wait_for_timeout(1000)
            else: pg.evaluate("h => { location.hash = h }", h); pg.wait_for_timeout(900)
            snap(h)
        def click(sel, label=None, wait=500, nth=0):
            try:
                loc = pg.locator(sel).nth(nth); loc.scroll_into_view_if_needed(timeout=2500); loc.click(timeout=2500); pg.wait_for_timeout(wait); snap(label or sel)
                return True
            except Exception as e:
                errors.append('click-miss %s: %s' % (sel, str(e).splitlines()[0])); return False
        def fill(sel, val):
            try: pg.locator(sel).first.fill(val, timeout=2500)
            except Exception as e: errors.append('fill-miss %s: %s @%s [%s]' % (sel, str(e).splitlines()[0], pg.evaluate('location.hash'), pg.evaluate("document.getElementById('app').innerText.slice(0,70)").replace('\n', ' / ')))
        def role(r):
            pg.locator('button[data-d=%s]' % r).click(); pg.wait_for_timeout(1000); snap('role:' + r)
        def modal_close():
            if pg.locator('.mback').count(): pg.keyboard.press('Escape'); pg.wait_for_timeout(250)

        # ── аноним ──
        go('#/login'); fill('form[data-form=login] input[name=email]', 'nobody@x.io'); fill('form[data-form=login] input[name=password]', 'wrongpass')
        click('form[data-form=login] button[type=submit]', 'login-error', 700)
        go('#/register'); fill('input[name=name]', 'Tester'); fill('input[name=email]', 'bad'); fill('input[name=password]', 'short')
        click('form[data-form=register] button[type=submit]', 'register-error1', 700)
        fill('input[name=email]', 'tester@example.com'); click('form[data-form=register] button[type=submit]', 'register-error2', 700)
        fill('input[name=password]', 'longenough1'); fill('input[name=name]', 'Tester'); click('form[data-form=register] button[type=submit]', 'register-nocode', 700)
        fill('input[name=code]', 'VOSCA-WRONG-CODE'); click('form[data-form=register] button[type=submit]', 'register-wrongcode', 900)
        fill('input[name=code]', 'VOSCA-DEMO-TEST'); click('form[data-form=register] button[type=submit]', 'registered', 1500)
        if os.environ.get('STOP') == 'reg': b.close(); return seen, errors
        go('#/cabinet'); go('#/club'); go('#/teachers'); click('a.tc2', 'teacher-open', 900); go('#/courses'); go('#/schedule'); go('#/homework'); go('#/course/thai'); go('#/lesson/prep-1')
        click('[data-act=focuscode]', 'focuscode') if pg.locator('[data-act=focuscode]').count() else None
        go('#/cabinet'); fill('#codeIn', 'WRONG-CODE'); click('form[data-form=redeem] button[type=submit]', 'redeem-wrong', 700)
        fill('#codeIn', 'VOSCA-DEMO-FREN'); click('form[data-form=redeem] button[type=submit]', 'redeem-ok', 1500)
        go('#/course/thai'); go('#/courses'); go('#/profile')
        click('.bell', 'bell', 600); click('[data-act=closebell]', 'bell-close') if pg.locator('[data-act=closebell]').count() else None
        # профиль: ошибки форм
        fill('form[data-form=password] input[name=old]', 'nope'); fill('form[data-form=password] input[name=password]', 'newpassword1'); click('form[data-form=password] button[type=submit]', 'pw-wrong', 700)
        fill('form[data-form=delacc] input[name=password]', 'longenough1'); click('form[data-form=delacc] button[type=submit]', 'delacc', 1200)

        # ── админ ──
        role('admin')
        go('#/admin'); click('tr.cl', 'admin-users-row', 900)
        go('#/admin/user/2') if False else None
        # карточка Анны: засчитать до 2-го урока, чтобы появились ДЗ
        pg.evaluate("location.hash='#/admin'"); pg.wait_for_timeout(800)
        pg.locator('tr.cl', has_text='anna@vosca.demo').first.click(); pg.wait_for_timeout(1000); snap('admin-user')
        click('[data-act=apass]', 'apass', 900, nth=1)
        click('[data-act=areset]', 'areset', 900, nth=0)
        click('[data-act=apass]', 'apass2', 900, nth=1)
        click('[data-act=unenroll]', 'unenroll', 800)
        click('form[data-form=enroll] button[type=submit]', 'enroll', 900)
        click('[data-act=admsess]', 'admsess-modal', 700); click('.modal button[type=submit]', 'admsess-submit', 900); modal_close()
        click('[data-act=setrole]', 'setrole', 600)
        fill('form[data-form=admpw] input[name=password]', 'short'); click('form[data-form=admpw] button[type=submit]', 'admpw-short', 700)
        fill('form[data-form=admpw] input[name=password]', 'newpassword1'); click('form[data-form=admpw] button[type=submit]', 'admpw', 700)
        click('[data-act=deluser]', 'deluser-modal', 600); modal_close()
        go('#/admin/teachers'); fill('form[data-form=newteacher] input[name=name]', 'Teacher T'); fill('form[data-form=newteacher] input[name=email]', 'x'); fill('form[data-form=newteacher] input[name=password]', 'short')
        click('form[data-form=newteacher] button[type=submit]', 'newteacher-err', 800)
        fill('form[data-form=newteacher] input[name=email]', 't@example.com'); fill('form[data-form=newteacher] input[name=password]', 'password123'); click('form[data-form=newteacher] button[type=submit]', 'newteacher-nolang', 800)
        pg.check('form[data-form=newteacher] input[name=langs][value=fr]'); click('form[data-form=newteacher] button[type=submit]', 'newteacher-ok', 1100)
        go('#/admin/schedule'); click('[data-act=admcancel]', 'admcancel', 800, nth=1) if pg.locator('[data-act=admcancel]').count() > 1 else None
        go('#/admin/codes'); pg.select_option('form[data-form=newcodes] select[name=course]', 'fr'); click('form[data-form=newcodes] button[type=submit]', 'codes-new', 900); click('[data-act=regcopy]', 'regcopy', 500); click('[data-act=codeoff]', 'codeoff', 800)
        go('#/admin/invites'); click('form[data-form=newinvites] button[type=submit]', 'invite-nolang', 800); pg.check('form[data-form=newinvites] input[name=langs][value=en]'); click('form[data-form=newinvites] button[type=submit]', 'invite-new', 900)
        go('#/admin/materials'); click('[data-act=amnew]', 'amat-new', 700); fill('form[data-form=matadd] input[name=title]', 'Школьный материал'); click('form[data-form=matadd] button[type=submit]', 'amat-nourl', 800)
        fill('form[data-form=matadd] input[name=url]', 'http://bad'); click('form[data-form=matadd] button[type=submit]', 'amat-badurl', 800)
        pg.check('form[data-form=matadd] input[name=kind][value=text]'); pg.wait_for_timeout(150); snap('amat-text'); pg.check('form[data-form=matadd] input[name=kind][value=file]'); pg.wait_for_timeout(150); click('form[data-form=matadd] button[type=submit]', 'amat-nofile', 800)
        pg.check('form[data-form=matadd] input[name=kind][value=text]'); fill('form[data-form=matadd] textarea[name=text]', 'Hello'); pg.check('form[data-form=matadd] input[name=audience]'); click('form[data-form=matadd] button[type=submit]', 'amat-ok', 1000)
        click('[data-act=matdel]', 'amat-del', 600); modal_close()
        go('#/admin/codes'); pg.select_option('form[data-form=newcodes] select[name=course]', 'thai'); pg.wait_for_timeout(200); snap('codes-thai-teacher')
        go('#/admin/club'); fill('form[data-form=subgrant] input[name=user]', 'nobody@x.io'); click('form[data-form=subgrant] button[type=submit]', 'club-grant-err', 800)
        fill('form[data-form=subgrant] input[name=user]', 'boris@vosca.demo'); pg.select_option('#submode', 'until'); pg.wait_for_timeout(150); snap('club-until')
        click('form[data-form=subgrant] button[type=submit]', 'club-grant-nodate', 800); pg.select_option('#submode', 'days'); click('form[data-form=subgrant] button[type=submit]', 'club-grant', 1200)
        click('[data-act=subext]', 'club-ext', 600); click('[data-act=subadd]', 'club-add', 900)
        click('[data-act=subext]', 'club-ext2', 600); click('.modal button[type=submit]', 'club-ext-empty', 700); modal_close()
        click('[data-act=subrev]', 'club-rev', 600); click('[data-act=subrev2]', 'club-rev2', 900)
        click('[data-act=newclub]', 'club-new', 700); click('.modal button[type=submit]', 'club-new-submit', 1100)
        click('[data-act=cmove]', 'club-move', 600); click('.modal button[type=submit]', 'club-move-submit', 900); modal_close()
        click('[data-act=ccancel]', 'club-cancel', 600); click('.modal button[type=submit]', 'club-cancel-submit', 900)
        click('[data-act=ckick]', 'club-kick', 700)
        go('#/admin'); pg.locator('tr.cl', has_text='anna@vosca.demo').first.click(); pg.wait_for_timeout(900); snap('admin-user-club')
        click('[data-act=subext2]', 'club-ext3', 600); modal_close()
        go('#/admin/teachers'); pg.locator('a.trow').first.click(); pg.wait_for_timeout(1000); snap('admin-teacher'); click('form[data-form=tlangs] button[type=submit]', 'tlangs-save', 900)
        fill('form[data-form=tprof] input[name=video]', 'http://bad'); click('form[data-form=tprof] button[type=submit]', 'tprof-badvideo', 800)
        fill('form[data-form=tprof] input[name=video]', ''); click('form[data-form=tprof] button[type=submit]', 'tprof-save', 800)
        go('#/admin/codes'); pg.select_option('form[data-form=newcodes] select[name=course]', 'club'); click('form[data-form=newcodes] button[type=submit]', 'codes-club', 900)
        go('#/admin/content')
        pg.set_input_files('#lessonFile', LESSON); click('[data-act=stagefile]', 'stagefile', 2500)
        fill('input[name=key]', 'x'); click('form[data-form=commit] button[type=submit]', 'commit-badkey', 900)
        fill('input[name=key]', 'grammar-1-copy'); pg.select_option('#mSel', '__new'); pg.wait_for_timeout(200)
        fill('input[name=moduleTitle]', 'Test module'); click('form[data-form=commit] button[type=submit]', 'commit', 1500)
        # английская версия: язык определяется по файлу, выбирается урок, к которому относится перевод
        pg.set_input_files('#lessonFile', LESSON_EN); click('[data-act=stagefile]', 'stagefile-en', 2500)
        pg.select_option('#lSel', 'ru'); pg.wait_for_timeout(200); snap('lang-ru-form'); pg.select_option('#lSel', 'en'); pg.wait_for_timeout(200); snap('lang-en-form')
        click('form[data-form=commit] button[type=submit]', 'commit-en', 1500)
        click('[data-act=lmove]', 'lmove', 700, nth=1); click('[data-act=lrem]', 'lrem-modal', 600); modal_close()
        click('[data-act=editcourse]', 'editcourse', 600); click('.modal button[type=submit]', 'editcourse-save', 800); modal_close()
        fill('form[data-form=course] input[name=id]', 'x'); click('form[data-form=course] button[type=submit]', 'course-badid', 700)
        go('#/admin/mail'); go('#/admin/legal')

        # ── преподаватель ──
        role('kim')
        go('#/teach'); click('[data-act=newsess]', 'newsess', 700); click('.modal button[type=submit]', 'newsess-submit', 900); modal_close()
        click('[data-act=tmove]', 'tmove', 600); click('.modal button[type=submit]', 'tmove-submit', 900); modal_close()
        click('[data-act=tcancel]', 'tcancel', 600); click('.modal button[type=submit]', 'tcancel-submit', 900); modal_close()
        click('[data-act=tdone]', 'tdone', 600); fill('.modal textarea', 'Good job'); click('.modal button[type=submit]', 'tdone-submit', 900); modal_close()
        click('[data-act=tnote]', 'tnote', 600); modal_close()
        go('#/teach'); click('[data-act=reqdec]', 'req-decline', 600); fill('.modal input[name=reason]', 'Busy'); click('.modal button[type=submit]', 'req-decline-submit', 900)
        go('#/teach/students'); click('[data-act=take]', 'take', 900); click('[data-act=stnew]', 'st-newsess', 700); modal_close(); click('[data-act=stmat]', 'st-mat', 700); click('.modal button[type=submit]', 'st-mat-send', 900); modal_close()
        go('#/teach/materials'); click('[data-act=matnew]', 'tmat-new', 700); fill('form[data-form=matadd] input[name=title]', 'Мой материал'); click('form[data-form=matadd] button[type=submit]', 'tmat-nourl', 800)
        pg.check('form[data-form=matadd] input[name=kind][value=text]'); fill('form[data-form=matadd] textarea[name=text]', 'Hello'); click('form[data-form=matadd] button[type=submit]', 'tmat-ok', 1000)
        click('[data-act=matshare]', 'tmat-share', 700); click('.modal button[type=submit]', 'tmat-share-none', 800); modal_close()
        click('[data-act=matunshare]', 'tmat-unshare', 800); click('[data-act=matdel]', 'tmat-del', 600); modal_close()
        go('#/teach/club'); fill('form[data-form=clublink] input[name=url]', 'http://bad'); click('form[data-form=clublink] button[data-notify="0"]', 'clublink-bad', 700); fill('form[data-form=clublink] input[name=url]', 'https://meet.google.com/new-club'); click('form[data-form=clublink] button[data-notify="1"]', 'clublink-save', 900); click('[data-act=lksend]', 'clublink-resend', 800)
        click('[data-act=newclub]', 'tclub-new', 700); click('.modal button[type=submit]', 'tclub-new-submit', 1100); modal_close()
        click('[data-act=cdone]', 'tclub-done', 800)
        go('#/teachers'); go('#/profile'); fill('form[data-form=tprof] input[name=video]', 'http://bad'); click('form[data-form=tprof] button[type=submit]', 'tprof-badvideo2', 800)
        fill('form[data-form=tprof] input[name=video]', ''); click('form[data-form=tprof] button[type=submit]', 'tprof-save2', 800)
        click('[data-act=tphotodel]', 'tphotodel', 800)
        fill('input[name=meeting_url]', 'http://bad'); click('form[data-form=profile] button[type=submit]', 'profile-badurl', 800)
        click('.bell', 'bell-teacher', 600)
        go('#/schedule'); go('#/cabinet')

        # ── ученица ──
        role('anna')
        go('#/cabinet'); go('#/club'); click('[data-act=cbook]', 'cbook', 900); click('[data-act=cunbook]', 'cunbook', 900); go('#/teachers'); click('a.tc2', 'teacher-open2', 900)
        go('#/materials')
        go('#/schedule'); click('[data-act=reqnew]', 'req-new', 700); click('.modal button[type=submit]', 'req-send', 1000); click('[data-act=reqcancel]', 'req-cancel', 800)
        go('#/teachers'); click('a.tc2', 'teacher-open3', 900); click('[data-act=reqnew]', 'req-new2', 700); modal_close()
        go('#/schedule'); click('[data-act=decline]', 'decline', 600); click('.modal button[type=submit]', 'decline-submit', 900); modal_close()
        go('#/homework'); go('#/course/thai'); go('#/lesson/prep-1'); go('#/lesson/grammar-1')
        go('#/homework')
        if pg.locator('a[href^="#/hw/"]').count():
            pg.locator('a[href^="#/hw/"]').first.click(); pg.wait_for_timeout(1100); snap('hw-open')
            n = pg.locator('.hwq').count()
            for i in range(n): pg.locator('.hwq').nth(i).locator('.op').first.click()
            pg.wait_for_timeout(300); snap('hw-answered'); click('#hwSubmit', 'hw-submit', 1000); click('[data-act=hwretry]', 'hw-retry', 900)
        go('#/hw/prep-1'); go('#/hw/nope'); go('#/lesson/nope'); go('#/nowhere'); go('#/course/nope'); go('#/legal/offer'); go('#/teach'); go('#/admin')
        click('.bell', 'bell-student', 600)
        go('#/profile'); fill('form[data-form=profile] input[name=name]', ''); click('form[data-form=profile] button[type=submit]', 'profile-noname', 700)
        # ── Борис: курсы без доступа ──
        pg.evaluate("DEMO.login('boris@vosca.demo')"); pg.evaluate("V.S.user=null;V.S.ov=null;V.S.checked=false"); go('#/cabinet'); go('#/courses'); go('#/course/thai'); go('#/lesson/prep-1'); go('#/schedule'); go('#/homework')
        # ── время ──
        role('admin'); click('button[data-d=t30]', 'time+30', 900); click('button[data-d=t1d]', 'time+1d', 900); go('#/admin/mail'); go('#/admin/schedule'); click('button[data-d=t0]', 'time0', 700)
        click('button[data-d=close]', 'bar-close', 300); click('button[data-d=open]', 'bar-open', 300)
        click('button[data-d=reset]', 'bar-reset', 1800)
        b.close()
    return seen, errors

if __name__ == '__main__':
    bad = 0
    for lang in LANGS:
        seen, errors = run(lang)
        seen = {k: v for k, v in seen.items() if '(grammar-1-copy)' not in k}      # загруженный в тесте русский урок без перевода — его название по определению русское
        print('═══ %s: непереведено %d' % (lang, len(seen)))
        by = collections.defaultdict(list)
        for s, lab in seen.items(): by[lab].append(s)
        for lab, items in by.items():
            print('── ' + lab)
            for s in items: print('   ' + json.dumps(s, ensure_ascii=False))
        e = [x for x in errors if not x.startswith('click-miss') or '--verbose' in sys.argv]
        for x in errors: print('   !', x)
        bad += len(seen) + len(errors)
    sys.exit(1 if bad else 0)
