'use strict';
/* Ученики преподавателя и материалы.  node --no-warnings test/materials.test.js */
const assert = require('node:assert/strict');
const path = require('node:path');
const crypto = require('node:crypto');
const { load } = require('../lib/loader');
const content = require('../lib/content').open(path.join(__dirname, '..', 'content'));
let clock = Date.UTC(2026, 9, 26, 9);
const env = { now: () => clock, random: Math.random, token: n => crypto.randomBytes(n).toString('base64url'),
  hashPassword: p => 'h:' + p, verifyPassword: (p, h) => h === 'h:' + p, dummyHash: () => 'h:?', baseUrl: () => 'https://app.test', dropSessions() { }, mailMode: () => 'log' };
const app = load().createApp({ db: {}, content, env, adminEmail: 'admin@test.io', cfg: { PASS_SCORE: 80, HW_SIZE: 8, HW_PASS: 70, MIN_LESSON_SECONDS: 0, AUTO_ENROLL: [], LEGAL: false } });
const call = (user, method, p, body) => app.handle({ method, path: p, body: body || {}, query: {}, user: user ? app.db().users[user.id] : null, ip: '1.1.1.1', ua: 't' });
const okc = r => { assert.equal(r.status, 200, JSON.stringify(r.body)); return r.body; };
let n = 0; const ok = s => { n++; console.log('  ✓', s); };
const admin = app.bootstrapAdmin('admin@test.io', 'adminpass1', 'Админ');
const code = (course, extra) => okc(call(admin, 'POST', '/api/admin/codes', Object.assign({ course, days: 60, max: 1 }, extra))).codes[0];
const stu = (name, email, cd) => app.db().users[okc(call(null, 'POST', '/api/register', { name, email, password: 'secret1234', code: cd })).user.id];
const teacher = (name, email, langs) => app.db().users[okc(call(admin, 'POST', '/api/admin/teachers', { name, email, langs, password: 'teacherpass1', meeting_url: 'https://meet.example.com/' + name })).teacher.id];
const kim = teacher('Ким', 'kim@x.io', ['thai']), marie = teacher('Мари', 'm@x.io', ['fr']);
const anna = stu('Анна', 'anna@x.io', code('thai')), fred = stu('Фред', 'fred@x.io', code('fr'));

/* ученики преподавателя */
let p = okc(call(kim, 'GET', '/api/teach/students'));
assert.deepEqual(p.free.map(s => s.name), ['Анна']); assert.equal(p.students.length, 0); ok('свободные ученики: преподаватель тайского видит ученика с тайским, но не французского');
assert.equal(call(marie, 'POST', '/api/teach/students/take', { student: anna.id, course: 'thai' }).status, 403);
okc(call(kim, 'POST', '/api/teach/students/take', { student: anna.id, course: 'thai' }));
p = okc(call(kim, 'GET', '/api/teach/students')); assert.equal(p.students[0].name, 'Анна'); assert.equal(p.free.length, 0);
assert.equal(call(kim, 'POST', '/api/teach/students/take', { student: anna.id, course: 'thai' }).status, 409);
assert.equal(okc(call(anna, 'GET', '/api/teachers')).teachers.find(t => t.name === 'Ким').mine, true); ok('«взять ученика»: закрепление, повторно нельзя, чужой язык нельзя');
const codeT = code('thai', { teacher: kim.id });
assert.equal(call(admin, 'POST', '/api/admin/codes', { course: 'thai', days: 30, teacher: marie.id }).status, 400, 'преподаватель не того языка');
const lena = stu('Лена', 'lena@x.io', codeT);
assert.equal(okc(call(kim, 'GET', '/api/teach/students')).students.some(s => s.name === 'Лена'), true);
assert.equal(okc(call(admin, 'GET', '/api/admin/codes')).codes.find(c => c.code === codeT).teacherName, 'Ким'); ok('код, выданный под преподавателя, закрепляет ученика при регистрации');

/* материалы */
const PDF = Buffer.from('%PDF-1.4 test').toString('base64');
let m1 = okc(call(kim, 'POST', '/api/materials', { kind: 'link', title: 'Тоны', url: 'https://example.com/tones', course: 'thai', desc: 'Видео про тоны' })).material;
let m2 = okc(call(kim, 'POST', '/api/materials', { kind: 'text', title: 'Заметка', text: 'Слова на тему «еда»', course: 'thai' })).material;
let m3 = okc(call(kim, 'POST', '/api/materials', { kind: 'file', title: 'Прописи', course: 'thai', file: { name: 'prописи.pdf', data: PDF } })).material;
assert.equal(m3.file.mime, 'application/pdf');
assert.equal(call(kim, 'POST', '/api/materials', { kind: 'file', title: 'x', course: 'thai', file: { name: 'a.exe', data: PDF } }).status, 400);
assert.equal(call(kim, 'POST', '/api/materials', { kind: 'file', title: 'x', course: 'thai', file: { name: 'a.pdf', data: Buffer.from('not a pdf').toString('base64') } }).status, 400);
assert.equal(call(kim, 'POST', '/api/materials', { kind: 'file', title: 'x', course: 'thai', file: { name: 'a.pdf', data: Buffer.alloc(3.5 * 1024 * 1024, 65).toString('base64') } }).status, 413);
assert.equal(call(kim, 'POST', '/api/materials', { kind: 'link', title: 'x', url: 'http://insecure', course: 'thai' }).status, 400);
assert.equal(call(kim, 'POST', '/api/materials', { kind: 'link', title: 'x', url: 'https://ok.com', course: 'fr' }).status, 403, 'чужой язык');
assert.equal(okc(call(kim, 'GET', '/api/teach/materials')).mine.length, 3); assert.equal(okc(call(marie, 'GET', '/api/teach/materials')).mine.length, 0);
ok('преподаватель добавляет ссылку, текст и файл; недопустимые файлы, большие файлы и чужой язык отклоняются');
const sm = okc(call(admin, 'POST', '/api/materials', { kind: 'link', title: 'Программа курса', url: 'https://school.example/prog', course: 'thai' })).material;
const fm = okc(call(admin, 'POST', '/api/materials', { kind: 'text', title: 'Фразы для знакомства', text: 'Bonjour!', course: 'fr', audience: 'all' })).material;
assert.deepEqual(okc(call(kim, 'GET', '/api/teach/materials')).school.map(x => x.title), ['Программа курса']);
assert.deepEqual(okc(call(marie, 'GET', '/api/teach/materials')).school.map(x => x.title), ['Фразы для знакомства']);
assert.deepEqual(okc(call(fred, 'GET', '/api/materials')).items.map(x => x.title), ['Фразы для знакомства']); assert.equal(okc(call(anna, 'GET', '/api/materials')).items.length, 0);
assert.equal(call(kim, 'POST', '/api/materials', { kind: 'link', title: 'x', url: 'https://a.io', course: 'thai', audience: 'all' }).status, 200);
ok('материалы школы: видят преподаватели нужного языка; «для учеников» — ученики этого языка');
assert.ok(app.db().notes[kim.id].some(x => x.kind === 'material'), 'преподавателю пришло уведомление');

/* отправка ученику */
assert.equal(call(kim, 'POST', `/api/materials/${m1.id}/share`, { students: [fred.id] }).status, 403, 'не своему ученику');
assert.equal(call(kim, 'POST', `/api/materials/${m1.id}/share`, { students: [] }).status, 400);
let sh = okc(call(kim, 'POST', `/api/materials/${m1.id}/share`, { students: [anna.id, lena.id], note: 'Посмотрите до пятницы' })); assert.equal(sh.shared, 2);
okc(call(kim, 'POST', `/api/materials/${m3.id}/share`, { students: [anna.id] })); okc(call(kim, 'POST', `/api/materials/${sm.id}/share`, { students: [anna.id] }));
const items = okc(call(anna, 'GET', '/api/materials')).items; assert.equal(items.length, 3); assert.equal(items.find(x => x.id === m1.id).note, 'Посмотрите до пятницы'); assert.equal(items.find(x => x.id === m1.id).url, 'https://example.com/tones');
assert.ok(app.db().notes[anna.id].some(x => x.kind === 'material'));
const f = okc(call(anna, 'GET', `/api/materials/${m3.id}/file`)); assert.equal(f.name, 'prописи.pdf'); assert.equal(Buffer.from(f.b64, 'base64').toString().slice(0, 4), '%PDF');
assert.equal(call(fred, 'GET', `/api/materials/${m3.id}/file`).status, 404, 'чужому файл не отдаём'); assert.equal(call(null, 'GET', `/api/materials/${m3.id}/file`).status, 401);
assert.equal(call(anna, 'POST', '/api/materials', { kind: 'text', title: 'x', text: 'y', course: 'thai' }).status, 403, 'ученик не добавляет'); assert.equal(call(anna, 'GET', '/api/teach/materials').status, 403);
okc(call(kim, 'POST', `/api/materials/${m1.id}/unshare`, { student: anna.id })); assert.equal(okc(call(anna, 'GET', '/api/materials')).items.some(x => x.id === m1.id), false);
ok('преподаватель отправляет материал только своим ученикам; ученик видит его с запиской и скачивает файл; отзыв доступа работает');

/* удаление */
assert.equal(call(marie, 'POST', `/api/materials/${m2.id}/delete`).status, 403); assert.equal(call(kim, 'POST', `/api/materials/${sm.id}/delete`).status, 403, 'материал школы учитель не удалит');
okc(call(kim, 'POST', `/api/materials/${m3.id}/delete`)); assert.equal(app.db().mfiles[m3.id], undefined); okc(call(admin, 'POST', `/api/materials/${sm.id}/delete`));
assert.equal(okc(call(admin, 'GET', '/api/admin/materials')).items.some(x => x.id === sm.id), false);
okc(call(admin, 'POST', `/api/admin/users/${kim.id}/delete`)); assert.equal(Object.values(app.db().materials).some(x => x.owner === kim.id), false); ok('удаление материалов и чистка при удалении аккаунта');
console.log('\nПроверки учеников и материалов пройдены:', n);
