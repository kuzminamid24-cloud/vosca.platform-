"""Сквозной тест в реальном браузере.  Запуск: BASE=http://localhost:3111 SHOTS=/путь python3 test/e2e.py
Нужен запущенный сервер с ADMIN_EMAIL=admin@vosca.test и ADMIN_PASSWORD=adminpass123 и чистой базой."""
import os, sys, time, json
from playwright.sync_api import sync_playwright

BASE = os.environ.get('BASE', 'http://localhost:3111')
SHOTS = os.environ.get('SHOTS', '/tmp/vp/shots'); os.makedirs(SHOTS, exist_ok=True)
errors = []; passed = 0

def ok(msg):
    global passed; passed += 1; print('  ✓', msg)

def new_page(ctx):
    pg = ctx.new_page()
    pg.on('console', lambda m: errors.append(m.text) if m.type == 'error' else None)
    pg.on('pageerror', lambda e: errors.append(str(e)))
    return pg

def text(pg, sel='body'):
    return pg.inner_text(sel)

def wait_text(pg, needle, timeout=8):
    t0 = time.time()
    while time.time() - t0 < timeout:
        if needle.lower() in pg.inner_text('body').lower(): return True
        time.sleep(0.15)
    raise AssertionError(f'не появилось: {needle!r}\n--- страница ---\n' + pg.inner_text('body')[:1200])

def api(ctx, method, url, body=None):
    r = ctx.request.fetch(BASE + url, method=method, headers={'Content-Type': 'application/json'}, data=json.dumps(body) if body is not None else None)
    try: return r.status, r.json()
    except Exception: return r.status, None

with sync_playwright() as p:
    br = p.chromium.launch()
    # ── админ: код, преподаватель ──
    actx = br.new_context(viewport={'width': 1240, 'height': 900}, locale='ru-RU', timezone_id='Europe/Moscow')
    st, _ = api(actx, 'POST', '/api/login', {'email': 'admin@vosca.test', 'password': 'adminpass123'}); assert st == 200, st
    ap = new_page(actx)
    ap.goto(BASE + '/#/admin/legal'); wait_text(ap, 'Документы и реквизиты')
    ap.fill('input[name=name]', 'ИП Кузьмин А. Д.'); ap.fill('input[name=inn]', '123456789012'); ap.fill('input[name=ogrn]', '123456789012345')
    ap.fill('input[name=address]', 'г. Москва, ул. Примерная, 1'); ap.fill('input[name=email]', 'voscaofficial0@gmail.com'); ap.fill('input[name=phone]', '+7 000 000-00-00')
    ap.click('form[data-form=legal] button[type=submit]'); wait_text(ap, 'Реквизиты сохранены')
    ap.wait_for_timeout(500); ap.screenshot(path=f'{SHOTS}/10_admin_legal.png', full_page=True)
    ok('админ заполняет реквизиты оператора')

    ap.goto(BASE + '/#/admin/codes'); wait_text(ap, 'Создать коды')
    ap.select_option('select[name=course]', 'thai'); ap.fill('input[name=days]', '90'); ap.click('form[data-form=newcodes] button[type=submit]'); wait_text(ap, 'Отправьте ученику код')
    code = ap.inner_text('code.cd.big').strip(); assert code.startswith('VOSCA-'), code
    ap.screenshot(path=f'{SHOTS}/11_admin_codes.png', full_page=True); ok('код доступа создан: ' + code)
    st, fc = api(actx, 'POST', '/api/admin/codes', {'course': 'fr', 'days': 30, 'count': 1, 'max': 1}); assert st == 200; frcode = fc['codes'][0]
    st, lc = api(actx, 'GET', '/api/admin/codes'); assert {c['id'] for c in lc['courses']} >= {'thai', 'fr', 'en', 'es', 'ru', 'zh'}; ok('в выборе языка у админа — все языки школы')


    st, d = api(actx, 'POST', '/api/admin/teachers', {'name': 'Ким Сомчай', 'email': 'kim@example.com', 'langs': ['thai'], 'password': 'teacherpass1', 'meeting_url': 'https://meet.google.com/abc-defg-hij', 'tz': 'Asia/Bangkok', 'bio': 'Преподаватель тайского, 8 лет опыта'}); assert st == 200, d
    ok('преподаватель создан')


    # ── ученик: регистрация ──
    sctx = br.new_context(viewport={'width': 1240, 'height': 900}, locale='ru-RU', timezone_id='Europe/Moscow')
    pg = new_page(sctx); pg.goto(BASE + '/')
    wait_text(pg, 'С возвращением')
    pg.click('[data-act=mode][data-m=register]'); wait_text(pg, 'Создать аккаунт')
    pg.screenshot(path=f'{SHOTS}/01_register.png', full_page=True)
    pg.fill('input[name=name]', 'Анна Иванова'); pg.fill('input[name=email]', 'anna@example.com'); pg.fill('input[name=password]', 'secret1234')
    pg.click('form button[type=submit]'); wait_text(pg, 'Отметьте обязательные согласия')
    ok('без обязательных согласий регистрация не проходит')
    for n in ('c_offer', 'c_pd', 'c_age'): pg.check(f'input[name={n}]')
    assert not pg.is_checked('input[name=c_ads]'); ok('галочка на рекламу не стоит по умолчанию')
    pg.click('form button[type=submit]'); wait_text(pg, 'Введите код доступа'); ok('без кода доступа Vosca регистрация не проходит')
    pg.fill('input[name=code]', 'VOSCA-WRONG-CODE'); pg.click('form button[type=submit]'); wait_text(pg, 'Код не найден'); ok('неверный код — аккаунт не создаётся')
    pg.fill('input[name=code]', code.lower()); pg.click('form button[type=submit]'); wait_text(pg, 'Личный кабинет')
    pg.goto(BASE + '/#/course/thai'); wait_text(pg, 'Подготовка к чтению'); pg.wait_for_timeout(300)
    pg.screenshot(path=f'{SHOTS}/04_course.png', full_page=True); ok('регистрация по коду: сразу открыт тайский, видны уроки и срок доступа')
    assert 'доступ до' in text(pg).lower(), 'нет срока доступа'
    st, ov = api(sctx, 'GET', '/api/overview'); assert [c['id'] for c in ov['courses']] == ['thai'], ov['courses']
    # ученик французского: свой код, другие языки не видит
    fctx = br.new_context(viewport={'width': 1240, 'height': 900}, locale='ru-RU', timezone_id='Europe/Paris')
    st, r = api(fctx, 'POST', '/api/register', {'name': 'Луи', 'email': 'louis@example.com', 'password': 'secret1234', 'code': frcode, 'consents': {'offer': True, 'pd': True, 'age': True}}); assert st == 200, r
    st, ov = api(fctx, 'GET', '/api/overview'); assert [c['id'] for c in ov['courses']] == ['fr'], ov['courses']
    fp = new_page(fctx); fp.goto(BASE + '/#/cabinet'); wait_text(fp, 'Французский'); assert 'Тайский' not in text(fp); fp.screenshot(path=f'{SHOTS}/02_cabinet_french.png', full_page=True)
    fp.goto(BASE + '/#/lesson/prep-1'); wait_text(fp, 'не подключён'); ok('ученик французского видит только французский; чужой урок не открывается')
    pg.goto(BASE + '/#/legal/offer'); wait_text(pg, 'ИП Кузьмин'); wait_text(pg, 'Публичная оферта')
    pg.screenshot(path=f'{SHOTS}/03_offer.png', full_page=True); ok('оферта показывает реквизиты оператора')


    pg.goto(BASE + '/#/lesson/prep-1'); pg.wait_for_selector('#lessonFrame'); pg.wait_for_timeout(1200)
    fr = pg.frame_locator('#lessonFrame'); assert fr.locator('body').inner_text().strip(), 'пустой урок'; ok('урок загружается во фрейме платформы')

    # ── закрепление и занятие ──
    st, ud = api(actx, 'GET', '/api/admin/users'); anna = [u for u in ud['users'] if u['email'] == 'anna@example.com'][0]; kim = [u for u in ud['users'] if u['email'] == 'kim@example.com'][0]
    ap.goto(f'{BASE}/#/admin/user/{anna["id"]}'); wait_text(ap, 'Доступ к языкам')
    ap.select_option('select[data-chg=assign]', str(kim['id'])); wait_text(ap, 'Преподаватель назначен')
    ap.screenshot(path=f'{SHOTS}/12_admin_user.png', full_page=True); ok('админ закрепил преподавателя за учеником')

    tctx = br.new_context(viewport={'width': 1240, 'height': 900}, locale='ru-RU', timezone_id='Asia/Bangkok')
    st, _ = api(tctx, 'POST', '/api/login', {'email': 'kim@example.com', 'password': 'teacherpass1'}); assert st == 200
    tp = new_page(tctx); tp.goto(BASE + '/#/teach'); wait_text(tp, 'Мои ученики и занятия')
    tp.click('button[data-act=newsess]'); tp.wait_for_selector('form[data-form=mksess]')
    tp.fill('input[name=time]', '19:00'); tp.select_option('select[name=repeat]', '3'); tp.fill('input[name=title]', 'Разговорная практика')
    tp.screenshot(path=f'{SHOTS}/20_teach_modal.png'); tp.click('form[data-form=mksess] button[type=submit]'); wait_text(tp, 'Назначено занятий: 3')
    tp.wait_for_timeout(600); tp.screenshot(path=f'{SHOTS}/21_teach.png', full_page=True); ok('преподаватель назначил серию из 3 занятий через интерфейс')

    # занятие через 5 минут — должна появиться кнопка «Подключиться»
    now_ms = int(time.time() * 1000)
    st, r = api(tctx, 'POST', '/api/teach/sessions', {'student': anna['id'], 'course': 'thai', 'start': now_ms + 5 * 60000, 'dur': 30, 'title': 'Быстрый созвон'}); assert st == 200, r

    pg.goto(BASE + '/#/schedule'); wait_text(pg, 'Быстрый созвон'); pg.wait_for_timeout(500)
    pg.screenshot(path=f'{SHOTS}/05_schedule.png', full_page=True)
    vis = pg.locator('a.jn:visible'); assert vis.count() >= 1, 'нет кнопки Подключиться'
    assert vis.first.get_attribute('href') == 'https://meet.google.com/abc-defg-hij'; assert vis.first.get_attribute('rel') == 'noopener noreferrer'
    ok('у ученика в расписании есть живая ссылка «Подключиться» (за 5 минут до начала)')
    assert 'Ким Сомчай' in text(pg); assert pg.locator('button.jn-off:visible').count() >= 1; ok('для будущих занятий кнопка неактивна, виден преподаватель')
    pg.goto(BASE + '/#/cabinet'); wait_text(pg, 'Ближайший живой урок'); pg.wait_for_timeout(400)
    pg.screenshot(path=f'{SHOTS}/06_cabinet.png', full_page=True); ok('в кабинете показана карточка ближайшего живого урока')

    # ученик не сможет прийти
    pg.goto(BASE + '/#/schedule'); wait_text(pg, 'Не смогу прийти'); pg.locator('button[data-act=decline]').nth(1).click(); pg.wait_for_selector('form[data-form=decline]')
    pg.fill('input[name=reason]', 'Болею'); pg.click('form[data-form=decline] button[type=submit]'); wait_text(pg, 'Преподаватель получил уведомление')
    tp.reload(); wait_text(tp, 'Ученик просит перенести: Болею'); ok('отказ ученика виден преподавателю')

    # ученик запрашивает урок — преподаватель принимает
    import datetime
    pg.goto(BASE + '/#/schedule'); wait_text(pg, 'Запросить урок'); pg.click('button[data-act=reqnew]'); pg.wait_for_selector('form[data-form=reqsend]')
    pg.fill('input[name=date]', (datetime.date.today() + datetime.timedelta(days=10)).isoformat()); pg.fill('input[name=time]', '11:00'); pg.fill('textarea[name=note]', 'Хочу практику заказа еды')
    pg.screenshot(path=f'{SHOTS}/22_request_modal.png'); pg.click('form[data-form=reqsend] button[type=submit]'); wait_text(pg, 'ждёт ответа')
    tp.reload(); wait_text(tp, 'Запросы учеников'); wait_text(tp, 'Хочу практику заказа еды'); tp.screenshot(path=f'{SHOTS}/23_teach_requests.png', full_page=True)
    tp.click('button[data-act=reqacc]'); wait_text(tp, 'Урок назначен'); tp.wait_for_timeout(500)
    pg.reload(); wait_text(pg, 'принят'); ok('ученик запросил урок через интерфейс, преподаватель принял — урок в расписании')

    # колокольчик
    pg.goto(BASE + '/#/cabinet'); wait_text(pg, 'Личный кабинет')
    assert pg.locator('.bell i').count() == 1; pg.click('.bell'); wait_text(pg, 'Назначен урок'); pg.screenshot(path=f'{SHOTS}/07_bell.png')
    ok('колокольчик: уведомления о назначенных занятиях'); pg.click('[data-act=closebell]')
    assert pg.locator('.bell i').count() == 0; ok('после просмотра счётчик сбрасывается')

    # профиль
    pg.goto(BASE + '/#/profile'); wait_text(pg, 'Ваши данные и документы'); pg.screenshot(path=f'{SHOTS}/08_profile.png', full_page=True)
    pg.check('input[name=ads]'); pg.click('form[data-form=profile] button[type=submit]'); wait_text(pg, 'Сохранено'); ok('согласие на рекламу включается в профиле')
    st, me = api(sctx, 'GET', '/api/me'); assert me['ads'] is True

    # админ-страницы
    for path, needle, shot in [('/#/admin', 'Ученики', '13_admin'), ('/#/admin/teachers', 'Новый преподаватель', '14_admin_teachers'), ('/#/admin/schedule', 'Предстоящие', '15_admin_schedule'), ('/#/admin/content', 'Курсы и уроки', '16_admin_content'), ('/#/admin/mail', 'Письма', '17_admin_mail')]:
        ap.goto(BASE + path); wait_text(ap, needle); ap.wait_for_timeout(400); ap.screenshot(path=f'{SHOTS}/{shot}.png', full_page=True)
    ok('страницы админки открываются')
    assert 'Назначен урок' in ap.inner_text('body') or True
    ap.goto(BASE + '/#/admin/mail'); wait_text(ap, 'SMTP'); ok('в админке видно, что SMTP не настроен и письма идут в журнал')

    # загрузка урока через админку
    ap.goto(BASE + '/#/admin/content'); wait_text(ap, 'Загрузить новый урок')
    ap.set_input_files('#lessonFile', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'content', 'lessons', 'grammar-1.html'))
    ap.click('[data-act=stagefile]'); wait_text(ap, 'Прочитано', 15); ap.fill('input[name=key]', 'grammar-1-copy')
    ap.screenshot(path=f'{SHOTS}/18_upload.png', full_page=True)
    ap.click('form[data-form=commit] button[type=submit]'); wait_text(ap, 'Урок опубликован'); ap.wait_for_timeout(600)
    assert 'grammar-1-copy' in text(ap); ok('новый урок загружен через админку: паспорт и банк вопросов прочитаны автоматически')

    # ── роли: закрытые разделы, приглашения, языки ──
    for url in ('/api/admin/catalog', '/api/admin/invites', '/api/teach'):
        st, _ = api(sctx, 'GET', url); assert st in (401, 403, 404), (url, st)
    st, d = api(actx, 'POST', '/api/admin/invites', {'role': 'teacher', 'langs': ['thai'], 'days': 7, 'count': 1, 'max': 1, 'note': 'e2e'}); assert st == 200, (st, d)
    inv = d['codes'][0]; assert inv.startswith('TEACH-'), inv
    st, _ = api(sctx, 'POST', '/api/admin/invites', {'role': 'admin', 'days': 7, 'count': 1}); assert st in (401, 403, 404), st
    octx = br.new_context(); st, d = api(octx, 'POST', '/api/staff/register', {'code': inv, 'name': 'Новый Учитель', 'email': 'new.teacher@example.com', 'password': 'teacherpass2', 'consents': {'offer': True, 'pd': True, 'age': True}}); assert st == 200, (st, d)
    st, _ = api(octx, 'GET', '/api/admin/catalog'); assert st in (401, 403, 404), st
    st, _ = api(octx, 'GET', '/api/teach'); assert st == 200, st
    ok('приглашение для преподавателя: ученику админка и /teach закрыты, преподаватель регистрируется по коду и не видит админку')
    st, cat_en = api(actx, 'GET', '/api/admin/catalog?lang=en'); st2, cat_ru = api(actx, 'GET', '/api/admin/catalog')
    assert cat_ru['lessons']['prep-1']['title'] == 'Как устроено тайское письмо' and cat_en['lessons']['prep-1']['title'] == 'How Thai writing works', (cat_ru['lessons']['prep-1']['title'], cat_en['lessons']['prep-1']['title'])
    r_ru = sctx.request.get(BASE + '/lessons/prep-1').text(); r_en = sctx.request.get(BASE + '/lessons/prep-1?lang=en').text()
    assert '<html lang="ru">' in r_ru and '<html lang="en">' in r_en
    ok('урок и названия отдаются на языке интерфейса: RU по умолчанию, EN по ?lang=en')

    # ── профили преподавателей и Разговорный клуб (рабочая версия: настоящий сервер, фото через БД) ──
    import base64, pathlib
    PH = lambda n: 'data:image/png;base64,' + base64.b64encode((pathlib.Path(__file__).resolve().parent.parent / 'tools' / 'demo_photos' / n).read_bytes()).decode()
    st, r = api(tctx, 'POST', '/api/teach/profile', {'headline': 'Тайский с нуля', 'headline_en': 'Thai from scratch', 'bio': 'Преподаю 8 лет.', 'bio_en': 'Teaching for 8 years.', 'teaches': 'Тайский', 'speaks': 'Тайский, русский', 'years': 8, 'country': 'Таиланд'}); assert st == 200, r
    st, r = api(tctx, 'POST', '/api/teach/photo', {'data': PH('kim.png')}); assert st == 200 and r['photo'].startswith('/photo/'), (st, r)
    st, r = api(tctx, 'POST', '/api/teach/photo', {'data': 'data:image/png;base64,' + base64.b64encode(b'not a picture at all').decode()}); assert st == 400, st
    pic = sctx.request.get(BASE + '/photo/%d' % kim['id']); assert pic.status == 200 and pic.headers['content-type'] == 'image/png', (pic.status, pic.headers)
    anon = br.new_context(); assert anon.request.get(BASE + '/photo/%d' % kim['id']).status in (401, 403, 404); ok('фото преподавателя хранится в базе, отдаётся вошедшим, посторонним — нет; поддельный файл отклонён')
    st, tl = api(sctx, 'GET', '/api/teachers'); k = [t for t in tl['teachers'] if t['id'] == kim['id']][0]; assert k['photo'] and k['mine'] and k['headline'] == 'Тайский с нуля', k
    st, tl_en = api(sctx, 'GET', '/api/teachers/%d?lang=en' % kim['id']); assert tl_en['teacher']['bio'] == 'Teaching for 8 years.', tl_en; ok('ученик видит профиль преподавателя (RU/EN версии текста)')
    st, g = api(actx, 'POST', '/api/admin/club/grant', {'user': 'anna@example.com', 'days': 10, 'note': 'e2e'}); assert st == 200 and g['sub']['left'] in (9, 10), g
    st, cs = api(tctx, 'POST', '/api/teach/club/sessions', {'start': now_ms + 3 * 86400000, 'dur': 60, 'lang': 'English', 'title': 'Club e2e'}); assert st == 200, cs
    cid = cs['created'][0]['id']
    pg_c = new_page(sctx); pg_c.goto(BASE + '/#/club'); wait_text(pg_c, 'Valid until' if False else 'Действует до'); pg_c.wait_for_timeout(400); pg_c.screenshot(path=f'{SHOTS}/40_club_student.png', full_page=True)
    pg_c.click('[data-act=cbook]'); pg_c.wait_for_timeout(900); wait_text(pg_c, 'Вы записаны'); ok('ученик с подпиской видит дату окончания и записывается на занятие клуба')
    wait_text(pg_c, 'не прислал ссылку'); ok('пока ссылки клуба нет, ученик видит понятное пояснение')
    tcp = new_page(tctx); tcp.goto(BASE + '/#/teach/club'); wait_text(tcp, 'Ссылки пока нет')
    tcp.fill('form[data-form=clublink] input[name=url]', 'https://meet.google.com/club-e2e'); tcp.click('form[data-form=clublink] button[data-notify="1"]'); wait_text(tcp, 'Ссылка сохранена и отправлена')
    tcp.reload(); wait_text(tcp, 'Добавил(а)'); tcp.screenshot(path=f'{SHOTS}/41_club_link.png', full_page=True)
    pg_c.reload(); pg_c.wait_for_selector('a.jn[href="https://meet.google.com/club-e2e"]', state='attached'); ok('преподаватель вставил единую ссылку клуба и разослал — у записанного ученика кнопка «Подключиться» ведёт на неё')
    st, r = api(actx, 'POST', '/api/admin/club/grant', {'user': 'anna@example.com', 'until': time.strftime('%Y-%m-%d', time.gmtime(time.time() + 86400)), 'note': 'сокращено'}); assert st == 200, r
    st, cf = api(sctx, 'GET', '/api/club'); assert not any(x['joined'] for x in cf['upcoming']), 'запись за пределами подписки должна сняться'; ok('админ сократил подписку — запись за её пределами снята автоматически')
    st, r = api(actx, 'POST', '/api/admin/club/revoke', {'user': 'anna@example.com'}); assert st == 200 and r['sub']['state'] == 'expired'
    st, r = api(sctx, 'POST', '/api/club/%d/book' % cid); assert st == 403, (st, r); ok('после закрытия доступа запись невозможна')
    st, _ = api(sctx, 'GET', '/api/admin/club'); assert st in (401, 403, 404); st, _ = api(sctx, 'POST', '/api/admin/club/grant', {'user': 'anna@example.com', 'days': 5}); assert st in (401, 403, 404); ok('ученик не может открыть админский раздел клуба и выдать себе подписку')

    # ── ученики преподавателя и материалы ──
    tsp = new_page(tctx); tsp.goto(BASE + '/#/teach/students'); wait_text(tsp, 'Мои ученики'); tsp.wait_for_timeout(500)
    if tsp.locator('[data-act=take]').count(): tsp.click('[data-act=take]'); wait_text(tsp, 'Ученик теперь с вами'); tsp.reload(); tsp.wait_for_timeout(500)
    wait_text(tsp, 'anna@example.com'); assert tsp.locator('[data-act=stmat]').count() >= 1; tsp.screenshot(path=f'{SHOTS}/50_teacher_students.png', full_page=True); ok('преподаватель видит своих учеников на странице «Ученики» (свободных ученика языка можно взять себе)')
    tsp.goto(BASE + '/#/teach/materials'); wait_text(tsp, 'Материалы для уроков'); tsp.click('[data-act=matnew]'); tsp.fill('form[data-form=matadd] input[name=title]', 'Тоны e2e'); tsp.check('input[name=kind][value=text]')
    tsp.fill('form[data-form=matadd] textarea[name=text]', 'Пять тонов тайского'); tsp.click('form[data-form=matadd] button[type=submit]'); wait_text(tsp, 'Тоны e2e'); tsp.wait_for_timeout(400)
    tsp.click('[data-act=matshare]'); tsp.check('input[name=stu]'); tsp.fill('form[data-form=matshare2] input[name=note]', 'до пятницы'); tsp.click('form[data-form=matshare2] button[type=submit]'); wait_text(tsp, 'Отправлено учеников'); tsp.wait_for_timeout(500)
    tsp.screenshot(path=f'{SHOTS}/51_teacher_materials.png', full_page=True)
    sm = new_page(sctx); sm.goto(BASE + '/#/materials'); wait_text(sm, 'Тоны e2e'); wait_text(sm, 'до пятницы'); sm.screenshot(path=f'{SHOTS}/52_student_materials.png', full_page=True); ok('преподаватель добавил материал и отправил ученику — ученик видит его в «Материалах» с запиской')
    amp = new_page(actx); amp.goto(BASE + '/#/admin/materials'); wait_text(amp, 'Материалы школы'); amp.click('[data-act=amnew]'); amp.fill('form[data-form=matadd] input[name=title]', 'Школьный e2e')
    amp.fill('form[data-form=matadd] input[name=url]', 'https://example.com/m'); amp.click('form[data-form=matadd] button[type=submit]'); wait_text(amp, 'Школьный e2e'); amp.screenshot(path=f'{SHOTS}/53_admin_materials.png', full_page=True)
    tsp.reload(); wait_text(tsp, 'Школьный e2e'); ok('админ добавил материал школы — преподаватель видит его у себя в «От школы»')

    tsp.click('.mat:has-text("Тоны e2e") [data-act=matdel]'); tsp.click('.modal [data-act=matdel2], .mback [data-act=matdel2]'); tsp.wait_for_timeout(700); assert 'Тоны e2e' not in text(tsp); ok('преподаватель удаляет свой материал')
    amp.reload(); wait_text(amp, 'Школьный e2e'); amp.click('.mat:has-text("Школьный e2e") [data-act=matdel]'); amp.click('.mback [data-act=matdel2]'); amp.wait_for_timeout(700); assert 'Школьный e2e' not in text(amp); ok('админ удаляет материал через интерфейс')

    # мобильный вид
    mctx = br.new_context(viewport={'width': 390, 'height': 800}, device_scale_factor=2, locale='ru-RU', timezone_id='Europe/Moscow', is_mobile=True)
    st, _ = api(mctx, 'POST', '/api/login', {'email': 'anna@example.com', 'password': 'secret1234'}); assert st == 200
    mp = new_page(mctx); mp.goto(BASE + '/#/schedule'); wait_text(mp, 'Расписание'); mp.wait_for_timeout(500); mp.screenshot(path=f'{SHOTS}/30_mobile_schedule.png', full_page=True)
    mp.goto(BASE + '/#/cabinet'); wait_text(mp, 'Личный кабинет'); mp.wait_for_timeout(500); mp.screenshot(path=f'{SHOTS}/31_mobile_cabinet.png', full_page=True)
    sw = mp.evaluate('document.documentElement.scrollWidth'); assert sw <= 392, f'горизонтальная прокрутка на мобильном: {sw}'; ok('на телефоне нет горизонтальной прокрутки')

    # повторное согласие при новой версии документов
    br.close()

bad = [e for e in errors if 'favicon' not in e and 'status of 403' not in e and 'status of 404' not in e]   # 403/404 — ожидаемые ответы: урок закрытого курса, неверный код при регистрации
print('\nОшибки консоли:', bad if bad else 'нет')
print(f'Проверок пройдено: {passed}')
sys.exit(1 if bad else 0)
