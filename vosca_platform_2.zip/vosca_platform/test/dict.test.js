'use strict';
/* Полнота словаря переводов.  node --no-warnings test/dict.test.js */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
global.window = {}; 
new Function('window', fs.readFileSync(path.join(__dirname, '..', 'public', 'i18n-dict.js'), 'utf8'))(global.window);
const d = global.window.VOSCA_DICT;
assert.ok(Array.isArray(d) && d.length > 400, 'словарь пуст');
const seen = new Set(); let n = 0;
for (const [ru, en, ...extra] of d) {
  assert.ok(ru && en, 'нет перевода: ' + ru); assert.equal(extra.length, 0, 'лишний столбец: ' + ru);
  assert.ok(!seen.has(ru), 'дубль: ' + ru); seen.add(ru);
  if (typeof en === 'string') {
    const toks = s => (s.match(/\{#?\d+\}/g) || []).map(t => t.replace('#', '')).sort().join();
    const need = (ru.match(/\{#?\d+\}/g) || []).map(t => t.replace('#', '')).sort().join();
    assert.equal(toks(en), need, 'подстановки EN: ' + ru);
    assert.ok(!/[А-Яа-я]/.test(en), 'кириллица в EN: ' + ru);
  }
  n++;
}
console.log(`  ✓ словарь: ${n} записей, у каждой есть EN, без дублей и потерянных подстановок`);
