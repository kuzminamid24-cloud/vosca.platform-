'use strict';
/* Режим «чистое демо» (LEGAL=false): регистрация без оферты и согласий, документы недоступны.  node --no-warnings test/legal_off.test.js */
const assert = require('node:assert/strict');
const path = require('node:path');
const crypto = require('node:crypto');
const { load } = require('../lib/loader');
const content = require('../lib/content').open(path.join(__dirname, '..', 'content'));
const env = { now: () => Date.UTC(2026, 9, 26, 9), random: Math.random, token: n => crypto.randomBytes(n).toString('base64url'),
  hashPassword: p => 'h:' + p, verifyPassword: (p, h) => h === 'h:' + p, dummyHash: () => 'h:?', baseUrl: () => 'https://app.test', dropSessions() { }, mailMode: () => 'log' };
const mk = legal => load().createApp({ db: {}, content, env, adminEmail: 'admin@test.io', cfg: { PASS_SCORE: 80, HW_SIZE: 8, HW_PASS: 70, MIN_LESSON_SECONDS: 0, AUTO_ENROLL: [], REQUIRE_CODE: false, LEGAL: legal } });
const call = (app, user, method, p, body) => app.handle({ method, path: p, body: body || {}, query: {}, user: user ? app.db().users[user.id] : null, ip: '1.2.3.4', ua: 't' });
let n = 0; const ok = s => { n++; console.log('  ✓', s); };

const off = mk(false);
let r = call(off, null, 'POST', '/api/register', { name: 'Анна', email: 'a@x.io', password: 'secret1234', tz: 'Europe/Moscow' });
assert.equal(r.status, 200, JSON.stringify(r.body));
const u = off.db().users[r.login];
assert.equal(off.db().consents.length, 0);
assert.equal(call(off, u, 'GET', '/api/me').body.config.legal, false);
assert.equal(call(off, null, 'GET', '/api/legal/offer').status, 404);
assert.equal(call(off, u, 'GET', '/api/overview').status, 200);
ok('LEGAL=off: регистрация без согласий, журнал пуст, документы 404, кабинет работает');

const on = mk(true);
r = call(on, null, 'POST', '/api/register', { name: 'Анна', email: 'a@x.io', password: 'secret1234', tz: 'Europe/Moscow' });
assert.equal(r.status, 400);
assert.equal(call(on, null, 'GET', '/api/legal/offer').status, 200);
ok('LEGAL=on: без согласий регистрация отклоняется, документы отдаются');
console.log(`\nПроверки режима демо пройдены: ${n}`);
