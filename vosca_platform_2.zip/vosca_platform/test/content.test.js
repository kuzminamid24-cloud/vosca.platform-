'use strict';
/* Языковые версии уроков: EN-файлы подаются по языку, банк вопросов совпадает с русским, перевод проверяется при загрузке.
   node --no-warnings test/content.test.js */
const assert = require('node:assert/strict');
const fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const src = path.join(__dirname, '..', 'content');
const content = require('../lib/content').open(src);
let n = 0; const ok = s => { n++; console.log('  ✓', s); };

const keys = content.courses().flatMap(c => (c.modules || []).flatMap(m => m.lessons));
assert.ok(keys.length >= 12);
for (const k of keys) {
  assert.deepEqual(content.langs(k), ['ru', 'en'], k + ': должны быть ru и en');
  const ru = content.html(k, 'ru').toString('utf8'), en = content.html(k, 'en').toString('utf8');
  assert.match(ru, /<html lang="ru">/); assert.match(en, /<html lang="en">/);
  assert.notEqual(ru, en);
  assert.equal(content.html(k).toString('utf8'), ru, 'без языка — русская версия');
  assert.equal(content.html(k, 'th').toString('utf8'), ru, 'неизвестный язык — русская версия');
  const bru = content.bank(k, 'ru'), ben = content.bank(k, 'en');
  assert.equal(bru.length, ben.length);
  bru.forEach((q, i) => { assert.equal(q.id, ben[i].id); assert.equal(q.a, ben[i].a); assert.equal(q.opts.length, ben[i].opts.length); assert.ok(!/[А-Яа-яЁё]/.test(ben[i].q + ben[i].opts.join('') + ben[i].why), k + ' ' + q.id + ': кириллица в EN-банке'); });
}
ok('все ' + keys.length + ' уроков доступны на ru и en, банки совпадают по id/числу вариантов/верному ответу, в EN-банке нет кириллицы');

/* загрузка перевода: проверка совпадения вопросов (на копии, чтобы не трогать содержимое) */
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'vosca-content-'));
fs.mkdirSync(path.join(tmp, 'lessons'));
fs.copyFileSync(path.join(src, 'courses.json'), path.join(tmp, 'courses.json'));
for (const f of ['prep-1.html', 'prep-1.json']) fs.copyFileSync(path.join(src, 'lessons', f), path.join(tmp, 'lessons', f));
const c2 = require('../lib/content').open(tmp);
assert.deepEqual(c2.langs('prep-1'), ['ru']); assert.equal(c2.html('prep-1', 'en').toString('utf8'), c2.html('prep-1').toString('utf8'));
const good = content.bank('prep-1', 'en'), html = content.html('prep-1', 'en');
assert.throws(() => c2.commit({ key: 'prep-1', lang: 'en', html, meta: { title: 'x' }, bank: good.slice(1) }), /не совпадают/);
assert.throws(() => c2.commit({ key: 'prep-1', lang: 'en', html, meta: { title: 'x' }, bank: good.map((q, i) => i ? q : { ...q, a: (q.a + 1) % q.opts.length }) }), /не совпадают/);
assert.throws(() => c2.commit({ key: 'prep-1', lang: 'en', html, meta: { title: 'x' }, bank: good.map((q, i) => i ? q : { ...q, opts: q.opts.slice(1) }) }), /не совпадают/);
assert.throws(() => c2.commit({ key: 'new-one', lang: 'en', html, meta: { title: 'x' }, bank: good }), /русскую версию/);
assert.throws(() => c2.commit({ key: 'prep-1', lang: 'de', html, meta: { title: 'x' }, bank: good }), /Неизвестный язык/);
c2.commit({ key: 'prep-1', lang: 'en', html, meta: { title: 'How Thai writing works' }, bank: good });
assert.deepEqual(c2.langs('prep-1'), ['ru', 'en']); assert.equal(c2.html('prep-1', 'en').toString('utf8'), html.toString('utf8'));
ok('перевод принимается только при тех же вопросах; без русской версии и для неизвестного языка — отказ');
fs.rmSync(tmp, { recursive: true, force: true });
console.log(n + ' проверок content ОК');
