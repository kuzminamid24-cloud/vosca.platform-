'use strict';
/* Запросы на урок и видимость курсов.  node --no-warnings test/requests.test.js */
const assert = require('node:assert/strict');
const path = require('node:path');
const crypto = require('node:crypto');
const { load } = require('../lib/loader');
const content = require('../lib/content').open(path.join(__dirname, '..', 'content'));
let clock = Date.UTC(2026, 9, 26, 9);
const env = { now: () => clock, random: Math.random, token: n => crypto.randomBytes(n).toString('base64url'),
  hashPassword: p => 'h:' + p, verifyPassword: (p, h) => h === 'h:' + p, dummyHash: () => 'h:?', baseUrl: () => 'https://app.test', dropSessions() { }, mailMode: () => 'log' };
const app = load().createApp({ db: {}, content, env, adminEmail: 'admin@test.io', cfg: { PASS_SCORE: 80, HW_SIZE: 8, HW_PASS: 70, MIN_LESSON_SECONDS: 0, AUTO_ENROLL: [], REQUIRE_CODE: false, LEGAL: false } });
const call = (user, method, p, body) => app.handle({ method, path: p, body: body || {}, query: {}, user: user ? app.db().users[user.id] : null, ip: '1.1.1.1', ua: 't' });
const okc = r => { assert.equal(r.status, 200, JSON.stringify(r.body)); return r.body; };
let n = 0; const ok = s => { n++; console.log('  ✓', s); };
const HOUR = 36e5, DAY = 864e5;
const admin = app.bootstrapAdmin('admin@test.io', 'adminpass1', 'Админ');
const mk = (name, email) => app.db().users[call(null, 'POST', '/api/register', { name, email, password: 'secret1234' }).login];
const anna = mk('Анна', 'anna@x.io'), boris = mk('Борис', 'boris@x.io');
const teacher = (name, email) => app.db().users[okc(call(admin, 'POST', '/api/admin/teachers', { name, email, langs: ['thai'], password: 'teacherpass1', meeting_url: 'https://meet.example.com/' + name })).teacher.id];
const kim = teacher('Ким', 'kim@x.io'), nari = teacher('Нари', 'nari@x.io');

/* видимость курсов */
let ov = okc(call(anna, 'GET', '/api/overview'));
assert.ok(ov.courses.length > 1, 'без курсов ученик видит каталог'); ok('новый ученик без курсов видит каталог, чтобы понять, что можно получить');
okc(call(admin, 'POST', `/api/admin/users/${anna.id}/enroll`, { course: 'thai', days: 90 }));
ov = okc(call(anna, 'GET', '/api/overview'));
assert.deepEqual(ov.courses.map(c => c.id), ['thai']); ok('у ученика есть тайский — другие языки не показываются');
assert.ok(okc(call(admin, 'GET', `/api/admin/users/${anna.id}`)).courses.length > 1); ok('админ в карточке ученика по-прежнему видит все курсы');
assert.ok(okc(call(boris, 'GET', '/api/overview')).courses.length > 1);

/* запрос на урок */
const start = clock + 30 * HOUR;
assert.equal(call(boris, 'POST', '/api/live/request', { teacher: kim.id, course: 'thai', start }).status, 400, 'без доступа к курсу — нельзя');
assert.equal(call(anna, 'POST', '/api/live/request', { teacher: kim.id, course: 'thai', start: clock + 10 * 60000 }).status, 400, 'ближе чем через час — нельзя');
assert.equal(call(anna, 'POST', '/api/live/request', { teacher: anna.id, course: 'thai', start }).status, 400, 'нельзя «запросить» ученика');
let r = okc(call(anna, 'POST', '/api/live/request', { teacher: kim.id, course: 'thai', start, dur: 50, note: 'после работы' })).request;
assert.equal(r.status, 'pending');
assert.equal(call(anna, 'POST', '/api/live/request', { teacher: kim.id, course: 'thai', start: start + 10 * 60000 }).status, 409, 'дубль почти на то же время');
let sc = okc(call(anna, 'GET', '/api/schedule')); assert.equal(sc.requests.length, 1); assert.ok(sc.reqTeachers.find(t => t.id === kim.id)); assert.deepEqual(sc.reqCourses.map(c => c.id), ['thai']);
assert.ok(okc(call(kim, 'GET', '/api/teach')).requests.some(x => x.id === r.id && x.student.name === 'Анна')); assert.equal(okc(call(nari, 'GET', '/api/teach')).requests.length, 0, 'чужой запрос не виден');
assert.ok(app.db().notes && JSON.stringify(app.db().notes).includes('Запрос на урок')); ok('ученик отправляет запрос, преподаватель видит его в кабинете и получает уведомление');
assert.equal(call(nari, 'POST', `/api/teach/requests/${r.id}/accept`).status, 403, 'чужой преподаватель не принимает');
assert.equal(call(anna, 'POST', `/api/teach/requests/${r.id}/accept`).status, 403, 'ученик не принимает свой запрос');
const acc = okc(call(kim, 'POST', `/api/teach/requests/${r.id}/accept`, {}));
assert.equal(acc.request.status, 'accepted'); assert.equal(acc.created[0].starts, start);
sc = okc(call(anna, 'GET', '/api/schedule')); assert.ok(sc.upcoming.find(s => s.starts === start && s.teacher.id === kim.id)); assert.equal(app.db().assign[anna.id].thai, kim.id, 'преподаватель закреплён за курсом');
assert.equal(call(kim, 'POST', `/api/teach/requests/${r.id}/accept`).status, 409, 'повторно нельзя');
assert.equal(call(anna, 'POST', '/api/live/request', { teacher: kim.id, course: 'thai', start: start + 20 * 60000 }).status, 409, 'это время теперь занято'); ok('преподаватель принимает — урок появляется в расписании ученика, ученик закрепляется за преподавателем');

/* отклонение, отмена, чужой преподаватель, истечение */
const start2 = clock + 50 * HOUR;
const r2 = okc(call(anna, 'POST', '/api/live/request', { teacher: nari.id, course: 'thai', start: start2 })).request;
assert.equal(call(kim, 'POST', `/api/teach/requests/${r2.id}/decline`, { reason: 'x' }).status, 403);
okc(call(nari, 'POST', `/api/teach/requests/${r2.id}/decline`, { reason: 'занята в это время' }));
sc = okc(call(anna, 'GET', '/api/schedule')); assert.equal(sc.requests.find(x => x.id === r2.id).status, 'declined'); assert.match(sc.requests.find(x => x.id === r2.id).reason, /занята/);
assert.ok(JSON.stringify(app.db().notes[anna.id]).includes('отклонён'));
const r3 = okc(call(anna, 'POST', '/api/live/request', { teacher: nari.id, course: 'thai', start: start2 })).request;
okc(call(anna, 'POST', `/api/live/request/${r3.id}/cancel`)); assert.equal(call(anna, 'POST', `/api/live/request/${r3.id}/cancel`).status, 409);
assert.equal(call(boris, 'POST', `/api/live/request/${r3.id}/cancel`).status, 403);
const r4 = okc(call(anna, 'POST', '/api/live/request', { teacher: nari.id, course: 'thai', start: start2 + 5 * DAY })).request;
clock += 8 * DAY; app.tick(); assert.equal(app.db().req[r4.id].status, 'expired'); ok('отклонение с причиной, отмена учеником, чужие права, просроченные запросы закрываются сами');
for (let i = 0; i < 6; i++) { const rr = call(anna, 'POST', '/api/live/request', { teacher: nari.id, course: 'thai', start: clock + (40 + i * 24) * HOUR }); if (i < 5) assert.equal(rr.status, 200, JSON.stringify(rr.body)); else assert.equal(rr.status, 429); }
ok('не больше пяти ожидающих запросов у одного ученика');
console.log('\nПроверки запросов на урок пройдены:', n);
