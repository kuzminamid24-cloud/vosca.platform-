'use strict';
/* Роли и приглашения: отдельные входы, коды для преподавателей/админов, закрытые разделы.  node --no-warnings test/roles.test.js */
const assert = require('node:assert/strict');
const path = require('node:path');
const crypto = require('node:crypto');
const { load } = require('../lib/loader');
const content = require('../lib/content').open(path.join(__dirname, '..', 'content'));
let clock = Date.UTC(2026, 9, 26, 9);
const env = { now: () => clock, random: Math.random, token: n => crypto.randomBytes(n).toString('base64url'),
  hashPassword: p => 'h:' + p, verifyPassword: (p, h) => h === 'h:' + p, dummyHash: () => 'h:?', baseUrl: () => 'https://app.test', dropSessions() { }, mailMode: () => 'log' };
const app = load().createApp({ db: {}, content, env, adminEmail: 'admin@test.io', cfg: { PASS_SCORE: 80, HW_SIZE: 8, HW_PASS: 70, MIN_LESSON_SECONDS: 0, AUTO_ENROLL: [], REQUIRE_CODE: false, LEGAL: false } });
const call = (user, method, p, body) => app.handle({ method, path: p, body: body || {}, query: {}, user: user ? app.db().users[user.id] : null, ip: '1.1.1.1', ua: 't' });
const okc = r => { assert.equal(r.status, 200, JSON.stringify(r.body)); return r.body; };
let n = 0; const ok = s => { n++; console.log('  ✓', s); };
const admin = app.bootstrapAdmin('admin@test.io', 'adminpass1', 'Админ');
const stu = (() => { const r = call(null, 'POST', '/api/register', { name: 'Анна', email: 'anna@x.io', password: 'secret1234' }); return app.db().users[r.login]; })();

/* приглашение для преподавателя */
const [code] = okc(call(admin, 'POST', '/api/admin/invites', { role: 'teacher', langs: ['thai'], days: 7, count: 1, max: 2, note: 'Ким' })).codes;
assert.match(code, /^TEACH-[A-Z0-9]{4}-[A-Z0-9]{4}$/);
assert.equal(okc(call(null, 'POST', '/api/staff/check', { code: code.toLowerCase() })).role, 'teacher');
assert.equal(call(null, 'POST', '/api/staff/check', { code: 'TEACH-NOPE-NOPE' }).status, 404);
let r = call(null, 'POST', '/api/staff/register', { code, name: 'Ким', email: 'kim@x.io', password: 'short' }); assert.equal(r.status, 400);
r = call(null, 'POST', '/api/staff/register', { code, name: 'Ким', email: 'kim@x.io', password: 'secret1234' }); okc(r);
const kim = app.db().users[r.login]; assert.equal(kim.role, 'teacher');
assert.equal(call(null, 'POST', '/api/staff/register', { code, name: 'Х', email: 'anna@x.io', password: 'secret1234' }).status, 409);   // email занят
const kim2 = okc(call(null, 'POST', '/api/staff/register', { code, name: 'Лек', email: 'lek@x.io', password: 'secret1234' }));
assert.equal(call(null, 'POST', '/api/staff/register', { code, name: 'Третий', email: 'third@x.io', password: 'secret1234' }).status, 409);   // использований 2
assert.ok(okc(call(admin, 'GET', '/api/admin/invites')).invites.find(i => i.code === code).state === 'used');
assert.ok(app.db().notes[admin.id].some(x => /присоединился/.test(x.title)));
ok('преподаватель регистрируется по коду приглашения; лимит использований, занятый email, админ получает уведомление');

/* срок действия и выключение */
const [c2] = okc(call(admin, 'POST', '/api/admin/invites', { role: 'teacher', langs: ['thai'], days: 1 })).codes;
clock += 2 * 864e5; assert.equal(call(null, 'POST', '/api/staff/register', { code: c2, name: 'Х', email: 'late@x.io', password: 'secret1234' }).status, 410);
const [c3] = okc(call(admin, 'POST', '/api/admin/invites', { role: 'teacher', langs: ['thai'] })).codes; okc(call(admin, 'POST', `/api/admin/invites/${c3}/off`));
assert.equal(call(null, 'POST', '/api/staff/check', { code: c3 }).status, 404);
ok('просроченное и выключенное приглашения не работают');

/* админ-приглашение: одноразовое */
const [ca] = okc(call(admin, 'POST', '/api/admin/invites', { role: 'admin', max: 50 })).codes; assert.match(ca, /^ADMIN-/);
const adm2 = app.db().users[okc(Object.assign({}, call(null, 'POST', '/api/staff/register', { code: ca, name: 'Второй', email: 'a2@x.io', password: 'secret1234' }))).user.id];
assert.equal(adm2.role, 'admin'); assert.equal(call(null, 'POST', '/api/staff/check', { code: ca }).status, 409);
ok('код администратора одноразовый, даже если указали больше использований');

/* кто может создавать приглашения */
assert.equal(call(stu, 'POST', '/api/admin/invites', { role: 'teacher', langs: ['thai'] }).status, 403);
assert.equal(call(kim, 'POST', '/api/admin/invites', { role: 'teacher', langs: ['thai'] }).status, 403);
assert.equal(call(kim, 'GET', '/api/admin/invites').status, 403);
assert.equal(call(null, 'POST', '/api/admin/invites', { role: 'teacher', langs: ['thai'] }).status, 401);
ok('приглашения создаёт только администратор');

/* отдельные входы */
const L = (email, portal) => call(null, 'POST', '/api/login', { email, password: 'secret1234', portal });
assert.equal(L('anna@x.io', 'student').status, 200); assert.equal(L('kim@x.io', 'teacher').status, 200);
r = L('kim@x.io', 'student'); assert.equal(r.status, 403); assert.equal(r.body.wrongPortal, 'teacher');
r = L('anna@x.io', 'admin'); assert.equal(r.status, 403); assert.equal(r.body.wrongPortal, 'student');
assert.equal(call(null, 'POST', '/api/login', { email: 'admin@test.io', password: 'adminpass1', portal: 'teacher' }).status, 403);
assert.equal(call(null, 'POST', '/api/login', { email: 'admin@test.io', password: 'adminpass1', portal: 'admin' }).status, 200);
assert.equal(call(null, 'POST', '/api/login', { email: 'kim@x.io', password: 'wrongpass1', portal: 'student' }).status, 401);   // роль не раскрывается без верного пароля
ok('у каждой роли свой вход; чужой аккаунт получает понятный отказ, роль не раскрывается без пароля');

/* ученик не видит чужие разделы на сервере */
['/api/admin/users', '/api/admin/codes', '/api/admin/invites', '/api/admin/outbox', '/api/admin/settings', '/api/admin/sessions'].forEach(p => assert.equal(call(stu, 'GET', p).status, 403, p));
assert.equal(call(stu, 'GET', '/api/teach').status, 403); assert.equal(call(stu, 'POST', '/api/teach/sessions', {}).status, 403);
assert.equal(call(kim, 'GET', '/api/admin/users').status, 403); assert.equal(call(kim, 'GET', '/api/teach').status, 200);
assert.equal(call(stu, 'POST', `/api/admin/users/${kim.id}/role`, { role: 'student' }).status, 403);
ok('ученик закрыт от админки и панели преподавателя, преподаватель — от админки');
console.log(`\nПроверки ролей пройдены: ${n}`);
