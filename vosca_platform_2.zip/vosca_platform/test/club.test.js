'use strict';
/* Профили преподавателей и Разговорный клуб: подписка с датой окончания, запись, права, напоминания.  node --no-warnings test/club.test.js */
const assert = require('node:assert/strict');
const path = require('node:path');
const crypto = require('node:crypto');
const { load } = require('../lib/loader');
const content = require('../lib/content').open(path.join(__dirname, '..', 'content'));
let clock = Date.UTC(2026, 9, 26, 9);                      // пн 26.10.2026 12:00 МСК
const env = { now: () => clock, random: Math.random, token: n => crypto.randomBytes(n).toString('base64url'),
  hashPassword: p => 'h:' + p, verifyPassword: (p, h) => h === 'h:' + p, dummyHash: () => 'h:?', baseUrl: () => 'https://app.test', dropSessions() { }, mailMode: () => 'log' };
const app = load().createApp({ db: {}, content, env, adminEmail: 'admin@test.io', cfg: { PASS_SCORE: 80, HW_SIZE: 8, HW_PASS: 70, MIN_LESSON_SECONDS: 0, AUTO_ENROLL: [], REQUIRE_CODE: false, LEGAL: false } });
const call = (user, method, p, body, query) => app.handle({ method, path: p, body: body || {}, query: query || {}, user: user ? app.db().users[user.id] : null, ip: '1.1.1.1', ua: 't' });
const okc = r => { assert.equal(r.status, 200, JSON.stringify(r.body)); return r.body; };
let n = 0; const ok = s => { n++; console.log('  ✓', s); };
const DAY = 864e5, HOUR = 36e5;
const admin = app.bootstrapAdmin('admin@test.io', 'adminpass1', 'Админ');
const mkStudent = (name, email) => { const r = call(null, 'POST', '/api/register', { name, email, password: 'secret1234' }); return app.db().users[r.login]; };
const anna = mkStudent('Анна', 'anna@x.io'), boris = mkStudent('Борис', 'boris@x.io');
const kim = (() => { okc(call(admin, 'POST', '/api/admin/teachers', { name: 'Ким', email: 'kim@x.io', langs: ['thai'], password: 'teacherpass1', meeting_url: 'https://meet.example.com/kim' })); return Object.values(app.db().users).find(u => u.email === 'kim@x.io'); })();
const sub = (u) => okc(call(u, 'GET', '/api/club')).sub;

/* ── профиль и фото преподавателя ── */
let r = okc(call(kim, 'POST', '/api/teach/profile', { headline: 'Английский и разговорная практика', headline_en: 'English & conversation', bio: 'Преподаю 6 лет.', bio_en: 'Teaching for six years.', speaks: 'English, Thai, Russian', years: 6, country: 'Thailand', video: 'https://youtu.be/abc' }));
assert.equal(r.years, 6); assert.equal(r.country, 'Thailand');
assert.equal(call(kim, 'POST', '/api/teach/profile', { video: 'http://x.io' }).status, 400);
assert.equal(call(kim, 'POST', '/api/teach/profile', { hidden: true }).status, 403, 'скрыть профиль может только админ');
assert.equal(call(anna, 'POST', '/api/teach/profile', { bio: 'x' }).status, 403, 'ученик не правит профили');
let t = okc(call(anna, 'GET', '/api/teachers')).teachers.find(x => x.id === kim.id);
assert.equal(t.headline, 'Английский и разговорная практика'); assert.equal(t.photo, '');
t = okc(call(anna, 'GET', '/api/teachers/' + kim.id, {}, { lang: 'en' })).teacher; assert.match(t.bio, /six|шесть|6/);
assert.equal(okc(call(anna, 'GET', '/api/teachers/' + kim.id)).teacher.mine, false);
const jpeg = 'data:image/jpeg;base64,' + Buffer.concat([Buffer.from([0xFF, 0xD8, 0xFF, 0xE0, 0, 16, 0x4A, 0x46, 0x49, 0x46, 0, 1, 1, 0, 0, 1]), Buffer.alloc(200, 7)]).toString('base64');
assert.match(okc(call(kim, 'POST', '/api/teach/photo', { data: jpeg })).photo, /^\/photo\/\d+\?v=\d+$/);
assert.equal(call(kim, 'POST', '/api/teach/photo', { data: 'data:image/jpeg;base64,' + Buffer.from('this is not a picture at all').toString('base64') }).status, 400, 'подмена типа файла');
assert.equal(call(kim, 'POST', '/api/teach/photo', { data: 'data:image/svg+xml;base64,PHN2Zy8+' }).status, 400, 'svg не принимаем');
assert.equal(call(kim, 'POST', '/api/teach/photo', { data: 'data:image/jpeg;base64,' + Buffer.concat([Buffer.from([0xFF, 0xD8, 0xFF]), Buffer.alloc(210 * 1024)]).toString('base64') }).status, 413, 'слишком большое');
assert.equal(app.photoOf(kim.id).mime, 'image/jpeg'); assert.ok(app.photoOf(kim.id).buf.length > 100);
assert.ok(okc(call(anna, 'GET', '/api/teachers')).teachers.find(x => x.id === kim.id).photo.startsWith('/photo/'));
okc(call(admin, 'POST', '/api/teach/profile', { teacher: kim.id, hidden: true }));
assert.equal(okc(call(anna, 'GET', '/api/teachers')).teachers.find(x => x.id === kim.id), undefined, 'скрытый не виден ученикам');
assert.equal(call(anna, 'GET', '/api/teachers/' + kim.id).status, 404);
okc(call(admin, 'POST', '/api/teach/profile', { teacher: kim.id, hidden: false, name: 'Ким Сомчай' }));
assert.equal(okc(call(anna, 'GET', '/api/teachers')).teachers.find(x => x.id === kim.id).name, 'Ким Сомчай');
assert.equal(okc(call(anna, 'GET', '/api/teachers')).teachers.find(x => x.id === admin.id), undefined, 'админ без профиля не в списке');
ok('профиль: поля, фото (проверка типа/размера/подмены), скрытие админом, видимость ученикам');

/* ── подписка на клуб ── */
assert.equal(sub(anna).state, 'none');
assert.equal(call(anna, 'POST', '/api/admin/club/grant', { user: anna.id, days: 30 }).status, 403, 'ученик сам себе подписку не выдаст');
const start = clock + 2 * DAY + 5 * HOUR;
const sess = okc(call(kim, 'POST', '/api/teach/club/sessions', { start, dur: 60, cap: 2, lang: 'English', level: 'A2', title: 'Travel talk' })).created[0];
assert.equal(sess.cap, 2); assert.equal(sess.taken, 0);
let up = okc(call(anna, 'GET', '/api/club')).upcoming; assert.equal(up.length, 1); assert.equal(up[0].block, 'nosub'); assert.equal(up[0].url, undefined, 'ссылка скрыта до записи');
let e = call(anna, 'POST', `/api/club/${sess.id}/book`); assert.equal(e.status, 403); assert.equal(e.body.club, 'nosub');
let g = okc(call(admin, 'POST', '/api/admin/club/grant', { user: 'anna@x.io', days: 10 })).sub;
assert.equal(g.state, 'active'); assert.ok(g.until > clock + 9 * DAY && g.until <= clock + 11 * DAY); assert.equal(g.left, 10);
ok('подписка: ученик без подписки не может записаться; админ выдаёт на N дней (по email)');
const booked = okc(call(anna, 'POST', `/api/club/${sess.id}/book`)); assert.equal(booked.joined, true); assert.equal(booked.url, '', 'пока ссылку не прислали — её нет');
assert.equal(okc(call(anna, 'GET', '/api/club')).linkSet, false);
/* единая ссылка клуба: вставляет преподаватель клуба */
assert.equal(call(anna, 'POST', '/api/teach/club/link', { url: 'https://meet.example.com/club' }).status, 403, 'ученик ссылку менять не может');
assert.equal(call(kim, 'POST', '/api/teach/club/link', { url: 'http://insecure.example.com' }).status, 400);
const before = app.db().outbox.length;
let lk = okc(call(kim, 'POST', '/api/teach/club/link', { url: 'https://meet.example.com/club', notify: true }));
assert.equal(lk.sent, 1, 'рассылка записанным'); assert.equal(lk.link.by, app.db().users[kim.id].name); assert.ok(app.db().outbox.length > before);
assert.equal(okc(call(anna, 'GET', '/api/club')).linkSet, true);
assert.equal(okc(call(anna, 'GET', '/api/club')).upcoming[0].url, 'https://meet.example.com/club'); assert.equal(okc(call(boris, 'GET', '/api/club')).upcoming[0].url, undefined, 'не записанному ссылка не видна');
assert.equal(okc(call(kim, 'GET', '/api/teach/club')).link.url, 'https://meet.example.com/club');
lk = okc(call(kim, 'POST', '/api/teach/club/link', { url: 'https://meet.example.com/club', notify: true })); assert.equal(lk.sent, 0, 'без изменений — повторно не шлём');
assert.equal(okc(call(kim, 'POST', '/api/teach/club/link/send')).sent, 1);
ok('единая ссылка клуба: ставит преподаватель, видна только записанным, обновляется во всех занятиях, рассылается участникам');
assert.equal(call(anna, 'POST', `/api/club/${sess.id}/book`).status, 409, 'двойная запись');
okc(call(admin, 'POST', '/api/admin/club/grant', { user: boris.id, days: 60 }));
const sess2 = okc(call(kim, 'POST', '/api/teach/club/sessions', { start: start + 3 * HOUR, dur: 60, cap: 2 })).created[0];
okc(call(boris, 'POST', `/api/club/${sess.id}/book`));
const carol = mkStudent('Кэрол', 'carol@x.io'); okc(call(admin, 'POST', '/api/admin/club/grant', { user: carol.id, lifetime: true }));
e = call(carol, 'POST', `/api/club/${sess.id}/book`); assert.equal(e.status, 409); assert.match(e.body.error, /места/);
assert.equal(okc(call(carol, 'GET', '/api/club')).upcoming.find(s => s.id === sess.id).block, 'full');
okc(call(anna, 'POST', `/api/club/${sess.id}/unbook`)); okc(call(carol, 'POST', `/api/club/${sess.id}/book`));
ok('запись: лимит мест, отмена записи освобождает место, ссылка видна только записанным');
assert.equal(call(anna, 'GET', '/api/teach/club').status, 403);
const panel = okc(call(kim, 'GET', '/api/teach/club')); assert.equal(panel.upcoming[0].members.length, 2); assert.ok(panel.upcoming[0].members[0].email);
assert.equal(okc(call(boris, 'GET', '/api/club')).upcoming[0].members, undefined, 'ученики не видят список участников');
ok('преподаватель видит участников, ученик — только число');

/* ── окончание подписки ── */
const sess3 = okc(call(kim, 'POST', '/api/teach/club/sessions', { start: start + 6 * HOUR, dur: 60, cap: 5 })).created[0];
okc(call(admin, 'POST', '/api/admin/club/grant', { user: anna.id, until: new Date(clock + 3 * DAY).toISOString().slice(0, 10) }));   // подписка Анны закончится раньше занятия (через 2д 5ч)... проверим границу ниже
const sA = sub(anna); assert.ok(sA.until > clock + 2 * DAY && sA.active);
okc(call(admin, 'POST', '/api/admin/club/grant', { user: anna.id, until: new Date(clock + DAY).toISOString().slice(0, 10) }));
e = call(anna, 'POST', `/api/club/${sess3.id}/book`); assert.equal(e.status, 403); assert.equal(e.body.club, 'late'); assert.match(e.body.error, /заканчивается/);
okc(call(admin, 'POST', '/api/admin/club/grant', { user: anna.id, days: 5 }));
okc(call(anna, 'POST', `/api/club/${sess3.id}/book`));                                                    // записана на sess
okc(call(admin, 'POST', '/api/admin/club/grant', { user: anna.id, until: new Date(clock + DAY).toISOString().slice(0, 10) }));            // админ сократил подписку — запись за её пределами снимается
assert.equal(okc(call(kim, 'GET', '/api/teach/club')).upcoming.find(s => s.id === sess3.id).members.some(m => m.id === anna.id), false, 'запись за пределами подписки снята');
assert.ok(app.db().notes[anna.id].some(x => x.kind === 'club_trim'));
ok('админ сокращает подписку → записи за её пределами снимаются, ученик уведомлён; запись «позже даты окончания» запрещена');
okc(call(admin, 'POST', '/api/admin/club/grant', { user: anna.id, days: 30 }));
okc(call(anna, 'POST', `/api/club/${sess2.id}/book`));
const rv = okc(call(admin, 'POST', '/api/admin/club/revoke', { user: anna.id })).sub; assert.equal(rv.active, false); assert.equal(rv.state, 'expired');
assert.equal(okc(call(kim, 'GET', '/api/teach/club')).upcoming.find(s => s.id === sess2.id).members.length, 0);
assert.equal(call(anna, 'POST', `/api/club/${sess2.id}/book`).status, 403);
ok('отзыв подписки: статус «закончилась», все будущие записи сняты');

/* ── напоминания о конце подписки ── */
okc(call(admin, 'POST', '/api/admin/club/grant', { user: anna.id, days: 9 }));
const kinds = () => (app.db().notes[anna.id] || []).filter(x => /^club_(w7|d1|exp)$/.test(x.kind)).map(x => x.kind).sort();
assert.deepEqual(kinds(), []); const outbox0 = app.db().outbox.length;
clock += 2.5 * DAY; app.tick(); assert.deepEqual(kinds(), ['club_w7'], 'за 7 дней'); app.tick(); assert.deepEqual(kinds(), ['club_w7'], 'повторно не шлём');
assert.equal(sub(anna).state, 'expiring'); assert.ok(sub(anna).left <= 7);
clock += 5.6 * DAY; app.tick(); assert.deepEqual(kinds(), ['club_d1', 'club_w7'], 'за день');
clock += 1.5 * DAY; app.tick(); assert.deepEqual(kinds(), ['club_d1', 'club_exp', 'club_w7'], 'в день окончания');
assert.equal(sub(anna).state, 'expired'); assert.ok(app.db().outbox.length > outbox0, 'письма поставлены в очередь');
ok('напоминания: за 7 дней, за 1 день, при окончании — по одному разу, с письмом');
okc(call(admin, 'POST', '/api/admin/club/grant', { user: anna.id, days: 30 })); assert.equal(sub(anna).state, 'active'); ok('после продления статус снова «активна»');

/* ── код доступа на клуб ── */
assert.equal(call(admin, 'POST', '/api/admin/codes', { course: 'club' }).status, 400, 'у кода на клуб должен быть срок');
const [code] = okc(call(admin, 'POST', '/api/admin/codes', { course: 'club', days: 14, count: 1, max: 1 })).codes;
assert.equal(okc(call(admin, 'GET', '/api/admin/codes')).codes.find(c => c.code === code).courseTitle, 'Разговорный клуб');
const dan = mkStudent('Дэн', 'dan@x.io'); const rr = okc(call(dan, 'POST', '/api/redeem', { code })); assert.equal(rr.club, true);
assert.equal(sub(dan).state, 'active'); assert.equal(sub(dan).source, 'code'); assert.ok(sub(dan).until > clock + 13 * DAY);
assert.equal(call(mkStudent('Эми', 'amy@x.io'), 'POST', '/api/redeem', { code }).status, 409, 'код одноразовый');
ok('код доступа на клуб: открывает подписку на N дней, одноразовый');

/* ── обзор админа, кабинет, календарь ── */
const ov = okc(call(admin, 'GET', '/api/admin/club'));
assert.ok(ov.stats.active >= 3 && ov.stats.lifetime === 1); assert.ok(ov.subs.find(x => x.email === 'carol@x.io').lifetime); assert.ok(ov.students.length >= 5);
assert.equal(call(kim, 'GET', '/api/admin/club').status, 403, 'преподаватель не видит админку клуба');
assert.equal(okc(call(dan, 'GET', '/api/overview')).club.state, 'active');
assert.match(app.icsByToken(app.db().users[carol.id].cal), /Разговорный клуб|Travel talk/);
const det = okc(call(admin, 'GET', '/api/admin/users/' + dan.id)); assert.equal(det.club.state, 'active'); assert.equal(det.clubHist[0].act, 'grant');
assert.equal(okc(call(admin, 'GET', '/api/admin/users/' + kim.id)).profile.years, 6);
ok('админ: обзор подписчиков и статистика, карточка ученика с историей, календарь содержит занятия клуба');

/* ── отмена занятия, удаление аккаунта ── */
const sx = okc(call(kim, 'POST', '/api/teach/club/sessions', { start: clock + 2 * DAY, dur: 60, cap: 3 })).created[0], sy = okc(call(kim, 'POST', '/api/teach/club/sessions', { start: clock + 3 * DAY, dur: 60, cap: 3 })).created[0];
okc(call(carol, 'POST', `/api/club/${sx.id}/book`)); const nb = (app.db().notes[carol.id] || []).length;
okc(call(kim, 'POST', `/api/teach/club/sessions/${sx.id}/cancel`, { reason: 'Болею' }));
assert.ok((app.db().notes[carol.id] || []).length > nb && app.db().notes[carol.id][0].kind === 'club_cancelled');
assert.equal(okc(call(carol, 'GET', '/api/club')).upcoming.some(s => s.id === sx.id), false);
okc(call(dan, 'POST', `/api/club/${sy.id}/book`)); okc(call(dan, 'POST', '/api/account/delete', { password: 'secret1234' }));
assert.equal(app.db().subs[dan.id], undefined); assert.ok(!app.db().club[sy.id].members.includes(dan.id));
ok('отмена занятия уведомляет записанных; удаление аккаунта убирает подписку и записи');
console.log('\nПроверки клуба и профилей пройдены: ' + n);
