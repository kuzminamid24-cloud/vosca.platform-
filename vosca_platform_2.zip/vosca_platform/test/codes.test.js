'use strict';
/* Регистрация по коду доступа, коды на любые языки, языки преподавателей.  node --no-warnings test/codes.test.js */
const assert = require('node:assert/strict');
const path = require('node:path');
const crypto = require('node:crypto');
const { load } = require('../lib/loader');
const content = require('../lib/content').open(path.join(__dirname, '..', 'content'));
let clock = Date.UTC(2026, 9, 26, 9);
const env = { now: () => clock, random: Math.random, token: n => crypto.randomBytes(n).toString('base64url'),
  hashPassword: p => 'h:' + p, verifyPassword: (p, h) => h === 'h:' + p, dummyHash: () => 'h:?', baseUrl: () => 'https://app.test', dropSessions() { }, mailMode: () => 'log' };
const app = load().createApp({ db: {}, content, env, adminEmail: 'admin@test.io', cfg: { PASS_SCORE: 80, HW_SIZE: 8, HW_PASS: 70, MIN_LESSON_SECONDS: 0, AUTO_ENROLL: [], LEGAL: false } });
const call = (user, method, p, body) => app.handle({ method, path: p, body: body || {}, query: {}, user: user ? app.db().users[user.id] : null, ip: '1.1.1.1', ua: 't' });
const okc = r => { assert.equal(r.status, 200, JSON.stringify(r.body)); return r.body; };
let n = 0; const ok = s => { n++; console.log('  ✓', s); };
const HOUR = 36e5;
const admin = app.bootstrapAdmin('admin@test.io', 'adminpass1', 'Админ');
const users = () => Object.keys(app.db().users).length;
const reg = (name, email, code) => call(null, 'POST', '/api/register', { name, email, password: 'secret1234', code });
const U = r => app.db().users[okc(r).user.id];

/* без кода и с неверным кодом аккаунт не создаётся */
const before = users();
let r = reg('Анна', 'anna@x.io'); assert.equal(r.status, 400); assert.match(r.body.error, /код доступа/i);
r = reg('Анна', 'anna@x.io', 'VOSCA-XXXX-YYYY'); assert.equal(r.status, 404);
assert.equal(users(), before); ok('регистрация без кода или с неверным кодом не создаёт аккаунт');

/* коды на разные языки, в списке — все языки школы */
const lst = okc(call(admin, 'GET', '/api/admin/codes'));
assert.deepEqual(lst.courses.map(c => c.id).sort(), ['en', 'es', 'fr', 'ru', 'thai', 'zh']); ok('админ видит все языки школы при выпуске кода');
const [thCode] = okc(call(admin, 'POST', '/api/admin/codes', { course: 'thai', days: 90, count: 1, max: 1 })).codes;
const [frCode] = okc(call(admin, 'POST', '/api/admin/codes', { course: 'fr', days: 60, count: 1, max: 1 })).codes;
assert.ok(okc(call(admin, 'GET', '/api/admin/codes')).codes.find(c => c.code === frCode).courseTitle.includes('Французский'));

const anna = U(reg('Анна', 'anna@x.io', thCode)), fred = U(reg('Фред', 'fred@x.io', frCode.toLowerCase().replace(/-/g, ' - ')));
assert.deepEqual(okc(call(anna, 'GET', '/api/overview')).courses.map(c => c.id), ['thai']);
assert.deepEqual(okc(call(fred, 'GET', '/api/overview')).courses.map(c => c.id), ['fr']); ok('код тайского открывает только тайский, код французского — только французский; ученики не пересекаются');
assert.equal(reg('Третий', 'third@x.io', thCode).status, 409); ok('одноразовый код нельзя использовать повторно, аккаунт при этом не создаётся');
assert.equal(call(anna, 'GET', '/api/course/fr').status === 200 && okc(call(anna, 'GET', '/api/course/fr')).enrolled, false);

/* языки преподавателей */
assert.equal(call(admin, 'POST', '/api/admin/teachers', { name: 'Без языка', email: 'nl@x.io', password: 'teacherpass1' }).status, 400);
const mkT = (name, email, langs) => app.db().users[okc(call(admin, 'POST', '/api/admin/teachers', { name, email, langs, password: 'teacherpass1', meeting_url: 'https://meet.example.com/' + name })).teacher.id];
const kim = mkT('Ким', 'kim@x.io', ['thai']), marie = mkT('Мари', 'marie@x.io', ['fr']), poly = mkT('Поли', 'poly@x.io', ['thai', 'fr']);
assert.deepEqual(okc(call(admin, 'GET', `/api/admin/users/${kim.id}`)).user.langs, ['thai']);
const names = u => okc(call(u, 'GET', '/api/teachers')).teachers.map(t => t.name).sort();
assert.deepEqual(names(anna), ['Ким', 'Поли']); assert.deepEqual(names(fred), ['Мари', 'Поли']); ok('ученик видит в списке только преподавателей своего языка');
assert.equal(call(admin, 'POST', `/api/admin/users/${anna.id}/assign`, { course: 'thai', teacher: marie.id }).status, 400);
okc(call(admin, 'POST', `/api/admin/users/${fred.id}/assign`, { course: 'fr', teacher: marie.id })); ok('закрепить можно только преподавателя этого языка');

const start = clock + 30 * HOUR;
assert.equal(call(anna, 'POST', '/api/live/request', { teacher: marie.id, course: 'thai', start }).status, 400, 'запрос преподавателю другого языка');
const rq = okc(call(fred, 'POST', '/api/live/request', { teacher: marie.id, course: 'fr', start })).request;
okc(call(marie, 'POST', `/api/teach/requests/${rq.id}/accept`)); ok('запрос урока: только преподавателю своего языка; для языка без готовых уроков в платформе занятия тоже работают');
assert.equal(call(marie, 'POST', '/api/teach/sessions', { student: anna.id, course: 'thai', start: start + 5 * HOUR, dur: 50 }).status, 400);
assert.equal(call(admin, 'POST', '/api/teach/sessions', { teacher: marie.id, student: anna.id, course: 'thai', start: start + 5 * HOUR, dur: 50 }).status, 400, 'админ тоже не назначит преподавателя вне его языков');
ok('преподаватель французского не может вести ученика с тайским');

/* языки можно менять; приглашение преподавателя задаёт языки */
assert.equal(call(admin, 'POST', `/api/admin/users/${marie.id}/langs`, { langs: [] }).status, 400);
okc(call(admin, 'POST', `/api/admin/users/${marie.id}/langs`, { langs: ['fr', 'es', 'нет-такого'] }));
assert.deepEqual(app.db().users[marie.id].langs, ['fr', 'es']);
assert.equal(call(admin, 'POST', '/api/admin/invites', { role: 'teacher' }).status, 400);
const [inv] = okc(call(admin, 'POST', '/api/admin/invites', { role: 'teacher', langs: ['es', 'zh'] })).codes;
const t2 = okc(call(null, 'POST', '/api/staff/register', { code: inv, name: 'Лу', email: 'lu@x.io', password: 'secret1234' }));
assert.deepEqual(app.db().users[t2.user.id].langs, ['es', 'zh']);
assert.deepEqual(okc(call(admin, 'GET', '/api/admin/invites')).invites.find(i => i.code === inv).langs.length, 2); ok('приглашение преподавателя несёт языки и записывает их при регистрации');

/* терпимость к вводу: регистр, пробелы, длинное тире, русская раскладка, без дефисов */
const [c1, c2, c3, c4] = okc(call(admin, 'POST', '/api/admin/codes', { course: 'es', days: 30, count: 4, max: 1 })).codes;
const ru = c => c.split('').map(ch => ({ Q: 'Й', W: 'Ц', E: 'У', R: 'К', T: 'Е', Y: 'Н', U: 'Г', I: 'Ш', O: 'Щ', P: 'З', A: 'Ф', S: 'Ы', D: 'В', F: 'А', G: 'П', H: 'Р', J: 'О', K: 'Л', L: 'Д', Z: 'Я', X: 'Ч', C: 'С', V: 'М', B: 'И', N: 'Т', M: 'Ь' }[ch] || ch)).join('');
assert.equal(U(reg('Э1', 'e1@x.io', ' ' + c1.toLowerCase().replace(/-/g, ' ') + ' ')).role, 'student');
assert.equal(U(reg('Э2', 'e2@x.io', ru(c2))).role, 'student');
assert.equal(U(reg('Э3', 'e3@x.io', c3.replace(/-/g, '–'))).role, 'student');
assert.equal(U(reg('Э4', 'e4@x.io', c4.replace(/-/g, ''))).role, 'student'); ok('код принимается в любом регистре, с пробелами, длинным тире, в русской раскладке и без дефисов');
const n0 = users(); assert.match(reg('Э5', 'e5@x.io', 'ПУСТО-ПУСТО').body.error, /не найден/); assert.equal(users(), n0, 'неверный код — без аккаунта');
/* код только на клуб: аккаунт без языков, каталог чужих языков не показываем */
const [clubCode] = okc(call(admin, 'POST', '/api/admin/codes', { course: 'club', days: 30 })).codes;
const cl = U(reg('Клубный', 'cl@x.io', clubCode)); assert.equal(okc(call(cl, 'GET', '/api/club')).sub.state, 'active'); assert.deepEqual(okc(call(cl, 'GET', '/api/overview')).courses, []); ok('код на Разговорный клуб при регистрации открывает клуб без чужих языков');
console.log('\nПроверки кодов и языков пройдены:', n);
