'use strict';
/* Проверка SMTP-клиента на поддельном локальном сервере: node --no-warnings test/smtp.test.js */
const net = require('node:net');
const assert = require('node:assert/strict');
const { sendMail } = require('../lib/smtp');

function fake({ starttls = false, authOk = true } = {}) {
  const got = { cmds: [], data: '' };
  const srv = net.createServer(s => {
    s.setEncoding('utf8'); let mode = 'cmd', buf = '';
    s.write('220 fake ESMTP\r\n');
    s.on('data', d => {
      buf += d;
      for (;;) {
        if (mode === 'data') { const i = buf.indexOf('\r\n.\r\n'); if (i < 0) return; got.data = buf.slice(0, i); buf = buf.slice(i + 5); mode = 'cmd'; s.write('250 queued\r\n'); continue; }
        const i = buf.indexOf('\r\n'); if (i < 0) return; const line = buf.slice(0, i); buf = buf.slice(i + 2); got.cmds.push(line.split(' ')[0]);
        if (/^EHLO/.test(line)) s.write('250-fake\r\n' + (starttls ? '250-STARTTLS\r\n' : '') + '250 AUTH PLAIN\r\n');
        else if (/^AUTH/.test(line)) { got.auth = Buffer.from(line.split(' ')[2], 'base64').toString(); s.write(authOk ? '235 ok\r\n' : '535 bad credentials\r\n'); }
        else if (/^MAIL/.test(line)) { got.from = line; s.write('250 ok\r\n'); }
        else if (/^RCPT/.test(line)) { got.to = line; s.write('250 ok\r\n'); }
        else if (/^DATA/.test(line)) { mode = 'data'; s.write('354 go\r\n'); }
        else if (/^QUIT/.test(line)) { s.end('221 bye\r\n'); }
        else s.write('250 ok\r\n');
      }
    });
  });
  return new Promise(r => srv.listen(0, '127.0.0.1', () => r({ srv, got, port: srv.address().port })));
}

(async () => {
  let f = await fake();
  await sendMail({ host: '127.0.0.1', port: f.port, user: 'u@x.io', pass: 'pw', from: 'Vosca <noreply@x.io>', requireTls: false }, { to: 'Анна <anna@x.io>', subject: 'Урок завтра — 18:00', text: 'Привет, мир', html: '<p>Привет <b>мир</b></p>' });
  assert.deepEqual(f.got.cmds.slice(0, 5), ['EHLO', 'AUTH', 'MAIL', 'RCPT', 'DATA']);
  assert.equal(f.got.auth, '\0u@x.io\0pw'); assert.match(f.got.from, /noreply@x\.io/); assert.match(f.got.to, /<anna@x\.io>/);
  assert.match(f.got.data, /Subject: =\?UTF-8\?B\?/); assert.match(f.got.data, /multipart\/alternative/);
  const b64s = [...f.got.data.matchAll(/base64\r\n\r\n([A-Za-z0-9+/=\r\n]+)/g)].map(m => Buffer.from(m[1].replace(/\s/g, ''), 'base64').toString());
  assert.deepEqual(b64s, ['Привет, мир', '<p>Привет <b>мир</b></p>']); f.srv.close();
  console.log('  ✓ письмо уходит: авторизация, адреса, кириллица в теме и тексте, html-часть');

  f = await fake({ authOk: false });
  await assert.rejects(() => sendMail({ host: '127.0.0.1', port: f.port, user: 'u', pass: 'bad', from: 'a@x.io', requireTls: false }, { to: 'b@x.io', subject: 's', text: 't' }), /535/); f.srv.close();
  console.log('  ✓ неверный пароль SMTP даёт понятную ошибку');

  f = await fake();
  await assert.rejects(() => sendMail({ host: '127.0.0.1', port: f.port, user: 'u', pass: 'p', from: 'a@x.io', requireTls: true }, { to: 'b@x.io', subject: 's', text: 't' }), /STARTTLS/); f.srv.close();
  assert.ok(!f.got.cmds.includes('AUTH')); console.log('  ✓ без шифрования пароль не отправляется (requireTls)');

  await assert.rejects(() => sendMail({ host: '127.0.0.1', port: 1, from: 'a@x.io' }, { to: 'b@x.io', subject: 's', text: 't' }));
  console.log('  ✓ недоступный сервер — ошибка, а не зависание\n\nSMTP-проверки пройдены: 4');
})().catch(e => { console.error(e); process.exit(1); });
