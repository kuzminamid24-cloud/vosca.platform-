'use strict';
/* Тесты ядра без HTTP, с управляемыми часами:  node --no-warnings test/core.test.js */
const assert = require('node:assert/strict');
const path = require('node:path');
const crypto = require('node:crypto');
const { load } = require('../lib/loader');
const contentLib = require('../lib/content');

const DAY = 864e5, HOUR = 3600e3, MIN = 60e3;
let clock = Date.UTC(2026, 9, 26, 9, 0, 0);          // пн 26.10.2026, 12:00 по Москве
const content = contentLib.open(path.join(__dirname, '..', 'content'));
const core = load(), rawDb = {};
const env = {
  now: () => clock, random: Math.random, token: n => crypto.randomBytes(n).toString('base64url'),
  hashPassword: p => 'h:' + p, verifyPassword: (p, h) => h === 'h:' + p, dummyHash: () => 'h:?', baseUrl: () => 'https://app.test', dropSessions() { }, mailMode: () => 'log'
};
const app = core.createApp({ db: rawDb, content, env, adminEmail: 'admin@test.io', cfg: { PASS_SCORE: 80, HW_SIZE: 8, HW_PASS: 70, MIN_LESSON_SECONDS: 0, AUTO_ENROLL: [], REQUIRE_CODE: false } });
const D = () => app.db();
const call = (user, method, p, body, q) => app.handle({ method, path: p, body: body || {}, query: q || {}, user: user ? D().users[user.id] : null, ip: '1.2.3.4', ua: 'test' });
const okc = (r, msg) => { assert.equal(r.status, 200, (msg || '') + ' → ' + JSON.stringify(r.body)); return r.body; };
let passed = 0; const ok = n => { passed++; console.log('  ✓', n); };
const CONS = { offer: true, pd: true, age: true };
const reg = (name, email, extra) => { const r = call(null, 'POST', '/api/register', Object.assign({ name, email, password: 'secret1234', tz: 'Europe/Moscow', consents: CONS }, extra)); okc(r); return D().users[r.login]; };
const finish = (u, key, hits) => { const n = content.meta(key).tasks; return okc(call(u, 'POST', '/api/progress/' + key, { done: n, total: n, tries: 100, hits: hits || 85, xp: 50, seconds: 600 })); };
const mails = to => D().outbox.filter(m => !to || m.to === to);
const msk = (y, mo, d, h, mi) => Date.UTC(y, mo - 1, d, h - 3, mi || 0);

/* ═══ регистрация и согласия ═══ */
let r = call(null, 'POST', '/api/register', { name: 'А', email: 'a@x.io', password: 'secret1234', consents: { offer: true } });
assert.equal(r.status, 400); assert.match(r.body.error, /персональных данных/);
r = call(null, 'POST', '/api/register', { name: 'А', email: 'a@x.io', password: 'secret1234', consents: { offer: true, pd: true } });
assert.equal(r.status, 400); assert.match(r.body.error, /возраст/);
const anna = reg('Анна', 'anna@x.io'), boris = reg('Борис', 'boris@x.io', { consents: Object.assign({ ads: true }, CONS) });
assert.equal(call(null, 'POST', '/api/register', { name: 'Анна', email: 'ANNA@x.io', password: 'secret1234', consents: CONS }).status, 409);
assert.equal(D().consents.filter(c => c.uid === anna.id && c.accepted).length, 3);
assert.equal(okc(call(anna, 'GET', '/api/me')).ads, false); assert.equal(okc(call(boris, 'GET', '/api/me')).ads, true);
ok('регистрация: обязательные согласия, реклама — отдельно и по желанию, журнал согласий');
okc(call(boris, 'POST', '/api/account', { ads: false })); assert.equal(okc(call(boris, 'GET', '/api/me')).ads, false);
assert.equal(D().consents.filter(c => c.uid === boris.id && c.doc === 'consent-ads').length, 2);
ok('согласие на рекламу отзывается в профиле, оба события остаются в журнале');

const offer = okc(call(null, 'GET', '/api/legal/offer')); assert.match(offer.html, /ст\. 437/); assert.ok(offer.missing.includes('name'));
['privacy', 'consent-pd', 'consent-ads'].forEach(d => okc(call(null, 'GET', '/api/legal/' + d)));
assert.equal(call(null, 'GET', '/api/legal/nope').status, 404);
ok('4 документа отдаются, незаполненные реквизиты помечены');
const admin = app.bootstrapAdmin('admin@test.io', 'adminpass1', 'Админ');
okc(call(admin, 'POST', '/api/admin/settings', { name: 'ИП Тест', status: 'ИП', inn: '1234567890', ogrn: '1234567890123', address: 'Москва', email: 'legal@test.io', phone: '+7 000', site: 'https://voscaschool.com', servers: 'РФ, Москва', hosting: 'X', mailer: 'Y', payments: 'Z', video: 'Zoom', refund_days: '10', price_note: '5 000 ₽' }));
assert.equal(okc(call(null, 'GET', '/api/legal/offer')).missing.length, 0); assert.match(okc(call(null, 'GET', '/api/legal/privacy')).html, /ИП Тест/);
ok('реквизиты из админки подставляются во все документы');

/* ═══ доступ по курсам ═══ */
let ov = okc(call(anna, 'GET', '/api/overview'));
assert.equal(ov.courses.find(c => c.id === 'thai').enrolled, false);
let e = call(anna, 'GET', '/api/lesson/prep-1'); assert.equal(e.status, 403); assert.equal(e.body.noCourse, 'thai');
ok('без покупки курс закрыт: ни уроков, ни ДЗ');
const [code1] = okc(call(admin, 'POST', '/api/admin/codes', { course: 'thai', days: 30, count: 1, max: 1, note: 'тест' })).codes;
assert.match(code1, /^VOSCA-[A-Z0-9]{4}-[A-Z0-9]{4}$/);
assert.equal(call(anna, 'POST', '/api/redeem', { code: 'VOSCA-NOPE-NOPE' }).status, 404);
okc(call(anna, 'POST', '/api/redeem', { code: code1.toLowerCase() }));
assert.equal(call(boris, 'POST', '/api/redeem', { code: code1 }).status, 409);
ov = okc(call(anna, 'GET', '/api/overview')); const tc = ov.courses.find(c => c.id === 'thai');
assert.ok(tc.enrolled); assert.ok(Math.abs(tc.expires - (clock + 30 * DAY)) < 5000);
assert.equal(call(anna, 'GET', '/api/lesson/prep-1').status, 200); assert.equal(call(boris, 'GET', '/api/lesson/prep-1').status, 403);
ok('код доступа: открывает только свой курс, одноразовый, срок 30 дней');
assert.ok(D().outbox.some(m => m.to === 'anna@x.io' && /Курс «Тайский язык» открыт/.test(m.subject)));
ok('письмо «курс открыт» поставлено в очередь');

/* ═══ прохождение, автооткрытие, ДЗ, достижения ═══ */
let p = finish(anna, 'prep-1', 70); assert.equal(p.passed, false); assert.equal(p.lowScore, true);
assert.equal(call(anna, 'GET', '/api/lesson/prep-2').status, 403);
p = finish(anna, 'prep-1', 85); assert.equal(p.passedNow, true); assert.equal(p.hwCreated, true); assert.equal(p.next.key, 'prep-2');
assert.equal(call(anna, 'GET', '/api/lesson/prep-2').status, 200);
let notes = okc(call(anna, 'GET', '/api/notifications')).items.map(n => n.kind);
assert.ok(notes.includes('hw_new') && notes.includes('unlock') && notes.includes('achievement'));
ov = okc(call(anna, 'GET', '/api/overview')); assert.equal(ov.streak.days, 1); assert.ok(ov.achievements.find(a => a.id === 'first').at);
const hw = okc(call(anna, 'GET', '/api/homework/prep-1')); assert.equal(hw.questions.length, 8); assert.ok(hw.questions.every(q => q.a === undefined));
const bank = Object.fromEntries(content.bank('prep-1').map(x => [x.id, x]));
let sub = okc(call(anna, 'POST', '/api/homework/prep-1/submit', { answers: Object.fromEntries(hw.questions.map(q => [q.id, (bank[q.id].a + 1) % q.opts.length])) })); assert.equal(sub.passed, false);
const hw2 = okc(call(anna, 'GET', '/api/homework/prep-1'));
sub = okc(call(anna, 'POST', '/api/homework/prep-1/submit', { answers: Object.fromEntries(hw2.questions.map(q => [q.id, bank[q.id].a])) })); assert.equal(sub.score, 100);
assert.ok(okc(call(anna, 'GET', '/api/overview')).achievements.find(a => a.id === 'ace').at);
ok('80% → следующий урок, ДЗ, уведомления, достижения; ДЗ: пересдача с новой подборкой, ответы не утекают');
clock += DAY; finish(anna, 'prep-1', 90);
assert.equal(okc(call(anna, 'GET', '/api/overview')).streak.days, 2);
clock += 3 * DAY; assert.equal(okc(call(anna, 'GET', '/api/overview')).streak.days, 0);
clock -= 4 * DAY; clock += 4 * DAY;
ok('серия дней растёт и обрывается при пропуске');

/* срок доступа */
clock += 27 * DAY;                                                   // 31 день с покупки
ov = okc(call(anna, 'GET', '/api/overview')); const exp = ov.courses.find(c => c.id === 'thai');
assert.equal(exp.enrolled, false); assert.equal(exp.expired, true); assert.equal(call(anna, 'GET', '/api/lesson/prep-2').status, 403);
const [code2] = okc(call(admin, 'POST', '/api/admin/codes', { course: 'thai', days: 60, count: 1, max: 5 })).codes;
okc(call(anna, 'POST', '/api/redeem', { code: code2 }));
assert.ok(okc(call(anna, 'GET', '/api/overview')).courses.find(c => c.id === 'thai').enrolled); assert.equal(call(anna, 'GET', '/api/lesson/prep-2').status, 200);
assert.equal(okc(call(anna, 'GET', '/api/overview')).courses.find(c => c.id === 'thai').passed, 1);
ok('по окончании срока курс закрывается, прогресс сохраняется, новый код возобновляет доступ');

/* ═══ преподаватели и живые уроки ═══ */
assert.equal(call(anna, 'GET', '/api/teach').status, 403);
okc(call(admin, 'POST', '/api/admin/teachers', { name: 'Ким', email: 'kim@x.io', langs: ['thai'], password: 'teacherpass1', meeting_url: 'https://meet.example.com/kim', tz: 'Asia/Bangkok' }));
assert.equal(call(admin, 'POST', '/api/admin/teachers', { name: 'Нок', email: 'nok@x.io', langs: ['thai'], password: 'teacherpass1', meeting_url: 'http://insecure.example.com' }).status, 400);
assert.equal(call(admin, 'POST', '/api/admin/teachers', { name: 'Нок', email: 'nok@x.io', langs: ['thai'], password: 'teacherpass1', meeting_url: 'javascript:alert(1)' }).status, 400);
const kim = Object.values(D().users).find(u => u.email === 'kim@x.io');
clock = msk(2026, 11, 28, 12, 0);
const startA = msk(2026, 12, 2, 18, 0);                                // ср 02.12, 18:00 МСК = 22:00 по Бангкоку
assert.equal(call(kim, 'POST', '/api/teach/sessions', { student: anna.id, course: 'thai', start: startA }).status, 403);   // ученик не закреплён
okc(call(admin, 'POST', `/api/admin/users/${anna.id}/assign`, { course: 'thai', teacher: kim.id }));
let cr = okc(call(kim, 'POST', '/api/teach/sessions', { student: anna.id, course: 'thai', start: startA, dur: 50, repeat: 3, title: 'Разговорная практика' })).created;
assert.equal(cr.length, 3); assert.equal(cr[0].url, 'https://meet.example.com/kim'); assert.equal(cr[1].starts - cr[0].starts, 7 * DAY);
const m1 = mails('anna@x.io').find(m => /Назначен урок/.test(m.subject)); assert.ok(m1); assert.match(m1.subject, /18:00/); assert.match(m1.html, /meet\.example\.com\/kim/);
assert.equal(call(kim, 'POST', '/api/teach/sessions', { student: anna.id, course: 'thai', start: startA + 20 * MIN, dur: 50 }).status, 409);
ok('преподаватель назначает серию из 3 уроков; ссылка на встречу берётся из профиля; пересечения запрещены; письмо ученику в его поясе');
let sc = okc(call(anna, 'GET', '/api/schedule'));
assert.equal(sc.upcoming.length, 3); assert.equal(sc.upcoming[0].teacher.name, 'Ким'); assert.equal(sc.teachers[0].name, 'Ким'); assert.match(sc.calUrl, /^https:\/\/app\.test\/cal\/.+\.ics$/);
assert.equal(okc(call(anna, 'GET', '/api/overview')).nextLive.id, sc.upcoming[0].id);
assert.equal(call(boris, 'GET', '/api/schedule').body.upcoming.length, 0);
ok('ученик видит расписание, преподавателя и ссылку на видеозвонок; чужие уроки не видны');

/* напоминания */
const s0 = D().live[sc.upcoming[0].id];
clock = s0.starts - 25 * HOUR; app.tick(); assert.equal(mails('anna@x.io').filter(m => /завтра|Напоминание/i.test(m.subject)).length, 0);
clock = s0.starts - 23 * HOUR; app.tick();
const r24a = mails('anna@x.io').find(m => /Напоминание: урок завтра/.test(m.subject)), r24k = mails('kim@x.io').find(m => /Напоминание: урок завтра/.test(m.subject));
assert.ok(r24a && r24k); assert.match(r24a.subject, /18:00/); assert.match(r24k.subject, /22:00/);          // каждый видит время в своём поясе
app.tick(); assert.equal(mails('anna@x.io').filter(m => /Напоминание: урок завтра/.test(m.subject)).length, 1);
clock = s0.starts - 14 * MIN; app.tick();
const r15 = mails('anna@x.io').find(m => /Урок начинается/.test(m.subject)); assert.ok(r15); assert.match(r15.html, /meet\.example\.com\/kim/);
assert.ok(okc(call(anna, 'GET', '/api/notifications')).items.some(n => n.kind === 'live_r15'));
ok('напоминания за 24 часа и за 15 минут: по одному разу, обоим, время — в поясе получателя, в письме ссылка на встречу');

/* перенос, отказ, отмена, итог */
clock = msk(2026, 11, 29, 12, 0);
const before = mails('anna@x.io').length;
okc(call(kim, 'POST', `/api/teach/sessions/${s0.id}/move`, { start: msk(2026, 12, 3, 19, 0) }));
assert.match(mails('anna@x.io').pop().subject, /Урок перенесён/); assert.equal(mails('anna@x.io').length, before + 1);
assert.equal(call(anna, 'POST', `/api/teach/sessions/${s0.id}/cancel`, {}).status, 403);
okc(call(anna, 'POST', `/api/schedule/${sc.upcoming[1].id}/decline`, { reason: 'Болею' }));
assert.ok(okc(call(kim, 'GET', '/api/teach')).upcoming.find(s => s.id === sc.upcoming[1].id).declined);
assert.ok(mails('kim@x.io').some(m => /просит перенести/.test(m.subject)));
okc(call(kim, 'POST', `/api/teach/sessions/${sc.upcoming[2].id}/cancel`, { reason: 'Праздник' }));
assert.match(mails('anna@x.io').pop().html, /Праздник/);
okc(call(kim, 'POST', `/api/teach/sessions/${s0.id}/done`, { note: 'Отлично! Повторить тоны.' }));
assert.ok(okc(call(anna, 'GET', '/api/notifications')).items.some(n => n.kind === 'teacher_note'));
assert.equal(okc(call(anna, 'GET', '/api/schedule')).past.find(s => s.id === s0.id).note, 'Отлично! Повторить тоны.');
assert.ok(okc(call(anna, 'GET', '/api/overview')).achievements.find(a => a.id === 'live').at);
ok('перенос, отказ ученика, отмена, итог урока с заметкой, достижение «Живой урок»');

/* календарь */
const ics = app.icsByToken(anna.cal); assert.match(ics, /BEGIN:VCALENDAR/); assert.match(ics, /URL:https:\/\/meet\.example\.com\/kim/); assert.match(ics, /TRIGGER:-PT15M/);
assert.equal(app.icsByToken('nope'), null);
ok('персональная ссылка-календарь (.ics) со ссылкой на встречу и напоминанием');

/* учёт летнего времени в серии */
const teacherB = okc(call(admin, 'POST', '/api/admin/teachers', { name: 'Берлин', email: 'be@x.io', langs: ['thai'], password: 'teacherpass1', meeting_url: 'https://meet.example.com/be', tz: 'Europe/Berlin' })).teacher;
okc(call(admin, 'POST', `/api/admin/users/${boris.id}/enroll`, { course: 'thai', days: 400 }));
clock = msk(2027, 3, 1, 12, 0);
okc(call(admin, 'POST', '/api/teach/sessions', { teacher: teacherB.id, student: boris.id, course: 'thai', start: Date.UTC(2027, 2, 20, 9, 0), repeat: 3 }));
const bs = Object.values(D().live).filter(s => s.student === boris.id).sort((a, b) => a.starts - b.starts);
assert.deepEqual(bs.map(s => new Date(s.starts).toISOString().slice(0, 16)), ['2027-03-20T09:00', '2027-03-27T09:00', '2027-04-03T08:00']);
ok('серия сохраняет «настенное» время преподавателя при переходе на летнее время');

/* письма можно отключить, уведомления в кабинете остаются */
okc(call(anna, 'POST', '/api/account', { notify: false })); const nm = mails('anna@x.io').length;
clock = msk(2026, 11, 30, 1, 0); const s1 = D().live[sc.upcoming[1].id]; s1.status = 'planned'; s1.starts = clock + 20 * HOUR; s1.r24 = 0; app.tick();
assert.equal(mails('anna@x.io').length, nm); assert.ok(okc(call(anna, 'GET', '/api/notifications')).items.length > 0);
okc(call(anna, 'POST', '/api/account', { notify: true }));
ok('выключенные письма не отправляются, уведомления в кабинете сохраняются');

/* ═══ обновление документов, экспорт и удаление ═══ */
D().consents.filter(c => c.uid === anna.id && c.doc === 'offer').forEach(c => { c.version = '2020-01-01'; });
assert.equal(okc(call(anna, 'GET', '/api/me')).needConsent[0].id, 'offer');
const blocked = call(anna, 'GET', '/api/overview'); assert.equal(blocked.status, 200);   // overview сам сообщает needConsent
assert.equal(call(anna, 'GET', '/api/lesson/prep-1').status, 403); assert.ok(call(anna, 'GET', '/api/lesson/prep-1').body.needConsent);
okc(call(anna, 'POST', '/api/consent/accept', { docs: ['offer'] })); assert.equal(call(anna, 'GET', '/api/lesson/prep-1').status, 200);
ok('при новой версии оферты работа блокируется до повторного согласия');
const exp2 = okc(call(anna, 'GET', '/api/account/export')); assert.equal(exp2.profile.email, 'anna@x.io'); assert.ok(exp2.consents.length >= 3); assert.equal(exp2.profile.hash, undefined);
assert.equal(call(anna, 'POST', '/api/account/delete', { password: 'wrong' }).status, 403);
const del = call(anna, 'POST', '/api/account/delete', { password: 'secret1234' }); assert.equal(del.status, 200); assert.ok(del.logout);
assert.equal(Object.values(D().users).some(u => u.email === 'anna@x.io'), false); assert.equal(D().progress[anna.id], undefined);
assert.ok(D().consents.filter(c => c.uid === anna.id).every(c => c.ip === ''));
assert.equal(Object.values(D().live).filter(s => s.student === anna.id).length, 0);
ok('выгрузка данных и удаление аккаунта: данные стёрты, в журнале согласий — обезличено');

/* ═══ админка ═══ */
const cat = okc(call(admin, 'GET', '/api/admin/catalog')); assert.equal(Object.keys(cat.lessons).length, 12);
okc(call(admin, 'POST', `/api/admin/users/${boris.id}/role`, { role: 'teacher' })); assert.equal(call(boris, 'GET', '/api/teach').status, 200);
assert.equal(call(admin, 'POST', `/api/admin/users/${admin.id}/role`, { role: 'student' }).status, 400);
okc(call(admin, 'POST', `/api/admin/users/${boris.id}/role`, { role: 'student' }));
okc(call(admin, 'POST', `/api/admin/users/${boris.id}/pass`, { lesson: 'prep-3' }));
assert.deepEqual(okc(call(admin, 'GET', `/api/admin/users/${boris.id}`)).courses[0].lessons.slice(0, 4).map(l => l.status), ['passed', 'passed', 'passed', 'open']);
okc(call(admin, 'POST', `/api/admin/users/${boris.id}/reset`, { lesson: 'prep-2' }));
assert.deepEqual(okc(call(admin, 'GET', `/api/admin/users/${boris.id}`)).courses[0].lessons.slice(0, 3).map(l => l.status), ['passed', 'open', 'locked']);
assert.ok(okc(call(admin, 'GET', '/api/admin/outbox')).items.length > 5); assert.ok(okc(call(admin, 'GET', '/api/admin/sessions')).upcoming.length >= 1);
ok('админка: каталог, роли, «засчитать до урока», «сбросить», журнал писем, расписание');

/* ═══ адаптер: прежние уроки подключаются к платформе автоматически ═══ */
const legacy = '<html><body><script>const State={done:new Set()};const LESSON={title:"x"};const TASKS=[];</script></body></html>';
const adapted = core.adaptLesson(legacy);
assert.ok(adapted.includes('vosca-lesson') && adapted.includes('getMeta') && adapted.indexOf('</script></body>') > 0);
assert.equal(core.adaptLesson(adapted), adapted);                      // повторно не дописывается
assert.equal(core.adaptLesson('<html><body>просто страница</body></html>'), null);
ok('адаптер: старый урок получает связь с платформой, чужой HTML отклоняется');

console.log(`\nВсе проверки ядра пройдены: ${passed}`);
