#!/bin/sh
# Сквозной тест в браузере на временной копии данных и контента (нужны: node 22+, python3, playwright)
cd "$(dirname "$0")/.."
T=$(mktemp -d); cp -r content "$T/content"
PORT=${PORT:-3111}
DATA_DIR="$T/data" CONTENT_DIR="$T/content" PORT=$PORT ADMIN_EMAIL=admin@vosca.test ADMIN_PASSWORD=adminpass123 node --no-warnings server.js >"$T/server.log" 2>&1 &
PID=$!; trap 'kill $PID 2>/dev/null; rm -rf "$T"' EXIT; sleep 1.5
BASE=http://localhost:$PORT python3 test/e2e.py
